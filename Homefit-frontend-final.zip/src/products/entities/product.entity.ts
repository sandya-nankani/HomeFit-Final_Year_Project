import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  OneToMany,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { ProductOrder } from './productOrder.entity';
import { Feedback } from 'src/feedback/entities/feedback.entity';
import { Category } from 'src/category/entities/category.entity';

@Entity()
export class Products {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  title: string;

  @Column()
  description: string;

  @Column()
  price: number;

  @Column()
  stock: number;

  @Column({ type: 'longblob' })
  image: Buffer;

  @Column()
  discount: number;

  @Column()
  discountPrice: number;

  @ManyToOne(() => Category)
  @JoinColumn({ name: 'categoryId' })
  category: Category;

  @OneToMany(() => ProductOrder, (order) => order.product)
  orders: ProductOrder[];

  @OneToMany(() => Feedback, (feedback) => feedback.product)
  feedback: Feedback[];
}
