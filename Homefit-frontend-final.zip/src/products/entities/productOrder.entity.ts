import { Column, Entity, PrimaryGeneratedColumn, ManyToOne, OneToOne, JoinColumn } from 'typeorm';
import { Products } from './product.entity';
import { User } from 'src/users/entities/user.entity';
import { OrderAddress } from 'src/order/entities/orderAddress.entity';

@Entity()
export class ProductOrder {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  orderId: string; // Assuming this is a unique identifier for the order

  @Column({ type: 'timestamp' })
  orderDate: Date;

  @Column('decimal', { precision: 10, scale: 2 })
  price: number;

  @Column()
  quantity: number;

  @Column()
  status: string; // Example status (e.g., "pending", "shipped")

  @Column()
  paymentType: string; // Type of payment (e.g., "credit card", "paypal")

  @ManyToOne(() => Products, (product) => product.orders) // Many-to-one relationship with Products
  @JoinColumn({ name: 'productId' })
  product: Products;

  @ManyToOne(() => User, (user) => user.orders) // Many-to-one relationship with User
  @JoinColumn({ name: 'userId' })
  user: User;

  @OneToOne(() => OrderAddress) // One-to-one relationship with OrderAddress
  @JoinColumn({ name: 'orderAddressId' })
  orderAddress: OrderAddress;
}
