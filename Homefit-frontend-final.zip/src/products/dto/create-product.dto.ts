export class CreateProductDto {
    title: string;
    description: string;
    price: number;
    stock: number;
    image: string;
    // discount: number;
    // discountPrice: number;
    categoryId: number; 
  }
  