import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { Products } from './entities/product.entity';
import { Like, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Category } from 'src/category/entities/category.entity';

@Injectable()
export class ProductsService {
  constructor(
    @InjectRepository(Products)
    private productRepository: Repository<Products>,
    @InjectRepository(Category)
    private categoryRepository: Repository<Category>,
  ) {}

  async create(
    createProductDto: CreateProductDto,
    imageBuffer?: Buffer,
  ): Promise<Products> {
    const category = await this.categoryRepository.findOneBy({
      id: createProductDto.categoryId,
    });
    if (!category) {
      throw new NotFoundException('Category not found');
    }

    const newProduct = this.productRepository.create({
      ...createProductDto,
      image: imageBuffer || null,
      category,
    });

    return this.productRepository.save(newProduct);
  }

  async findAll(page = 1, limit = 10) {
    const [products, total] = await this.productRepository.findAndCount({
      relations: ['category'],
      skip: (page - 1) * limit,
      take: limit,
    });

    const updatedProducts = products.map((product) => ({
      ...product,
      image: product.image
        ? `data:image/png;base64,${product.image.toString('base64')}`
        : null,
    }));

    return {
      totalItems: total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      pageSize: limit,
      products: updatedProducts,
    };
  }

  async findOne(id: number): Promise<Products> {
    const product = await this.productRepository.findOne({
      where: { id },
      relations: ['category'],
    });
    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }
    return product;
  }
  async update(
    id: number,
    updateProductDto: UpdateProductDto,
    imageBuffer?: Buffer,
  ): Promise<Products> {
    const product = await this.productRepository.findOne({
      where: { id },
      relations: ['category'],
    });
    if (!product) throw new NotFoundException('Product not found');

    if (updateProductDto.categoryId) {
      const category = await this.categoryRepository.findOneBy({
        id: updateProductDto.categoryId,
      });
      if (!category) throw new NotFoundException('Category not found');
      product.category = category;
    }

    Object.assign(product, updateProductDto);

    if (imageBuffer) {
      product.image = imageBuffer;
    }

    await this.productRepository.save(product);

    return product;
  }

  async remove(id: number): Promise<void> {
    const product = await this.findOne(id);
    await this.productRepository.remove(product as Products);
  }

  async searchProducts(search = '', page = 1, limit = 10) {
    const skip = (page - 1) * limit;

    const [products, total] = await this.productRepository.findAndCount({
      where: [
        { title: Like(`%${search}%`) },
        // Remove category search unless you join properly
      ],
      relations: ['category'],
      skip,
      take: limit,
    });

    const updatedProducts = products.map((product) => ({
      ...product,
      image: product.image
        ? `data:image/png;base64,${product.image.toString('base64')}`
        : null,
    }));

    return {
      totalItems: total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      pageSize: limit,
      products: updatedProducts,
    };
  }
}
