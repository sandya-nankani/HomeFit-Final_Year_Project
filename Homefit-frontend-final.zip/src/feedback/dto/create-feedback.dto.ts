export class CreateFeedbackDto {}
