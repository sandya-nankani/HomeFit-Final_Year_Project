import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Feedback } from './entities/feedback.entity';
import { Products } from 'src/products/entities/product.entity';


@Injectable()
export class FeedbackService {
  constructor(
    @InjectRepository(Feedback) private feedbackRepo: Repository<Feedback>,
    @InjectRepository(Products) private productRepo: Repository<Products>,
  ) {}

  async createFeedback(data: {
    productId: number;
    userId?: number;
    rating: number;
    comment?: string;
  }) {
    const product = await this.productRepo.findOneBy({ id: data.productId });
    if (!product) throw new Error('Product not found');

    const feedback = this.feedbackRepo.create({
      product,
      userId: data.userId,
      rating: data.rating,
      comment: data.comment,
    });

    return this.feedbackRepo.save(feedback);
  }

  async getFeedbackForProduct(productId: number) {
    return this.feedbackRepo.find({
      where: { product: { id: productId } },
      relations: ['product'],
    });
  }

  getAllFeedback() {
    return this.feedbackRepo.find({ relations: ['product'] });
  }
}
