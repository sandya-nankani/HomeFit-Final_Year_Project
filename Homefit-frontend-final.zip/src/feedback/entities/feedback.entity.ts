import { Products } from 'src/products/entities/product.entity';
import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    CreateDateColumn,
    ManyToOne,
  } from 'typeorm';

  
  @Entity()
  export class Feedback {
    @PrimaryGeneratedColumn()
    id: number;
  
    @Column({ nullable: true })
    userId: number;
  
    @Column({ type: 'int' })
    rating: number;
  
    @Column({ type: 'text', nullable: true })
    comment: string;
  
    @CreateDateColumn()
    createdAt: Date;
  
    @ManyToOne(() => Products, (product) => product.feedback, {
      onDelete: 'CASCADE',
    })
    product: Products;
  }
  