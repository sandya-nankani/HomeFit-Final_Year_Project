import { Controller, Post, Get, Body, Param, BadRequestException } from '@nestjs/common';
import { FeedbackService } from './feedback.service';

@Controller('feedback')
export class FeedbackController {
  constructor(private readonly feedbackService: FeedbackService) {}

  @Post()
  async createFeedback(@Body() body: any) {
    const { productId, rating, comment, userId } = body;

    if (!productId || !rating) {
      throw new BadRequestException('productId and rating are required');
    }

    return this.feedbackService.createFeedback({ productId, rating, comment, userId });
  }

  @Get('product/:id')
  getProductFeedback(@Param('id') id: string) {
    return this.feedbackService.getFeedbackForProduct(+id);
  }

  @Get()
  getAllFeedback() {
    return this.feedbackService.getAllFeedback();
  }
}
