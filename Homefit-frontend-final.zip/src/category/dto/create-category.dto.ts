export class CreateCategoryDto {
    id: number;
    
    name:string;
      
    image:string;
}
