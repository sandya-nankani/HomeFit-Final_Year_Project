import { ProductOrder } from "src/products/entities/productOrder.entity";
import { Column, Entity, PrimaryGeneratedColumn, OneToMany } from "typeorm";

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  profilePic: string;
  
  @Column()
  firstName: string;

  @Column()
  lastName: string;

  @Column()
  userName: string;

  @Column()
  password: string;
  
  @Column()
  email: string;
  
  @Column()
  phone: string;
  
  @Column()
  address: string;
  
  @Column({ nullable: true })
  accountType: string;

  @OneToMany(() => ProductOrder, (order) => order.user)
  orders: ProductOrder[];


}
