import { Controller, Get, Post, Body, Patch, Param, Delete, BadRequestException, UseInterceptors, UploadedFile } from '@nestjs/common';
import { UsersService } from './users.service';
import { CreateUserDto } from './Dto/CreateUserDto';
import { UpdateUserDto } from './Dto/UpdateUserDto';
import { User } from './entities/user.entity';
import * as bcrypt from 'bcryptjs';
import { FileInterceptor } from '@nestjs/platform-express';


@Controller("user")
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post("/create")
  async create(@Body() createUserDto: CreateUserDto) {
    console.log("Hit on create user");
    

    const emailRegex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
    if (!emailRegex.test(createUserDto.email)){
      throw new BadRequestException("Invalid email format");
    }
    console.log("email clear");

    const PhoneRegex = /^03\d{9}$/;
    if (!PhoneRegex.test(createUserDto.phone)){
     throw new BadRequestException('Invalid Phone number: must be a valid 11-digit Pakistani number starting with 03');
    }
    console.log("phone clear ");

    const userName=/^[A-Za-z][A-Za-z0-9_]{7,29}$/;
    if(!userName.test(createUserDto.userName)){
      return "Please enter a valid user name";
    }
    console.log("username clear ");


    const passwordRegex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordRegex.test(createUserDto.password)) {
     throw new BadRequestException('Invalid password: must contain at least 8 characters, one uppercase letter,one lowercase letter, one number and one special character ');
    }
    console.log("password clear ");


    const existUserName=await this.usersService.findbyUserName(createUserDto.userName);
    if(existUserName){
      throw new BadRequestException("Username Already Exists.");
    }
    console.log("already user clear ");


    const existEmail=await this.usersService.findbyEmail(createUserDto.email);
    if(existEmail){
      throw new BadRequestException("Username Already Exists.");
    }
    console.log("already email clear ");

    
    const salt = await bcrypt.genSalt();
    const hashPassword=await bcrypt.hash(createUserDto.password,salt);

     // Set default account type to "user" if not provided
    const accountType = createUserDto.accountType?.toLowerCase() === 'admin' ? 'admin' : 'user';
  
    const user = new User();
    user.firstName=createUserDto.firstName
    user.lastName=createUserDto.lastName
    user.accountType=accountType;
    user.phone=createUserDto.phone
    user.email=createUserDto.email
    user.address=createUserDto.address
    user.userName=createUserDto.userName
    user.password=hashPassword;
    console.log("hhghgh"+createUserDto.firstName)
    return this.usersService.createUser(user);
  }

  @Get()
  findAll() {
    return this.usersService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.usersService.findOne(+id);
  }
  @Post('/checkEmail')
  async findbyEmail(@Body('email') email: string) { 
    console.log("email checking",email);
    
    const user= await this.usersService.findbyEmail(email);
    if(user){
    return {
      status:200,
      message:"User Found",
      user,
    };
  }
  return {
    status:404,
    message:"User not found"
  }
  }

  @Patch('resetPassword/:id')
async updatePassword(@Param('id') id: number, @Body() updateUserDto: UpdateUserDto) {
  console.log("hit on resetPassword");
  if (updateUserDto.password) {
    const salt = await bcrypt.genSalt();
    const hashPassword = await bcrypt.hash(updateUserDto.password, salt);
    updateUserDto.password = hashPassword;
  }

  console.log(updateUserDto);
  

  return await this.usersService.update(+id, updateUserDto);
}

  @Patch(':id')
  updateUser(@Param('id') id: string, @Body() updateUserDto: UpdateUserDto) {
    return this.usersService.update(+id, updateUserDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.usersService.remove(+id);
  }
  
}
