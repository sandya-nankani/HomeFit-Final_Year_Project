import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsersModule } from './users/users.module';
import { User } from './users/entities/user.entity';
import { AuthModule } from './auth/auth.module';
import * as cors from 'cors'; 
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import config from './config/config';
import { UsersController } from './users/users.controller';
import { AuthController } from './auth/auth.controller';
import { UsersService } from './users/users.service';
import { AuthService } from './auth/auth.service';
import { jwtConstants } from './auth/contants';
import { PassportModule } from '@nestjs/passport';
import { AppController } from './app.controller';
import { HttpModule } from '@nestjs/axios';
import { ProductsModule } from './products/products.module';
import { Products } from './products/entities/product.entity';
import { ProductsController } from './products/products.controller';
import { ProductsService } from './products/products.service';
import { CategoryModule } from './category/category.module';
import { CartModule } from './cart/cart.module';
import { OrderModule } from './order/order.module';
import { Cart } from './cart/entities/cart.entity';
import { Category } from './category/entities/category.entity';
import { OrderAddress } from './order/entities/orderAddress.entity';
import { ProductOrder } from './products/entities/productOrder.entity';
import { OrderService } from './order/order.service';
import { OrderController } from './order/order.controller';
import mailConfig from './config/mail.config';
import { EmailService } from './auth/email.service';
import { FeedbackModule } from './feedback/feedback.module';
import { Feedback } from './feedback/entities/feedback.entity';
import { FeedbackController } from './feedback/feedback.controller';
import { FeedbackService } from './feedback/feedback.service';
import { CategoryService } from './category/category.service';
import { CategoryController } from './category/category.controller';
import { CartService } from './cart/cart.service';
import { CartController } from './cart/cart.controller';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost',
      port: 3306,
      username: 'root',
      password: '',
      database: 'homefit',
      synchronize: true,
      entities: [User,Products,Cart,Category,OrderAddress,ProductOrder,Feedback],
    })
    ,HttpModule,
    TypeOrmModule.forFeature([User,Products,Cart,Category,OrderAddress,ProductOrder,Feedback]),
    ConfigModule.forRoot({
      isGlobal: true,
      load: [mailConfig],
}),
    JwtModule.register({
      global: true,
      secret: jwtConstants.secret,
      signOptions: { expiresIn: '1d' },
    }),
    UsersModule,
    AuthModule,
    PassportModule,
    ProductsModule,
    CategoryModule,
    CartModule,
    OrderModule,
    FeedbackModule,
  ],
  controllers: [
    AppController,
    UsersController,
    AuthController,
    ProductsController,
    OrderController,
    FeedbackController,
    CategoryController,
    CartController,
  ],
  providers: [
    AppService,
    UsersService,
    AuthService,
    ProductsService,
    OrderService,
    EmailService,
    FeedbackService,
    CategoryService,
    CartService,
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(cors()).forRoutes('*');
  }
}