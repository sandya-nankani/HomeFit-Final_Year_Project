import { ProductOrder } from 'src/products/entities/productOrder.entity';
import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  OneToMany,
} from 'typeorm';

@Entity()
export class OrderAddress {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  firstName: string;

  @Column()
  lastName: string;

  @Column()
  email: string;

  @Column()
  mobileNo: string;

  @Column()
  address: string;

  @Column()
  city: string;

  @Column()
  state: string;

  @Column()
  pincode: string;

  @Column()
  paymentType: string;

  @OneToMany(() => ProductOrder, (productOrder) => productOrder.orderAddress)
  productOrders: ProductOrder[];
}
