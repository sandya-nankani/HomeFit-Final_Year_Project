import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UpdateOrderDto } from './dto/update-order.dto';
import { OrderAddress } from './entities/orderAddress.entity';
import { Products } from 'src/products/entities/product.entity';
import { ProductOrder } from 'src/products/entities/productOrder.entity';
import { OrderRequestDto } from './dto/create-order.dto';

@Injectable()
export class OrderService {
  constructor(
    @InjectRepository(OrderAddress)
    private readonly orderRepository: Repository<OrderAddress>,

    @InjectRepository(ProductOrder)
    private readonly productOrderRepository: Repository<ProductOrder>,

    @InjectRepository(Products)
    private readonly productRepository: Repository<Products>,
  ) {}

  // async placeOrder(orderDto: OrderRequestDto) {
  //   const orderAddress = this.orderRepository.create({
  //     firstName: orderDto.firstName,
  //     lastName: orderDto.lastName,
  //     email: orderDto.email,
  //     mobileNo: orderDto.mobileNo,
  //     address: orderDto.address,
  //     city: orderDto.city,
  //     state: orderDto.state,
  //     pincode: orderDto.pincode,
  //     paymentType: orderDto.paymentType,
  //   });

  //   const savedAddress = await this.orderRepository.save(orderAddress);

  //   const productOrders = [];
  //   for (const item of orderDto.products) {
  //     const product = await this.productRepository.findOne({ where: { id: item.productId } });
  //     if (!product) throw new NotFoundException(`Product with ID ${item.productId} not found`);

  //     const productOrder = this.productOrderRepository.create({
  //       quantity: item.quantity,
  //       totalPrice: item.totalPrice,
  //       orderAddress: savedAddress,
  //       product,
  //     });

  //     productOrders.push(await this.productOrderRepository.save(productOrder));
  //   }

  //   return {
  //     message: 'Order placed successfully',
  //     orderAddress: savedAddress,
  //     products: productOrders,
  //   };
  // }

  // async findAll(): Promise<OrderAddress[]> {
  //   return await this.orderRepository.find();
  // }

  // async findOne(id: number): Promise<OrderAddress> {
  //   const order = await this.orderRepository.findOne({ where: { id } });
  //   if (!order) {
  //     throw new NotFoundException(`Order with ID ${id} not found`);
  //   }
  //   return order;
  // }

  // async update(id: number, updateOrderDto: UpdateOrderDto): Promise<OrderAddress> {
  //   await this.findOne(id);
  //   await this.orderRepository.update(id, updateOrderDto);
  //   return this.findOne(id);
  // }

  // async remove(id: number): Promise<void> {
  //   const order = await this.findOne(id);
  //   await this.orderRepository.remove(order);
  // }
}
