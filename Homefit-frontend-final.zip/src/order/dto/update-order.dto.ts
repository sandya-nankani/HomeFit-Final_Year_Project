import { PartialType } from '@nestjs/mapped-types';
import { OrderRequestDto } from './create-order.dto';


export class UpdateOrderDto extends PartialType(OrderRequestDto) {}
