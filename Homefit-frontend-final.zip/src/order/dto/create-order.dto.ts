export class OrderRequestDto {
      firstName: string;
      lastName: string;
      email: string;
      mobileNo: string;
      address: string;
      city: string;
      state: string;
      pincode: string;
      paymentType: string;
      products: {
        productId: number;
        quantity: number;
        totalPrice: number;
      }[];
    }
    