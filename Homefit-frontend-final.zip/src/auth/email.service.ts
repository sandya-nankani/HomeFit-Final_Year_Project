import { Injectable } from '@nestjs/common';
import * as nodemailer from 'nodemailer';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class EmailService {
  private transporter: nodemailer.Transporter;

  constructor(private configService: ConfigService) {
    this.transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'rkmeghani36@gmail.com',
        pass: 'elfp mjqc mvof rtmy',
      },
    });
  }

  async sendOTP(email: string, otp: string): Promise<void> {
    const mailOptions = {
      from: this.configService.get<string>('EMAIL_USER'), // Fix here
      to: email,
      subject: 'Your OTP Code',
      text: `Your OTP code is: ${otp}. It expires in 10 minutes.`,
    };

    await this.transporter.sendMail(mailOptions);
  }

  async sendOrderConfirmation(email: string, orderDetails: any): Promise<void> {
    const mailOptions = {
      from: this.configService.get<string>('EMAIL_USER'), // Fix here
      to: email,
      subject: 'Order Confirmation',
      html: `<h3>Thank you for your order!</h3>
             <p>Your order details:</p>
             <ul>
               ${orderDetails.items
                 .map(
                   (item) =>
                     `<li>${item.name} - ${item.quantity} x $${item.price}</li>`,
                 )
                 .join('')}
             </ul>
             <p>Total: <strong>$${orderDetails.total}</strong></p>`,
    };

    await this.transporter.sendMail(mailOptions);
  }
}
