import { Injectable, NotFoundException } from '@nestjs/common';
import * as nodemailer from 'nodemailer';
import { InjectRepository } from '@nestjs/typeorm';
import { SendEmail } from './entities/send-email.entity';
import { Repository } from 'typeorm';


@Injectable()
export class SendEmailService {

    private transporter;

    constructor(
         @InjectRepository(SendEmail)
             private readonly emailRepository: Repository<SendEmail>,)
    {
        this.transporter = nodemailer.createTransport({
            service: 'gmail',
            auth : {
                user: 'dttaskmanager@gmail.com',
                pass: 'tdoo olpm jbrs hemj',
            }
        })
    }

    async sendIdea(
        to: string,
        subject: string,
        text: string,
        cc: string[],
    ): Promise<void> {
        const mailOptions = {
            from: 'dttaskmanager@gmail.com',
            to,
            cc: cc.join(','),
            subject,
            text,
        };

        await this.transporter.sendMail(mailOptions);
        
        const emailRecord = this.emailRepository.create({
          recepientEmail: to,
          subject,
          text,
          ccEmails: cc.join(','), // TypeORM handles array storage with 'simple-array'
        });
    
        await this.emailRepository.save(emailRecord); // Save the email
      }
    
  

    async getAllEmails() {
      return await this.emailRepository.find();
    }
  
    async getEmailById(id: number) {
      const email = await this.emailRepository.findOne({ where: { id } });
      if (!email) {
        throw new NotFoundException(`Email with ID ${id} not found`);
      }
      return email;
    }
  
    async deleteEmail(id: number) {
      const result = await this.emailRepository.delete(id);
      if (result.affected === 0) {
        throw new NotFoundException(`Email with ID ${id} not found`);
      }
      return { message: `Email with ID ${id} deleted successfully` };
    } 
  }

