import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class SendEmail {

     @PrimaryGeneratedColumn()
      id: number;
    
    @Column()
        recepientEmail: string;
        
        @Column()
        subject: string
    
        @Column()
        text: string;
    
        @Column()
        ccEmails: string;

        @CreateDateColumn()
        createdAt: Date;
    }

