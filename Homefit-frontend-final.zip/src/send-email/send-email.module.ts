import { Module } from '@nestjs/common';
import { SendEmailService } from './send-email.service';
import { SendEmailController } from './send-email.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SendEmail } from './entities/send-email.entity';

@Module({
  imports: [TypeOrmModule.forFeature([SendEmail])],
  controllers: [SendEmailController],
  providers: [SendEmailService],
})
export class SendEmailModule {}
