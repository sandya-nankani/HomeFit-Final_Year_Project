export class CreateSendEmailDto {}
