import { Controller, Get, Post, Body, Patch, Param, Delete, HttpStatus } from '@nestjs/common';
import { SendEmailService } from './send-email.service';
import { CreateSendEmailDto } from './dto/create-send-email.dto';
import { UpdateSendEmailDto } from './dto/update-send-email.dto';

@Controller('send-email')
export class SendEmailController {
  constructor(private readonly sendEmailService: SendEmailService) {}

  @Post('/send-idea')
  async sendIdea(
      @Body() body: {recipientEmail: string, subject: string, text: string, ccEmails: string[]}

  ) {
      const { recipientEmail, subject, text, ccEmails } = body
      await this.sendEmailService.sendIdea(recipientEmail, subject, text, ccEmails);

     
      return {
        message: 'Email sent successfully',
        data: body
  }
}

@Get()
async getAllEmails() {
  const emails = await this.sendEmailService.getAllEmails();
  return {
    statusCode: HttpStatus.OK,
    message: 'Emails retrieved successfully',
    data: emails,
  };
}

@Get(':id')
async getEmailById(@Param('id') id: number) {
  const email = await this.sendEmailService.getEmailById(id);
  return {
    statusCode: HttpStatus.OK,
    message: `Email with ID ${id} retrieved successfully`,
    data: email,
  };
}

@Delete(':id')
async deleteEmail(@Param('id') id: number) {
  return await this.sendEmailService.deleteEmail(id);
}
}
