import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Cart } from './entities/cart.entity';
import { Repository } from 'typeorm';
import { CreateCartDto } from './dto/create-cart.dto';
import { UpdateCartDto } from './dto/update-cart.dto';
import { User } from 'src/users/entities/user.entity';
import { Products } from 'src/products/entities/product.entity';

@Injectable()
export class CartService {
  constructor(
    @InjectRepository(Cart)
    private readonly cartRepository: Repository<Cart>,

    @InjectRepository(User)
    private readonly userRepository: Repository<User>,

    @InjectRepository(Products)
    private readonly productRepository: Repository<Products>,
  ) {}

  async create(createCartDto: CreateCartDto): Promise<Cart> {
    const user = await this.userRepository.findOne({ where: { id: createCartDto.user } });
    const product = await this.productRepository.findOne({ where: { id: createCartDto.product } });

    if (!user || !product) {
      throw new NotFoundException('User or Product not found');
    }

    const cart = this.cartRepository.create({
      quantity: createCartDto.quantity,
      totalPrice: createCartDto.totalPrice,
      totalOrderPrice: createCartDto.totalOrderPrice,
      user,
      product,
    });

    return this.cartRepository.save(cart);
  }

  async findAll(): Promise<Cart[]> {
    return this.cartRepository.find({ relations: ['user', 'product'] });
  }

  async findOne(id: number): Promise<Cart> {
    return this.cartRepository.findOne({
      where: { id },
      relations: ['user', 'product'],
    });
  }

  async update(id: number, updateCartDto: UpdateCartDto): Promise<Cart> {
    const cart = await this.cartRepository.findOne({ where: { id } });
    if (!cart) throw new NotFoundException('Cart not found');

    if (updateCartDto.user) {
      const user = await this.userRepository.findOne({ where: { id: updateCartDto.user } });
      if (!user) throw new NotFoundException('User not found');
      cart.user = user;
    }

    if (updateCartDto.product) {
      const product = await this.productRepository.findOne({ where: { id: updateCartDto.product } });
      if (!product) throw new NotFoundException('Product not found');
      cart.product = product;
    }

    cart.quantity = updateCartDto.quantity ?? cart.quantity;
    cart.totalPrice = updateCartDto.totalPrice ?? cart.totalPrice;
    cart.totalOrderPrice = updateCartDto.totalOrderPrice ?? cart.totalOrderPrice;

    return this.cartRepository.save(cart);
  }

  async remove(id: number): Promise<void> {
    await this.cartRepository.delete(id);
  }
}
