import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Delete,
  Put,
  ParseIntPipe,
} from '@nestjs/common';
import { CartService } from './cart.service';
import { CreateCartDto } from './dto/create-cart.dto';
import { UpdateCartDto } from './dto/update-cart.dto';

@Controller('cart')
export class CartController {
  constructor(private readonly cartService: CartService) {}

  // Create a new cart entry
  @Post()
  async create(@Body() createCartDto: CreateCartDto) {
    return this.cartService.create(createCartDto);
  }

  // Get all cart items
  @Get()
  async findAll() {
    return this.cartService.findAll();
  }

  // Get a specific cart item by ID
  @Get(':id')
  async findOne(@Param('id', ParseIntPipe) id: number) {
    return this.cartService.findOne(id);
  }

  // Update a cart item
  @Put(':id')
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateCartDto: UpdateCartDto,
  ) {
    return this.cartService.update(id, updateCartDto);
  }

  // Delete a cart item
  @Delete(':id')
  async remove(@Param('id', ParseIntPipe) id: number) {
    return this.cartService.remove(id);
  }
}
