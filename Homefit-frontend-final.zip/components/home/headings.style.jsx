import { COLORS, SIZES } from "../../assets/constants";
import { StyleSheet} from "react-native";
    const styles = StyleSheet.create({
    container: {
      marginTop: SIZES.xsmall,
      marginHorizontal: 14
    },
    header: {
        flexDirection: "row",
        
        justifyContent: "space-between"
    },
    headerTitle: {
        fontFamily: "semiBold",
        fontSize: SIZES.xLarge -2,
       
    }
})

export default styles