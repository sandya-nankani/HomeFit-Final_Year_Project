import { StyleSheet, Text, View, Image} from 'react-native'
import React from 'react'
import Swiper from 'react-native-swiper'
import { COLORS } from '../../assets/constants'

// const Carousel = () => {
//         const slides = [
//             require('../../assets/images/living-room.jpg'),
//             require('../../assets/images/living_room2.jpg'),
//             require('../../assets/images/tv_lounge.jpg')
//         ]
//         const renderItem = ({ item }) => (
//             <Image source={item} style={styles.image} resizeMode="cover" />
//           );
//   return (
//     <View style={styles.carouselContainer}>
//         <Carousel images={slides}
//         dotColor= {COLORS.primary}
//         inactiveDotColor={COLORS.secondary}
//         ImageComponentStyle = {{borderRadius: 15, width: "95%", marginTop: 15}}
//       />
//     </View>
//   )
// }

// export default Carousel

const MySwiper = () => {
    return (
      <View style={styles.wrapper}>
        <Swiper 
          autoplay={true} showsPagination={true}
        dotColor= {COLORS.white} activeDotColor={COLORS.primary}
        >
          <Image style={styles.image} source={require('../../assets/images/living-room.jpg')} />
          <Image style={styles.image} source={require('../../assets/images/living_room2.jpg')} />
          <Image style={styles.image} source={require('../../assets/images/tv_lounge.jpg')} />
        </Swiper>
      </View>
    );
  };

export default MySwiper

const styles = StyleSheet.create({
    // carouselContainer: {
    //     flex: 1,
    //     alignItems: "center"
    // }
    wrapper: {
        height: 200,
        margin: 10,
        marginBottom: -5
        
        
      },
      image: {
        width: '100%',
        height: '100%',
        borderRadius: 15,
      },
})