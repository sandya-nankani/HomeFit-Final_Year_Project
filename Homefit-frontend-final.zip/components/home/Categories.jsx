// components/home/Categories.js
import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { SIZES, COLORS } from '../../assets/constants';
import { useNavigation } from '@react-navigation/native';


const arrayBufferToBase64 = (buffer) => {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};

const getImageUriFromByteArray = (byteArray) => {
  if (!byteArray || !Array.isArray(byteArray)) return null;
  const base64String = arrayBufferToBase64(byteArray);
  return `data:image/jpeg;base64,${base64String}`;
};

const Categories = ({ selectedCategoryId, onSelectCategory }) => {
  const [categories, setCategories] = useState([]);


  
  useEffect(() => {
    
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await fetch('http://172.16.150.254:3000/categories');
      const data = await response.json();
      // setCategories(data);
      setCategories(data);

    } catch (error) {
      // console.error('Failed to fetch categories:', error);
    }
  };

  const renderItem = ({ item }) => {
    let imageUri = null;

    if (item.image?.data && Array.isArray(item.image.data)) {
      imageUri = getImageUriFromByteArray(item.image.data);
    } else if (typeof item.image === 'string') {
      imageUri = item.image;
    }

    return (
      <TouchableOpacity style={styles.categoryItem}
         onPress={() => {
  onSelectCategory(item.id , item.name);
}}
        >
          {imageUri && (
          <Image source={{ uri: imageUri }} style={styles.categoryImage} 
         />
          
        )}
        <Text style={styles.categoryText}>{item.name}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={categories}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id?.toString()}
        contentContainerStyle={{ columnGap: SIZES.medium }}
        renderItem={renderItem}
      />
    </View>
  );
};

export default Categories;



const styles = StyleSheet.create({
  selectedCategoryItem: {
  borderBottomWidth: 2,
  borderBottomColor: COLORS.primary,
  paddingBottom: 3,
},

  container: {
    marginVertical: 20,
    paddingHorizontal: SIZES.medium,
  },
  categoryItem: {
    alignItems: 'center',
  },
  categoryImage: {
    width: 65,
    height: 65,
    borderRadius: 45,
    backgroundColor: COLORS.lightGray,
    marginBottom: 6,
  },
  categoryText: {
    fontSize: 13,
    color: COLORS.black,
    textAlign: 'center',
  },
});










// // components/home/Categories.js
// import React, { useEffect, useState } from 'react';
// import { View, Text, FlatList, TouchableOpacity, Image, StyleSheet } from 'react-native';
// import { SIZES, COLORS } from '../../assets/constants';
// import { useNavigation } from '@react-navigation/native';


// const arrayBufferToBase64 = (buffer) => {
//   let binary = '';
//   const bytes = new Uint8Array(buffer);
//   for (let i = 0; i < bytes.byteLength; i++) {
//     binary += String.fromCharCode(bytes[i]);
//   }
//   return btoa(binary);
// };

// const getImageUriFromByteArray = (byteArray) => {
//   if (!byteArray || !Array.isArray(byteArray)) return null;
//   const base64String = arrayBufferToBase64(byteArray);
//   return `data:image/jpeg;base64,${base64String}`;
// };

// const Categories = ({ selectedCategory, onSelectCategory }) => {
//   const [categories, setCategories] = useState([]);
//   const navigation = useNavigation();

  
//   useEffect(() => {
//     fetchCategories();
//   }, []);

//   const fetchCategories = async () => {
//     try {
//       const response = await fetch('http://172.16.150.254:3000/categories');
//       const data = await response.json();
//       setCategories(data);
//     } catch (error) {
//       console.error('Failed to fetch categories:', error);
//     }
//   };

//   const renderItem = ({ item }) => {
//     let imageUri = null;

//     if (item.image?.data && Array.isArray(item.image.data)) {
//       imageUri = getImageUriFromByteArray(item.image.data);
//     } else if (typeof item.image === 'string') {
//       imageUri = item.image;
//     }

//     return (
//       <TouchableOpacity style={styles.categoryItem}
//           onPress={() => {
//           onSelectCategory(item.name === selectedCategory ? null : item.name); // toggle or select
//         }}
//         >
//           {imageUri && (
//           <Image source={{ uri: imageUri }} style={styles.categoryImage} 
//          />
          
//         )}
//         <Text style={styles.categoryText}>{item.name}</Text>
//       </TouchableOpacity>
//     );
//   };

//   return (
//     <View style={styles.container}>
//       <FlatList
//         data={categories}
//         horizontal
//         showsHorizontalScrollIndicator={false}
//         keyExtractor={(item) => item.id?.toString()}
//         contentContainerStyle={{ columnGap: SIZES.medium }}
//         renderItem={renderItem}
//       />
//     </View>
//   );
// };

// export default Categories;



// const styles = StyleSheet.create({
//   container: {
//     marginVertical: 20,
//     paddingHorizontal: SIZES.medium,
//   },
//   categoryItem: {
//     alignItems: 'center',
//   },
//   categoryImage: {
//     width: 65,
//     height: 65,
//     borderRadius: 45,
//     backgroundColor: COLORS.lightGray,
//     marginBottom: 6,
//   },
//   categoryText: {
//     fontSize: 13,
//     color: COLORS.black,
//     textAlign: 'center',
//   },
// });
