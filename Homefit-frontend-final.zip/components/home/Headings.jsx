




// import { StyleSheet, Text, TouchableOpacity, View } from 'react-native'
// import React from 'react'
// import { Ionicons } from '@expo/vector-icons'
// import { COLORS } from '../../assets/constants'
// import styles from './headings.style'

// const Headings = ({ title }) => {
//   return (
//     <View style={styles.container}>
//         <View style={styles.header}>
//             <Text style={styles.headerTitle}>{title}</Text>
//             <TouchableOpacity>
//                 <Ionicons name='grid' size={22} color={COLORS.primary}/>
//             </TouchableOpacity>
//         </View>
      
//     </View>
//   )
// }

// export default Headings











import { StyleSheet, Text, View, TouchableOpacity, Modal, FlatList, TouchableWithoutFeedback } from 'react-native';
import React, { useState } from 'react';
import { COLORS } from '../../assets/constants';
import styles from './headings.style';
import { Ionicons } from '@expo/vector-icons';

const Headings = ({ title, onFilterChange }) => {
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState('');

  const filters = [
    { label: 'DATE: Old to New', value: 'oldToNew' },
    { label: 'DATE: New to Old', value: 'newToOld' },
    { label: 'PRICE: Low to High', value: 'lowToHigh' },
    { label: 'PRICE: High to Low', value: 'highToLow' },
    { label: 'ALPHABETICAL: A-Z/a-z', value: 'A-Z/a-z' },
     { label: 'ALPHABETICAL: Z-A/z-a', value: 'Z-A/z-a' },
  ];

  const handleSelect = (value) => {
    setSelectedFilter(value);
    onFilterChange?.(value);
    setModalVisible(false);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{title}</Text>

        {/* Sort Button */}
        {/* <TouchableOpacity
          style={localStyles.sortButton}
          onPress={() => setModalVisible(true)}
        >
          <Text style={localStyles.sortText}>
            {selectedFilter
              ? filters.find(f => f.value === selectedFilter)?.label
              : 'Sort By:'}
          </Text>
        </TouchableOpacity> */}



         <TouchableOpacity
  style={localStyles.sortButton}
  onPress={() => setModalVisible(true)}
>
  <Text style={localStyles.sortText}>
    {selectedFilter
      ? filters.find(f => f.value === selectedFilter)?.label
      : 'Sort By:'}
  </Text>

  {!selectedFilter && (
    <Ionicons
      name="grid"
      size={18}
      color={COLORS.white}
      style={{ marginLeft: 6 }}
    />
  )}
</TouchableOpacity>



        {/* <TouchableOpacity
  style={localStyles.sortButton}
  onPress={() => setModalVisible(true)}
  activeOpacity={0.7}
>
  
  <Text style={localStyles.sortText}>
    {selectedFilter
      ? filters.find(f => f.value === selectedFilter)?.label
      : 'Sort By:'}
  </Text>
  <Ionicons name="grid" size={18} color={COLORS.primary} style={{ marginLeft: 6 }} />
</TouchableOpacity> */}





      </View>

      {/* Modal */}
      <Modal
        visible={modalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setModalVisible(false)}
      >
        <TouchableWithoutFeedback onPress={() => setModalVisible(false)}>
          <View style={localStyles.modalBackground}>
            <TouchableWithoutFeedback>
              <View style={localStyles.modalContent}>
                <Text style={localStyles.modalTitle}>Sort By</Text>
                <FlatList
                  data={filters}
                  keyExtractor={(item) => item.value}
                  renderItem={({ item }) => (
                    <TouchableOpacity
                      style={localStyles.option}
                      onPress={() => handleSelect(item.value)}
                    >
                      <Text style={localStyles.optionText}>{item.label}</Text>
                    </TouchableOpacity>
                  )}
                />
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </View>
  );
};

const localStyles = StyleSheet.create({
  // sortButton: {
  //   paddingHorizontal: 12,
  //   paddingVertical: 5,
  //   borderWidth: 1,
  //   borderColor: COLORS.primary,
  //   borderRadius: 5,
  //   marginBottom: 5,
  //   marginRight: 2
  // },
  // sortText: {
  //   fontWeight: 600,
  //   fontSize: 16,
  //   color: COLORS.primary,
  // },

  sortButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: COLORS.primary,
    marginBottom: 5,
     marginRight: 2
  },
  sortText: {
    fontSize: 16,
    fontWeight: '500',
    color: COLORS.white,
  },

  modalBackground: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    width: 250,
    borderRadius: 10,
    padding: 15,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: COLORS.primary  
  },
  option: {
    paddingVertical: 10,
  },
  optionText: {
    fontSize: 16,
  },
});

export default Headings;
