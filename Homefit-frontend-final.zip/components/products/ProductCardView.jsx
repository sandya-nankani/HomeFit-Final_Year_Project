

import { StyleSheet, Text, View, TouchableOpacity, Image, Alert } from 'react-native';
import React from 'react';
import styles from './productCardView.style';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../../assets/constants';
import { useNavigation } from '@react-navigation/native';
import base64 from 'react-native-base64';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import ThreeDModelViewer from '../ThreeDModelViewer'; // ✅ 3D Viewer Import

const arrayBufferToBase64 = (buffer) => {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return base64.encode(binary);
};




const getImageUriFromByteArray = (byteArray) => {
  if (!byteArray) return null;

  let arr = null;
  if (Array.isArray(byteArray)) {
    arr = byteArray;
  } else if (byteArray.data && Array.isArray(byteArray.data)) {
    arr = byteArray.data;
  } else {
    return null;
  }

  const base64String = arrayBufferToBase64(arr); // ✅ fix here
  return `data:image/jpeg;base64,${base64String}`;
};


const ProductCardView = ({ product }) => {
  const navigation = useNavigation();

  // const imageData = product.image?.data || product.image;
  // const imageUrl = getImageUriFromByteArray(imageData);

  const imageData = product.image?.data || product.image;
const imageUrl = getImageUriFromByteArray(imageData);
console.log("📦 Product fileType:", product.fileType);


  const addToCart = async (product) => {
    try {
      const userData = await AsyncStorage.getItem('user');
      if (!userData) {
        console.error('🛑 User not found in storage');
        return;
      }

      const user = JSON.parse(userData);
      const userId = user.id;
      const quantity = 1;

      const response = await axios.post('http://172.16.150.254:3000/cart/add', {
        user: userId,
        product: product.id,
        quantity,
      });

      Alert.alert('Success', '✅ Product added to cart successfully!');
      console.log('✅ Added to cart:', response.data);
    } catch (err) {
      // Alert.alert('Error', '🛑 Failed to add product to cart');
      console.log(err)
    }
  };

  return (
    <TouchableOpacity onPress={() => navigation.navigate("ProductDetails", { product })}>
      <View style={styles.container}>
        <View style={styles.imageContainer}>

        
   { imageUrl && <Image source={{ uri: imageUrl }} style={styles.productImage} />
  
  }
        </View>

        <View style={styles.details}>
          <Text style={styles.title} numberOfLines={1}>{product?.title}</Text>
          <Text style={styles.description} numberOfLines={1}>{product?.description || ''}</Text>
          <Text style={styles.price}>Rs. {product.price.toLocaleString() || ''}</Text>
        </View>

        <TouchableOpacity style={styles.addBtn} onPress={() => addToCart(product)}>
          <Ionicons name="add-circle" size={33} color={COLORS.primary} />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
};

export default ProductCardView;
