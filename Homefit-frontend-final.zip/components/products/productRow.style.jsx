import { StyleSheet } from "react-native";
import {COLORS, SIZES} from "../../assets/constants"