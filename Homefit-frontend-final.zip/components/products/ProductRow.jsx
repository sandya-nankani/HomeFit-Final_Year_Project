

// import React, { useEffect, useState } from 'react';
// import {
//   View,
//   FlatList,
//   ActivityIndicator,
//   StyleSheet,
//   Dimensions,
// } from 'react-native';
// import ProductCardView from './ProductCardView';
// import { SIZES } from '../../assets/constants';

// const Products = ({ selectedCategory }) => {
//   const [products, setProducts] = useState([]);
//   const [loading, setLoading] = useState(true);

//   const fetchProducts = async () => {
//     try {
//       const response = await fetch('http://172.16.150.254:3000/products');
//       const data = await response.json();
//       setProducts(data.products || data); // Handles both `{ products: [...] }` and raw array
    
     

//     } catch (error) {
//       // console.error('Failed to fetch products:', error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchProducts();
//   }, []);


//    const filteredProducts = selectedCategory
//     ? products.filter((product) => product.category?.toLowerCase() === selectedCategory.toLowerCase())
//     : products;


//   if (loading) {  
//     return (
//       <View style={styles.loading}>
//         <ActivityIndicator size="large" color="#0000ff" />
//       </View>
//     );
//   }
  
//   return (
//     <FlatList
//       data={products}
//       keyExtractor={(item) => item.id.toString()}
//       renderItem={({ item }) => <ProductCardView product={item} />}
//       numColumns={2}
//       contentContainerStyle={styles.listContainer}
//       columnWrapperStyle={styles.columnWrapper}
//       showsVerticalScrollIndicator={false}
//     />
//   );
// };

// const styles = StyleSheet.create({
//   loading: {
//     flex: 1,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   listContainer: {
//     paddingBottom: 50,
//     gap: SIZES.medium,
//     paddingHorizontal: SIZES.medium,
//   },
//   columnWrapper: {
//     justifyContent: 'space-between',
//     marginBottom: SIZES.medium,
//   },
// });

// export default Products;






import React, { useEffect, useState, useMemo } from 'react';
import {
  View,
  FlatList,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';
import ProductCardView from './ProductCardView';
import { SIZES } from '../../assets/constants';

const Products = ({ selectedCategory, sortOption }) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchProducts = async () => {
    try {
      const response = await fetch('http://172.16.150.254:3000/products');
      const data = await response.json();
       
  //     setProducts(data.products || data);
    

  //   } catch (error) {
  //     // console.error('Failed to fetch products:', error);
  //   } finally {
  //     setLoading(false);
  //   }
  // };


   // 🔹 Add fileType dynamically
     const productsWithFileType = (data.products || data).map(p => {
  // Some backends wrap the image in { data: [...] } or might use null
  const hasModel = p.modelPath && p.modelPath.length > 0;
  const hasImage = p.image && (Array.isArray(p.image) ? p.image.length > 0 : true);

  return {
    ...p,
    fileType: hasModel ? '3d' : hasImage ? 'image' : null,
  };
});


      setProducts(productsWithFileType);
    } catch (error) {
      console.error('Failed to fetch products:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);





  // 🔹 Filter + Sort together
  const processedProducts = useMemo(() => {
  let filtered = selectedCategory
    ? products.filter(
        (p) => p.category?.toLowerCase() === selectedCategory.toLowerCase()
      )
    : [...products];

  let sorted = [...filtered]; // 🔹 Make a fresh copy before sorting
switch (sortOption) {
  case 'oldToNew':
    sorted.sort((a, b) => new Date(a.createdAt || 0) - new Date(b.createdAt || 0));
    break;
  case 'newToOld':
    sorted.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    break;
  case 'lowToHigh':
    sorted.sort((a, b) => 
      parseFloat(a.price?.toString().replace(/[^0-9.]/g, '') || 0) -
      parseFloat(b.price?.toString().replace(/[^0-9.]/g, '') || 0)
    );
    break;
  case 'highToLow':
    sorted.sort((a, b) => 
      parseFloat(b.price?.toString().replace(/[^0-9.]/g, '') || 0) -
      parseFloat(a.price?.toString().replace(/[^0-9.]/g, '') || 0)
    );
    break;
  case 'A-Z/a-z':
    sorted.sort((a, b) => a.title?.localeCompare(b.title || '') || 0);
    break;
  case 'Z-A/z-a':
    sorted.sort((a, b) => b.title?.localeCompare(a.title || '') || 0);
    break;
}


  return sorted;
}, [products, selectedCategory, sortOption]);





  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  return (
    <FlatList
      data={processedProducts}
      keyExtractor={(item) => item.id.toString()}
      renderItem={({ item }) => <ProductCardView product={item} />}
      numColumns={2}
      contentContainerStyle={styles.listContainer}
      columnWrapperStyle={styles.columnWrapper}
      showsVerticalScrollIndicator={false}
    />
  );
};

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContainer: {
    paddingBottom: 50,
    gap: SIZES.medium,
    paddingHorizontal: SIZES.medium,
  },
  columnWrapper: {
    justifyContent: 'space-between',
    marginBottom: SIZES.medium,
  },
});

export default Products;
