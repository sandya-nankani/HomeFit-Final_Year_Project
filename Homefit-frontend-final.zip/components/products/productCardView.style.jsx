import { StyleSheet } from "react-native";
import {COLORS, SIZES} from "../../assets/constants";


const styles = StyleSheet.create({
    container: {
        width: 160,
        height: 230,
        marginLeft: 10,
        marginEnd: 5,
        borderRadius: SIZES.large-4,
        backgroundColor: COLORS.secondary
    },

    imageContainer: {
        flex: 1,
        marginLeft:15,
       
        // marginRight: SIZES.xSmall/5,
        marginTop: SIZES.small/2,
        borderRadius: SIZES.small,
        overflow: "hidden",  
    },
    
    productImage: {
    // marginLeft: SIZES.xSmall/1.5,
    // marginRight: SIZES.xSmall/1.5,
    width: '100%',
    height: '100%',
   borderRadius: SIZES.large-4,
    aspectRatio: 1,
   resizeMode: 'cover',
},
    image:{
        height: '100%',
        width: '100%',
        aspectRatio: 1,
        resizeMode:"cover",
        borderRadius: SIZES.small,
        
    },
    details:{
        padding: SIZES.small,
        
    },
    title: {
        fontFamily: "bold",
        fontSize: SIZES.large -2,
        marginBottom: 2
    },
    description: {
        fontFamily: "regular",
        fontSize: SIZES.small,
       color: COLORS.gray
    },
    price: {
        fontFamily: "bold",
        fontSize: SIZES.medium,
        top: 5
        
    },
    addBtn: {
        position: "absolute",
        bottom: SIZES.xSmall-7,
        right: SIZES.xSmall
    }
})


export default styles;