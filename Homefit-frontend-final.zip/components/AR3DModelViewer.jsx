import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Image,
} from 'react-native';
import { Ionicons, MaterialIcons, FontAwesome } from '@expo/vector-icons';
import { COLORS } from '../assets/constants';

const { width, height } = Dimensions.get('window');

const AR3DModelViewer = ({ product, onClose, onPlaceObject }) => {
  const [scale, setScale] = useState(1);
  const [rotation, setRotation] = useState(0);

  const getImageUriFromByteArray = (byteArray) => {
    if (!byteArray || !Array.isArray(byteArray)) return null;
    const arrayBufferToBase64 = (buffer) => {
      let binary = '';
      const bytes = new Uint8Array(buffer);
      for (let i = 0; i < bytes.byteLength; i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      return btoa(binary);
    };
    const base64String = arrayBufferToBase64(byteArray);
    return `data:image/jpeg;base64,${base64String}`;
  };

  const imageUri = product?.image?.data
    ? getImageUriFromByteArray(product.image.data)
    : typeof product.image === 'string'
    ? product.image
    : null;

  const handleScale = (direction) => {
    if (direction === 'up') {
      setScale(prev => Math.min(prev + 0.1, 3));
    } else {
      setScale(prev => Math.max(prev - 0.1, 0.5));
    }
  };

  const handleRotate = (direction) => {
    if (direction === 'left') {
      setRotation(prev => prev - 15);
    } else {
      setRotation(prev => prev + 15);
    }
  };

  const handlePlaceObject = () => {
    onPlaceObject && onPlaceObject();
  };

  const handleReset = () => {
    setScale(1);
    setRotation(0);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>3D Model Viewer</Text>
        <TouchableOpacity style={styles.closeButton} onPress={onClose}>
          <Ionicons name="close" size={24} color="white" />
        </TouchableOpacity>
      </View>

      {/* 3D Model Display Area */}
      <View style={styles.modelContainer}>
        <View
          style={[
            styles.modelView,
            {
              transform: [
                { scale: scale },
                { rotate: `${rotation}deg` }
              ],
            },
          ]}
        >
          {/* 3D Model Representation */}
          <View style={styles.modelBox}>
            {imageUri && (
              <Image source={{ uri: imageUri }} style={styles.modelImage} />
            )}
            <View style={styles.modelInfo}>
              <Text style={styles.modelTitle} numberOfLines={2}>
                {product?.title || 'Product'}
              </Text>
              <Text style={styles.modelPrice}>
                Rs. {product?.price?.toLocaleString() || ''}
              </Text>
            </View>
          </View>
        </View>
      </View>

      {/* Controls */}
      <View style={styles.controlsContainer}>
        {/* Scale Controls */}
        <View style={styles.controlSection}>
          <Text style={styles.controlTitle}>Scale</Text>
          <View style={styles.controlRow}>
            <TouchableOpacity
              style={styles.controlButton}
              onPress={() => handleScale('down')}
            >
              <FontAwesome name="minus" size={20} color="white" />
            </TouchableOpacity>
            <Text style={styles.controlValue}>{scale.toFixed(1)}x</Text>
            <TouchableOpacity
              style={styles.controlButton}
              onPress={() => handleScale('up')}
            >
              <FontAwesome name="plus" size={20} color="white" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Rotation Controls */}
        <View style={styles.controlSection}>
          <Text style={styles.controlTitle}>Rotation</Text>
          <View style={styles.controlRow}>
            <TouchableOpacity
              style={styles.controlButton}
              onPress={() => handleRotate('left')}
            >
              <Ionicons name="rotate-left" size={20} color="white" />
            </TouchableOpacity>
            <Text style={styles.controlValue}>{rotation}°</Text>
            <TouchableOpacity
              style={styles.controlButton}
              onPress={() => handleRotate('right')}
            >
              <Ionicons name="rotate-right" size={20} color="white" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={styles.placeButton}
            onPress={handlePlaceObject}
          >
            <MaterialIcons name="place" size={24} color="white" />
            <Text style={styles.placeButtonText}>Place in AR</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.resetButton}
            onPress={handleReset}
          >
            <Ionicons name="refresh" size={24} color="white" />
            <Text style={styles.resetButtonText}>Reset</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Instructions */}
      <View style={styles.instructions}>
        <Text style={styles.instructionText}>
          Adjust the product size and rotation, then place it in AR space.
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 40,
  },
  headerTitle: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  closeButton: {
    backgroundColor: '#F44336',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modelContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modelView: {
    alignItems: 'center',
  },
  modelBox: {
    width: 150,
    height: 150,
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 15,
    padding: 15,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,
    elevation: 8,
  },
  modelImage: {
    width: 80,
    height: 80,
    borderRadius: 10,
    marginBottom: 10,
  },
  modelInfo: {
    alignItems: 'center',
  },
  modelTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    color: COLORS.primary,
    textAlign: 'center',
    marginBottom: 5,
  },
  modelPrice: {
    fontSize: 10,
    color: COLORS.gray,
    fontWeight: 'bold',
  },
  controlsContainer: {
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    padding: 20,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  controlSection: {
    marginBottom: 20,
  },
  controlTitle: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  controlRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  controlButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 10,
  },
  controlValue: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    minWidth: 50,
    textAlign: 'center',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    marginTop: 20,
  },
  placeButton: {
    backgroundColor: '#4CAF50',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 25,
  },
  placeButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  resetButton: {
    backgroundColor: '#FF9800',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 25,
  },
  resetButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  instructions: {
    padding: 20,
    alignItems: 'center',
  },
  instructionText: {
    color: 'white',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});

export default AR3DModelViewer; 