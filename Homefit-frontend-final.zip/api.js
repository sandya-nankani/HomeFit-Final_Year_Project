import axios from "axios";
const API_URL = 'http://172.16.150.254:3000';

export const apiClient = axios.create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json',
    }
});
