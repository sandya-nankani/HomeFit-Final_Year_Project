
import { COLORS,  SIZES, images, SHADOWS} from "./theme";

export { COLORS,  SIZES, images, SHADOWS};
