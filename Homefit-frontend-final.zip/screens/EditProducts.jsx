import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, Image, Alert,
  TouchableOpacity, StyleSheet, Button
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Picker } from '@react-native-picker/picker';
import base64 from 'react-native-base64';
import { useIsFocused } from '@react-navigation/native';

const arrayBufferToBase64 = (buffer) => {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return base64.encode(binary);
};

const getImageUriFromByteArray = (byteArray) => {
  if (!byteArray || !Array.isArray(byteArray)) return null;
  const base64String = arrayBufferToBase64(byteArray);
  return `data:image/jpeg;base64,${base64String}`;
};

const EditProducts = ({ route, navigation }) => {
  const { id } = route.params;
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [description, setDescription] = useState('');
  const [stock, setStock] = useState('');
  const [categories, setCategories] = useState([]);
  const [categoryId, setCategoryId] = useState('');
  const [imageUri, setImageUri] = useState(null);
  const [newImage, setNewImage] = useState(null);
   const isFocused = useIsFocused();

  useEffect(() => {
    if (isFocused) {
    fetchProduct();
    fetchCategories();
  }
 }, [isFocused] );

  const fetchProduct = async () => {
    try {
      const response = await fetch(`http://172.16.150.254:3000/products/${id}`);
      const data = await response.json();

      setTitle(data.title);
      setPrice(data.price.toString());
      setDescription(data.description);
      setStock(data.stock.toString());
      setCategoryId(data.category?.id || '');

      
      const img = data.image?.data || data.image;
      const uri = getImageUriFromByteArray(img);
      setImageUri(uri);
    } catch (err) {
      console.error('Failed to fetch product:', err);
      Alert.alert('Error', 'Unable to load product');
      navigation.goBack();
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await fetch('http://172.16.150.254:3000/categories');
      const data = await response.json();
      setCategories(data);
    } catch (err) {
      console.error('Failed to fetch categories:', err);
      Alert.alert('Error', 'Unable to load categories');
    }
  };

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 1,
    });

    if (!result.canceled && result.assets?.length > 0) {
      setNewImage(result.assets[0]);
      setImageUri(result.assets[0].uri);
    }
  };

  const handleUpdate = async () => {
    if (!title || !price || !description || !stock || !categoryId) {
      alert('Please fill in all required fields.');
      return;
    }

    const formData = new FormData();
    formData.append('title', title);
    formData.append('price', price);
    formData.append('description', description);
    formData.append('stock', stock);
    formData.append('categoryId', categoryId);

    if (newImage) {
      formData.append('file', {
        uri: newImage.uri,
        name: `${Date.now()}.jpg`,
        type: 'image/jpeg',
      });
    }

    try {
      const response = await fetch(`http://172.16.150.254:3000/products/update/${id}`, {
        method: 'PATCH',
        body: formData,
      });

      const result = await response.json();
      if (!response.ok) {
        const errorText = await response.text();
  throw new Error(errorText || 'Failed to update product');
      }

      alert('✅ Product updated successfully!');
    } catch (error) {
      console.error('Update failed:', error);
      alert('❌ Failed to update product.');
    }
    navigation.navigate('ManageProducts', { refresh: true });
  };


  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Edit Product</Text>

      <TextInput
        value={title}
        onChangeText={setTitle}
        placeholder="Product name"
        style={styles.input}
      />
      <TextInput
        value={price}
        onChangeText={setPrice}
        placeholder="Price"
        keyboardType="numeric"
        style={styles.input}
      />
      <TextInput
        value={description}
        onChangeText={setDescription}
        placeholder="Description"
        style={styles.input}
      />
      <TextInput
        value={stock}
        onChangeText={setStock}
        placeholder="Stock"
        keyboardType="numeric"
        style={styles.input}
      />

      <View style={styles.input}>
        <Picker
          selectedValue={categoryId}
          onValueChange={(itemValue) => setCategoryId(itemValue)}
        >
          <Picker.Item label="Select Category" value="" />
          {categories.map((cat) => (
            <Picker.Item label={cat.name} value={cat.id} key={cat.id} />
          ))}
        </Picker>
      </View>

      <TouchableOpacity onPress={pickImage} style={styles.imageButton}>
        <Text style={styles.imageButtonText}>Pick Image</Text>
      </TouchableOpacity>

      {imageUri && (
        <Image
          source={{ uri: imageUri }}
          style={{ width: 100, height: 100, marginBottom: 10 }}
        />
      )}

      <Button title="Update Product" onPress={handleUpdate} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#fff',
    flex: 1
  },
  heading: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    borderRadius: 8,
    marginBottom: 12
  },
  imageButton: {
    backgroundColor: '#3498db',
    padding: 10,
    borderRadius: 8,
    marginBottom: 10
  },
  imageButtonText: {
    color: '#fff',
    textAlign: 'center'
  },
});

export default EditProducts;
