
import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  TouchableOpacity,
  Alert,
  ScrollView,
} from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { COLORS, SIZES } from '../assets/constants';
import { Ionicons } from '@expo/vector-icons';
import BackBtn from '../components/BackBtn';

const getImageUriFromByteArray = (byteArray) => {
  if (!byteArray || !Array.isArray(byteArray)) return null;
  const base64String = btoa(
    byteArray.map((byte) => String.fromCharCode(byte)).join('')
  );
  return `data:image/jpeg;base64,${base64String}`;
};

const CartScreen = ({ navigation }) => {
  const [cartItems, setCartItems] = useState([]);

  const fetchCartItems = async () => {
    try {
      const userData = await AsyncStorage.getItem('user');
      if (!userData) return;

      const user = JSON.parse(userData);
      const response = await axios.get(
        `http://172.16.150.254:3000/cart/user/${user.id}`
      );
      setCartItems(response.data || []);
    } catch (error) {
      // console.error('🛑 Error fetching cart items:', error.message);
    }
  };

  useEffect(() => {
    fetchCartItems();
  }, []);


  const updateQuantity = async (cartItemId, type) => {
  try {
    const endpoint = `http://172.16.150.254:3000/cart/${cartItemId}/${type}`;
    await axios.patch(endpoint);
    fetchCartItems(); // Refresh cart
  } catch (error) {
    // console.error(`Error updating quantity:`, error.response?.data || error.message);
    Alert.alert('Product quantity cannot be less than 1')
  }
};


  const handleDelete = async (cartItemId) => {
  try {
    await axios.delete(`http://172.16.150.254:3000/cart/${cartItemId}`);
    // Remove item from state
    setCartItems(prev => prev.filter(item => item.id !== cartItemId));
  } catch (error) {
    // console.error('🛑 Error deleting cart item:', error.response?.data || error.message);
    // Alert.alert('Error', 'Failed to delete item from cart.');
  }
};



  const totalPrice = cartItems.reduce(
    (total, item) => total + item.quantity * item.product.price,
    0
  );

  const renderItem = ({ item }) => {
    const imageData = item.product.image?.data;
    const imageUrl = imageData ? getImageUriFromByteArray(imageData) : null;

    return (
      <View style={styles.card}>
        {imageUrl && (
          <Image source={{ uri: imageUrl }} style={styles.image} resizeMode="cover" />
        )}
        <View style={styles.info}>
          <Text style={styles.title}>{item.product.title}</Text>
          <Text style={styles.price}>Rs. {item.product.price.toLocaleString()}</Text>
          <View style={styles.quantityRow}>
  <TouchableOpacity
    style={styles.qtyBtn}
    onPress={() => updateQuantity(item.id, 'decrease')}
  >
    <Ionicons name="remove" size={20} />
  </TouchableOpacity>
  <Text style={styles.quantityText}>{item.quantity}</Text>
  <TouchableOpacity
    style={styles.qtyBtn}
    onPress={() => updateQuantity(item.id, 'increase')}
  >
    <Ionicons name="add" size={20} />
  </TouchableOpacity>
    </View>
        </View>
        <TouchableOpacity style={styles.deleteBtn} onPress={() => handleDelete(item.id)}>
          <Ionicons name="trash" size={20} color="red" />
          </TouchableOpacity>
      </View>
    );
  };

  if (cartItems.length === 0) {
    return (
      <View style={styles.emptyContainer}>
         <View style={styles.backButtonContainer}>
        <BackBtn onPress={() => navigation.goBack()} />
      
        
          </View>
        <Image
          source={require('../assets/images/empty-cart1.jpg')}
          style={{
            height: SIZES.height / 3,
            width: SIZES.width - 60,
            resizeMode: 'contain',
            marginBottom: SIZES.xxLarge,
          }}
        />
        <Text style={styles.emptyTitle}>Your cart is empty</Text>
        <Text style={styles.emptySubtitle}>
          Looks like you haven’t added anything to your cart yet.
        </Text>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Home')}
        >
          <Text style={styles.buttonText}>Shop Now</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <BackBtn onPress={() => navigation.goBack()} />
        <Text style={styles.heading}>Items in Cart</Text>
      </View>

      <FlatList
        data={cartItems}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={{ paddingBottom: 120 }}
      />

      <View style={styles.footer}>
        <View>
          <Text style={styles.totalText}>Total:</Text>
          <Text style={styles.totalPrice}>Rs. {totalPrice.toLocaleString()}</Text>

        </View>
        <TouchableOpacity
  style={styles.checkoutBtn}
  onPress={() => navigation.navigate('CheckoutScreen', { products: cartItems })}
>
  <Text style={styles.checkoutText}>Checkout</Text>
</TouchableOpacity>
      </View>
    </View>
  );
};

export default CartScreen;

// 🖌️ Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  backButtonContainer: {
    position: 'absolute',
    top: 40, // adjust based on safe area
    left: 15,
    zIndex: 1,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    marginTop: 40,
    marginBottom: 10,
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginLeft: 95,
  },
  card: {
    flexDirection: 'row',
    backgroundColor: '#f8f8f8',
    padding: 10,
    borderRadius: 12,
    marginHorizontal: 10,
    marginBottom: 12,
    alignItems: 'center',
    elevation: 2,
  },
  image: {
    width: 70,
    height: 70,
    borderRadius: 10,
    marginRight: 15,
  },
  info: {
    flex: 1,
    justifyContent: 'center',
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  price: {
    color: COLORS.gray,
    marginBottom: 8,
  },
  quantityRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  qtyBtn: {
    backgroundColor: '#ddd',
    padding: 5,
    borderRadius: 5,
    marginHorizontal: 5,
  },
  quantityText: {
    fontSize: 16,
    fontWeight: '500',
  },
  deleteBtn: {
    paddingLeft: 10,
  },
  footer: {
    position: 'absolute',
    bottom: 90,
    width: '100%',
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderColor: '#ccc',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  totalText: {
    fontSize: 16,
    color: '#777',
  },
  totalPrice: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  checkoutBtn: {
    backgroundColor: COLORS.primary,
    paddingVertical: 10,
    paddingHorizontal: 25,
    borderRadius: 20,
  },
  checkoutText: {
    color: '#fff',
    fontWeight: 'bold',
  },

  // Empty cart styles
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  emptyTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 10,
    marginTop: -50,
  },
  emptySubtitle: {
    fontSize: 16,
    color: COLORS.gray || '#777',
    textAlign: 'center',
    marginBottom: 25,
  },
  button: {
    backgroundColor: COLORS.primary,
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 25,
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
  },
});


