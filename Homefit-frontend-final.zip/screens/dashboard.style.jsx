import { StyleSheet } from 'react-native';
import { COLORS, SIZES } from '../assets/constants';

export default StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: COLORS.white,
    flexGrow: 1,
  },
  header: {
    marginTop: SIZES.large,
    fontSize: 26,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 24,
    textAlign: 'center',
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.offwhite,
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    elevation: 2,
  },
  label: {
    fontSize: 18,
    marginLeft: 16,
    color: COLORS.black,
  },
});
