// import { ScrollView,  View, Text, Image, TextInput, TouchableOpacity, Alert } from 'react-native'
// import React, {useState, useRef} from 'react'
// import { SafeAreaView } from 'react-native-safe-area-context';
// import BackBtn from '../components/BackBtn';
// import styles from './login.style';
// import Button from '../components/Button';
// import * as Yup from "yup"
// import { MaterialCommunityIcons } from '@expo/vector-icons';
// import { COLORS, SIZES } from '../assets/constants';
// import { Formik } from 'formik';


// const validationSchema =  Yup.object().shape({
    
// });

// const SendOtp = ({navigation}) => {
//     const [otp, setOtp] = useState(["", "", "", ""]);
//     const inputRefs = [useRef(null), useRef(null), useRef(null), useRef(null)];

//     const handleOtpChange = (index, value) => {
//         if (/^\d$/.test(value) || value === "") {
//           const newOtp = [...otp];
//           newOtp[index] = value;
//           setOtp(newOtp);
    
//           // Move focus to the next input
//           if (value && index < 3) {
//             inputRefs[index + 1].current.focus();
//           }
//         }
//       };
    

//       const handleVerify = () => {
//         const enteredOtp = otp.join("");
//         if (enteredOtp.length < 4) {
//           Alert.alert("Invalid Code", "Please enter the complete OTP.");
//         } else if (enteredOtp !== sentOtp) {
//             Alert.alert("Error", "Incorrect OTP, please try again.");
//           } else {
//             Alert.alert("Success", "OTP verified successfully!");
//             navigation.navigate("NextScreen"); // Replace with actual next screen name
//           }
//     } 
        
      

//   return (
//     <ScrollView>
//         <SafeAreaView style={{marginHorizontal: 20}}>
//             <View>
//                 <BackBtn onPress={() => navigation.goBack()}/>
//                 <Image 
//                 source={require('../assets/images/bk.png')}
//                 style={{
//                     height: SIZES.height/3,
//                     width: SIZES.width-60,
//                     resizeMode: "contain",
//                     marginBottom: SIZES.xxLarge
//                 }}
//                 />
//              <Text style={{
//                 fontFamily: "bold",
//                 fontSize: SIZES.xLarge,
//                 color: COLORS.primary,
//                 alignItems: "center",
//                 marginBottom: SIZES.xSmall
//              }}
//              >Verification</Text> 
//              <Text style={{
//                 marginBottom: 35,
//                 fontSize: SIZES.medium}}>Enter the verification code we just sent you to your email address</Text>
        
//             <View> 
//             <View style={styles.otpContainer}>
//              {otp.map((digit, index) => (
//              <TextInput
//             key={index}
//             ref={inputRefs[index]}
//             style={styles.otpInput}
//             keyboardType="numeric"
//             maxLength={1}
//             value={digit}
//             onChangeText={(value) => handleOtpChange(index, value)}
//           />
//         ))}
//       </View>
//       {/* <TouchableOpacity onPress={() => Alert.alert("Code Resent","Check your email for a new code.")}> </TouchableOpacity>    */}
//       <TouchableOpacity onPress={() => Alert.alert("Code Resent", "Check your email for a new code.")}>
 
// </TouchableOpacity>


                 


               
//                 <Button title={"V E R I F Y"} onPress={() => navigation.navigate('ResetPassword')} />
                 
//                 {/* <Text style={styles.NoAccount}> Didn't receive the code?  
//                     <Text style={styles.registration} onPress={() => {}}>  Resend </Text>
//                 </Text> */}

//                 <View style={{ flexDirection: 'column' }}>
//                 <Text style={styles.NoAccount}>Didn't receive the code?</Text>
//              <Text style={styles.registration}>Resend</Text>
                
//                  </View>

                
//             </View> 
            
//             </View>
//         </SafeAreaView>
//     </ScrollView>
//   );
// }

// export default SendOtp;









import { ScrollView, View, Text, Image, TextInput, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import React, { useState, useRef } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import BackBtn from '../components/BackBtn';
import styles from './login.style';
import Button from '../components/Button';
import { COLORS, SIZES } from '../assets/constants';
import axios from 'axios';

const SendOtp = ({ navigation, route }) => {
  const { email, correctOtp, userId } = route.params || {}; // Get email and OTP sent from backend
  const [otp, setOtp] = useState(["", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const inputRefs = [useRef(null), useRef(null), useRef(null), useRef(null)];

  const handleOtpChange = (index, value) => {
    if (/^\d$/.test(value) || value === "") {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      if (value && index < 3) {
        inputRefs[index + 1].current.focus();
      }
    }
  };

  const handleVerify = () => {
    const enteredOtp = otp.join(""); // Combine OTP digits

    if (enteredOtp.length < 4) {
      Alert.alert("Invalid Code", "Please enter the complete OTP.");
      return;
    }
    console.log("entered otp:", enteredOtp)
    console.log("correct otp:", correctOtp)


    if (enteredOtp === correctOtp) {
      Alert.alert("Success", "OTP verified successfully!");
      navigation.navigate("ResetPassword", { email, userId});
      console.log('userid: ', userId)
    } else {
      Alert.alert("Error", "Incorrect OTP, please try again.");
    }
  };

  

  const handleResendOtp = async () => {
    setLoading(true);
    try {
      const response = await axios.post('http://172.16.150.254:3000/auth/sendOtp', { email });

      if (response.data.status === 200) {
        Alert.alert("Success", "OTP resent successfully!");
      } else {
        Alert.alert("Error", "Failed to resend OTP.");
      }
    } catch (error) {
      Alert.alert("Error", error.response?.data?.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView>
      <SafeAreaView style={{ marginHorizontal: 20 }}>
        <View>
          <BackBtn onPress={() => navigation.goBack()} />
          <Image
            source={require('../assets/images/bk.png')}
            style={{
              height: SIZES.height / 3,
              width: SIZES.width - 60,
              resizeMode: 'contain',
              marginBottom: SIZES.xxLarge,
            }}
          />
          <Text style={{ fontFamily: 'bold', fontSize: SIZES.xLarge, color: COLORS.primary, marginBottom: SIZES.xSmall }}>
            Verification
          </Text>
          <Text style={{ marginBottom: 35, fontSize: SIZES.medium }}>Enter the verification code sent to your email</Text>

          <View style={styles.otpContainer}>
            {otp.map((digit, index) => (
              <TextInput
                key={index}
                ref={inputRefs[index]}
                style={styles.otpInput}
                keyboardType="numeric"
                maxLength={1}
                value={digit}
                onChangeText={(value) => handleOtpChange(index, value)}
              />
            ))}
          </View>

          {loading ? (
            <ActivityIndicator size="large" color={COLORS.primary} />
          ) : (
            <Button title={"V E R I F Y"} onPress={handleVerify} />
          )}

          <View style={{ flexDirection: 'column', marginTop: 20 }}>
            <Text style={styles.NoAccount}>Didn't receive the code?</Text>
            <TouchableOpacity onPress={handleResendOtp}>
              <Text style={styles.registration}>Resend OTP</Text>
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    </ScrollView>
  );
};

export default SendOtp;
