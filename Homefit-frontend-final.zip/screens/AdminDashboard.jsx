import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { COLORS } from '../assets/constants';
import styles from './dashboard.style';

const DashboardOption = ({ icon, label, screen }) => {
  const navigation = useNavigation();

  return (
    <TouchableOpacity style={styles.card} onPress={() => navigation.navigate(screen)}>
      <Ionicons name={icon} size={30} color={COLORS.primary} />
      <Text style={styles.label}>{label}</Text>
    </TouchableOpacity>
  );
};

const AdminDashboard = () => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>Admin Dashboard</Text>

      <DashboardOption icon="cube-outline" label="Manage Products" screen="ManageProducts" />
      <DashboardOption icon="pricetags-outline" label="Manage Categories" screen="ManageCategories" />
      <DashboardOption icon="people-outline" label="Manage Users" screen="ManageUsers" />
      <DashboardOption icon="cart-outline" label="Manage Orders" screen="ManageOrders" />
    </ScrollView>
  );
};

export default AdminDashboard;
