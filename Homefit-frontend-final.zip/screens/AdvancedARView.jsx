// import React, { useState, useEffect, useRef } from 'react';
// import {
//   View,
//   Text,
//   TouchableOpacity,
//   StyleSheet,
//   Dimensions,
//   Alert,
//   Image,
//   SafeAreaView,
//   PanGestureHandler,
//   State,
// } from 'react-native';
// import { Camera } from 'expo-camera';
// import { Ionicons, MaterialIcons, FontAwesome } from '@expo/vector-icons';
// import { COLORS, SIZES } from '../assets/constants';
// import { GestureHandlerRootView } from 'react-native-gesture-handler';

// const { width, height } = Dimensions.get('window');

// const AdvancedARView = ({ navigation, route }) => {
//   const { product } = route.params;
//   const [hasPermission, setHasPermission] = useState(null);
//   const [cameraType, setCameraType] = useState('back');
//   const [flashMode, setFlashMode] = useState('off');
//   const [isARMode, setIsARMode] = useState(true);
//   const [arObjectPosition, setArObjectPosition] = useState({ x: width / 2, y: height / 2 });
//   const [arObjectScale, setArObjectScale] = useState(1);
//   const [arObjectRotation, setArObjectRotation] = useState(0);
//   const [isObjectPlaced, setIsObjectPlaced] = useState(false);
//   const cameraRef = useRef(null);

//   useEffect(() => {
//     (async () => {
//       const { status } = await Camera.requestCameraPermissionsAsync();
//       setHasPermission(status === 'granted');
//     })();
//   }, []);

//   const handleCameraPermission = () => {
//     if (hasPermission === null) {
//       return <View />;
//     }
//     if (hasPermission === false) {
//       return (
//         <View style={styles.permissionContainer}>
//           <Text style={styles.permissionText}>No access to camera</Text>
//           <TouchableOpacity
//             style={styles.permissionButton}
//             onPress={() => navigation.goBack()}
//           >
//             <Text style={styles.permissionButtonText}>Go Back</Text>
//           </TouchableOpacity>
//         </View>
//       );
//     }
//   };

//   const toggleCameraType = () => {
//     setCameraType(
//       cameraType === 'back'
//         ? 'front'
//         : 'back'
//     );
//   };

//   const toggleFlashMode = () => {
//     setFlashMode(
//       flashMode === 'off'
//         ? 'on'
//         : 'off'
//     );
//   };

//   const toggleARMode = () => {
//     setIsARMode(!isARMode);
//   };

//   const takePicture = async () => {
//     if (cameraRef.current) {
//       try {
//         const photo = await cameraRef.current.takePictureAsync();
//         Alert.alert('Success', 'AR screenshot saved!');
//       } catch (error) {
//         Alert.alert('Error', 'Failed to take picture');
//       }
//     }
//   };

//   const placeObject = () => {
//     setIsObjectPlaced(true);
//     Alert.alert('Success', 'Product placed in AR space!');
//   };

//   const resetObject = () => {
//     setIsObjectPlaced(false);
//     setArObjectPosition({ x: width / 2, y: height / 2 });
//     setArObjectScale(1);
//     setArObjectRotation(0);
//   };

//   const scaleObject = (direction) => {
//     if (direction === 'up') {
//       setArObjectScale(prev => Math.min(prev + 0.1, 3));
//     } else {
//       setArObjectScale(prev => Math.max(prev - 0.1, 0.5));
//     }
//   };

//   const rotateObject = (direction) => {
//     if (direction === 'left') {
//       setArObjectRotation(prev => prev - 15);
//     } else {
//       setArObjectRotation(prev => prev + 15);
//     }
//   };

//   const getImageUriFromByteArray = (byteArray) => {
//     if (!byteArray || !Array.isArray(byteArray)) return null;
//     const arrayBufferToBase64 = (buffer) => {
//       let binary = '';
//       const bytes = new Uint8Array(buffer);
//       for (let i = 0; i < bytes.byteLength; i++) {
//         binary += String.fromCharCode(bytes[i]);
//       }
//       return btoa(binary);
//     };
//     const base64String = arrayBufferToBase64(byteArray);
//     return `data:image/jpeg;base64,${base64String}`;
//   };

//   const imageUri = product?.image?.data
//     ? getImageUriFromByteArray(product.image.data)
//     : typeof product.image === 'string'
//     ? product.image
//     : null;

//   if (handleCameraPermission()) {
//     return handleCameraPermission();
//   }

//   return (
//     <GestureHandlerRootView style={styles.container}>
//       <SafeAreaView style={styles.container}>
//         <Camera
//           style={styles.camera}
//           type={cameraType}
//           flashMode={flashMode}
//           ref={cameraRef}
//         >
//           {/* AR Overlay */}
//           {isARMode && (
//             <View style={styles.arOverlay}>
//               {/* AR Object */}
//               {isObjectPlaced && (
//                 <View
//                   style={[
//                     styles.arObject,
//                     {
//                       left: arObjectPosition.x - 50,
//                       top: arObjectPosition.y - 50,
//                       transform: [
//                         { scale: arObjectScale },
//                         { rotate: `${arObjectRotation}deg` }
//                       ]
//                     }
//                   ]}
//                 >
//                   {imageUri && (
//                     <Image source={{ uri: imageUri }} style={styles.arObjectImage} />
//                   )}
//                   <View style={styles.arObjectInfo}>
//                     <Text style={styles.arObjectTitle} numberOfLines={1}>
//                       {product?.title || 'Product'}
//                     </Text>
//                     <Text style={styles.arObjectPrice}>
//                       Rs. {product?.price?.toLocaleString() || ''}
//                     </Text>
//                   </View>
//                 </View>
//               )}

//               {/* Placement Guide */}
//               {!isObjectPlaced && (
//                 <View style={styles.placementGuide}>
//                   <View style={styles.guideCircle}>
//                     <Ionicons name="hand-left" size={24} color={COLORS.primary} />
//                   </View>
//                   <Text style={styles.guideText}>Tap to place product in your space</Text>
//                   <TouchableOpacity style={styles.placeButton} onPress={placeObject}>
//                     <Text style={styles.placeButtonText}>Place Product</Text>
//                   </TouchableOpacity>
//                 </View>
//               )}

//               {/* AR Controls */}
//               {isObjectPlaced && (
//                 <View style={styles.arControls}>
//                   <View style={styles.controlRow}>
//                     <TouchableOpacity
//                       style={styles.controlButton}
//                       onPress={() => scaleObject('up')}
//                     >
//                       <FontAwesome name="plus" size={20} color="white" />
//                     </TouchableOpacity>
//                     <TouchableOpacity
//                       style={styles.controlButton}
//                       onPress={() => scaleObject('down')}
//                     >
//                       <FontAwesome name="minus" size={20} color="white" />
//                     </TouchableOpacity>
//                   </View>
//                   <View style={styles.controlRow}>
//                     <TouchableOpacity
//                       style={styles.controlButton}
//                       onPress={() => rotateObject('left')}
//                     >
//                       <Ionicons name="rotate-left" size={20} color="white" />
//                     </TouchableOpacity>
//                     <TouchableOpacity
//                       style={styles.controlButton}
//                       onPress={() => rotateObject('right')}
//                     >
//                       <Ionicons name="rotate-right" size={20} color="white" />
//                     </TouchableOpacity>
//                   </View>
//                   <TouchableOpacity
//                     style={styles.resetButton}
//                     onPress={resetObject}
//                   >
//                     <Text style={styles.resetButtonText}>Reset</Text>
//                   </TouchableOpacity>
//                 </View>
//               )}
//             </View>
//           )}

//           {/* Camera Controls */}
//           <View style={styles.controlsContainer}>
//             {/* Top Controls */}
//             <View style={styles.topControls}>
//               <TouchableOpacity
//                 style={styles.controlButton}
//                 onPress={() => navigation.goBack()}
//               >
//                 <Ionicons name="close" size={30} color="white" />
//               </TouchableOpacity>

//               <TouchableOpacity
//                 style={styles.controlButton}
//                 onPress={toggleARMode}
//               >
//                 <MaterialIcons
//                   name={isARMode ? "view-in-ar" : "camera-alt"}
//                   size={30}
//                   color="white"
//                 />
//               </TouchableOpacity>

//               <TouchableOpacity
//                 style={styles.controlButton}
//                 onPress={toggleFlashMode}
//               >
//                 <Ionicons
//                   name={flashMode === 'off' ? "flash-off" : "flash"}
//                   size={30}
//                   color="white"
//                 />
//               </TouchableOpacity>
//             </View>

//             {/* Bottom Controls */}
//             <View style={styles.bottomControls}>
//               <TouchableOpacity
//                 style={styles.captureButton}
//                 onPress={takePicture}
//               >
//                 <View style={styles.captureButtonInner} />
//               </TouchableOpacity>

//               <TouchableOpacity
//                 style={styles.switchButton}
//                 onPress={toggleCameraType}
//               >
//                 <Ionicons name="camera-reverse" size={24} color="white" />
//               </TouchableOpacity>
//             </View>
//           </View>
//         </Camera>
//       </SafeAreaView>
//     </GestureHandlerRootView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: 'black',
//   },
//   camera: {
//     flex: 1,
//   },
//   permissionContainer: {
//     flex: 1,
//     justifyContent: 'center',
//     alignItems: 'center',
//     backgroundColor: COLORS.primary,
//   },
//   permissionText: {
//     color: 'white',
//     fontSize: 18,
//     marginBottom: 20,
//   },
//   permissionButton: {
//     backgroundColor: 'white',
//     paddingHorizontal: 20,
//     paddingVertical: 10,
//     borderRadius: 8,
//   },
//   permissionButtonText: {
//     color: COLORS.primary,
//     fontSize: 16,
//     fontWeight: 'bold',
//   },
//   arOverlay: {
//     flex: 1,
//     justifyContent: 'space-between',
//     padding: 20,
//   },
//   placementGuide: {
//     alignItems: 'center',
//     marginBottom: 100,
//   },
//   guideCircle: {
//     width: 60,
//     height: 60,
//     borderRadius: 30,
//     backgroundColor: 'rgba(255, 255, 255, 0.8)',
//     justifyContent: 'center',
//     alignItems: 'center',
//     marginBottom: 10,
//   },
//   guideText: {
//     color: 'white',
//     fontSize: 14,
//     textAlign: 'center',
//     backgroundColor: 'rgba(0, 0, 0, 0.5)',
//     paddingHorizontal: 15,
//     paddingVertical: 8,
//     borderRadius: 20,
//     marginBottom: 15,
//   },
//   placeButton: {
//     backgroundColor: COLORS.primary,
//     paddingHorizontal: 20,
//     paddingVertical: 10,
//     borderRadius: 25,
//   },
//   placeButtonText: {
//     color: 'white',
//     fontSize: 16,
//     fontWeight: 'bold',
//   },
//   arObject: {
//     position: 'absolute',
//     width: 100,
//     height: 100,
//     backgroundColor: 'rgba(255, 255, 255, 0.9)',
//     borderRadius: 12,
//     padding: 10,
//     alignItems: 'center',
//     shadowColor: '#000',
//     shadowOffset: {
//       width: 0,
//       height: 2,
//     },
//     shadowOpacity: 0.25,
//     shadowRadius: 3.84,
//     elevation: 5,
//   },
//   arObjectImage: {
//     width: 60,
//     height: 60,
//     borderRadius: 8,
//     marginBottom: 5,
//   },
//   arObjectInfo: {
//     alignItems: 'center',
//   },
//   arObjectTitle: {
//     fontSize: 10,
//     fontWeight: 'bold',
//     color: COLORS.primary,
//     textAlign: 'center',
//   },
//   arObjectPrice: {
//     fontSize: 8,
//     color: COLORS.gray,
//   },
//   arControls: {
//     position: 'absolute',
//     right: 20,
//     top: 100,
//     backgroundColor: 'rgba(0, 0, 0, 0.7)',
//     borderRadius: 15,
//     padding: 10,
//   },
//   controlRow: {
//     flexDirection: 'row',
//     marginBottom: 10,
//   },
//   controlButton: {
//     width: 40,
//     height: 40,
//     borderRadius: 20,
//     backgroundColor: 'rgba(255, 255, 255, 0.2)',
//     justifyContent: 'center',
//     alignItems: 'center',
//     marginHorizontal: 5,
//   },
//   resetButton: {
//     backgroundColor: COLORS.primary,
//     paddingHorizontal: 15,
//     paddingVertical: 8,
//     borderRadius: 15,
//     alignItems: 'center',
//   },
//   resetButtonText: {
//     color: 'white',
//     fontSize: 12,
//     fontWeight: 'bold',
//   },
//   controlsContainer: {
//     position: 'absolute',
//     bottom: 0,
//     left: 0,
//     right: 0,
//     paddingBottom: 30,
//   },
//   topControls: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     paddingHorizontal: 20,
//     marginBottom: 20,
//   },
//   bottomControls: {
//     flexDirection: 'row',
//     justifyContent: 'center',
//     alignItems: 'center',
//     paddingHorizontal: 20,
//   },
//   captureButton: {
//     width: 80,
//     height: 80,
//     borderRadius: 40,
//     backgroundColor: 'rgba(255, 255, 255, 0.3)',
//     justifyContent: 'center',
//     alignItems: 'center',
//     marginHorizontal: 30,
//   },
//   captureButtonInner: {
//     width: 60,
//     height: 60,
//     borderRadius: 30,
//     backgroundColor: 'white',
//   },
//   switchButton: {
//     width: 50,
//     height: 50,
//     borderRadius: 25,
//     backgroundColor: 'rgba(0, 0, 0, 0.5)',
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
// });

// export default AdvancedARView; 








import React from "react";
import { View, StyleSheet } from "react-native";
import ARExperience from "./ARExperience";

export default function AdvancedARView() {
  return (
    <View style={styles.container}>
      <ARExperience />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000" },
});
