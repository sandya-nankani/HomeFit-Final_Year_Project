
import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { COLORS, SIZES } from '../assets/constants'; // optional custom constants
import BackBtn from '../components/BackBtn';

const EmptyCart = ({ navigation }) => {
  const handleShopNow = () => {
    navigation.navigate('Home'); // or 'Products'
  };

  return (
    <View style={styles.container}>
     <View style={styles.backButtonContainer}>
        <BackBtn onPress={() => navigation.goBack()} />
      </View>

      <Image
        source={require('../assets/images/empty-cart1.jpg')}
        style={{
          height: SIZES.height / 3,
          width: SIZES.width - 60,
          resizeMode: 'contain',
          marginBottom: SIZES.xxLarge,
        }}
      />

      <Text style={styles.title}>Your cart is empty</Text>
      <Text style={styles.subtitle}>
        Looks like you haven’t added anything to your cart yet.
      </Text>

      <TouchableOpacity style={styles.button} onPress={handleShopNow}>
        <Text style={styles.buttonText}>Shop Now</Text>
      </TouchableOpacity>
    </View>
  );
};

export default EmptyCart;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  backButtonContainer: {
    position: 'absolute',
    top: 45, // adjust based on safe area
    left: 30,
    zIndex: 1,
  },
  image: {
    width: 400,
    height: 400,
    // marginBottom: 2,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 10,
    marginTop: -50
  },
  subtitle: {
    fontSize: 16,
    color: COLORS.gray || '#777',
    textAlign: 'center',
    marginBottom: 25,
  },
  button: {
    backgroundColor: COLORS.primary || '#007bff',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 25,
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
});
