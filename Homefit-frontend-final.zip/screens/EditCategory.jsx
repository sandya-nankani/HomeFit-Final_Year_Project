import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, Image, Alert,
  TouchableOpacity, StyleSheet, Button
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import axios from 'axios';  // <-- added axios import
import base64 from 'react-native-base64';
import { useIsFocused } from '@react-navigation/native';


const arrayBufferToBase64 = (buffer) => {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return base64.encode(binary);
};

const getImageUriFromByteArray = (byteArray) => {
  if (!byteArray || !Array.isArray(byteArray)) return null;
  const base64String = arrayBufferToBase64(byteArray);
  return `data:image/jpeg;base64,${base64String}`;
};

const EditCategory = ({ route, navigation }) => {
  const { id } = route.params;
  const [name, setName] = useState('');
  const [imageUri, setImageUri] = useState(null);
  const [newImage, setNewImage] = useState(null);
  const isFocused = useIsFocused();



  useEffect(() => {
  if (isFocused) {
    loadCategories();
  }
}, [isFocused]);

  const loadCategories = async () => {
    try {
      const response = await fetch(`http://172.16.150.254:3000/categories/${id}`);
      const data = await response.json();

      setName(data.name);
      const img = data.image?.data || data.image;
      const uri = getImageUriFromByteArray(img);
      setImageUri(uri);
    } catch (err) {
      console.error('Failed to fetch category:', err);
      Alert.alert('Error', 'Unable to load category');
      navigation.goBack();
    }
  };

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 1,
    });

    if (!result.canceled && result.assets?.length > 0) {
      setNewImage(result.assets[0]);
      setImageUri(result.assets[0].uri);
    }
  };

  const handleUpdate = async () => {
    console.log("Update button pressed");
    if (!name ) {
    alert('Please enter a category name ');
    return;
  }


  const formData = new FormData();
  formData.append('name', name);

  if (newImage) {
  formData.append('file', {
    uri: newImage.uri,
    name: `${Date.now()}.jpg`,
    type: 'image/jpeg',
  });
  }

     try {
        const response = await fetch(`http://172.16.150.254:3000/categories/update/${id}`, {
          method: 'PATCH',
          body: formData,
        });
    
        const result = await response.json();
        if (!response.ok) {
          throw new Error(result.message || 'Failed to update category');
        }
    
        // const updatedCategories = [...categories, result];
        // setCategories(updatedCategories);
        // saveCategories(updatedCategories);
    
        // setName('');
        // setNewImage(null);
    
        alert('✅ Category updated successfully!');
      } catch (error) {
        console.error('Update failed:', error);
        alert('❌ Failed to update category.');
      }
      navigation.navigate('ManageCategories', { refresh: true });
    };
    
    
    
     
 
  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Edit Category</Text>
      <TextInput
        value={name}
        onChangeText={setName}
        placeholder="Category name"
        style={styles.input}
      />
      <TouchableOpacity onPress={pickImage} style={styles.imageButton}>
        <Text style={styles.imageButtonText}>Pick Image</Text>
      </TouchableOpacity>

      {imageUri && (
        <Image
          source={{ uri: imageUri }}
          style={{ width: 100, height: 100, marginBottom: 10 }}
        />
      )}

      <Button title="Update Category" onPress={handleUpdate} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { 
    padding: 16,
    backgroundColor: '#fff', 
    flex: 1 
},

  heading: { 
    fontSize: 20, 
    fontWeight: 'bold', 
    marginBottom: 12 
},
  input: { borderWidth: 1, 
    borderColor: '#ccc', 
    padding: 10,
    borderRadius: 8, 
    marginBottom: 12 
},
  imageButton: { 
    backgroundColor: '#3498db', 
    padding: 10, 
    borderRadius: 8, 
    marginBottom: 10 
},
  imageButtonText: { 
    color: '#fff', 
    textAlign: 'center' },
});

export default EditCategory;
