


import { ScrollView, View, Text, Image, TextInput, TouchableOpacity, Alert } from 'react-native';
import React, { useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import BackBtn from '../components/BackBtn';
import styles from './login.style';
import Button from '../components/Button';
import * as Yup from 'yup';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS, SIZES } from '../assets/constants';
import { Formik } from 'formik';
import axios from 'axios'; // Import axios for API calls

const validationSchema = Yup.object().shape({
  email: Yup.string()
    .trim()
    .required('Email is required')
    .email('Invalid email format')
    .matches(
      /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
      'Invalid email format'
    ),
});


const ForgotPassword = ({ navigation }) => {
  const [loading, setLoading] = useState(false); // State to prevent multiple submissions


  const handleEmailSubmit = async (values) => {
    setLoading(true); // Disable button while API call is in progress
    try {
      const response = await axios.post('http://172.16.150.254:3000/user/checkEmail', {
        email:values.email,
      });
      console.log("✅ Response received:", response.data);
      if (response.data.status === 200) {
        const userId = Number(response.data.user?.id);

           

          const otpResponse = await axios.post('http://172.16.150.254:3000/auth/sendOtp', {
            email:values.email
          });
        navigation.navigate('SendOtp', { email: values.email, correctOtp: otpResponse.data.object, userId: userId }); // Navigate only if email exists
       console.log('userId:', userId)
        
        //   var otp=JSON.stringify(otpResponse.object);
          console.log(otpResponse.data);
          const otp = otpResponse.data.object
          console.log(otp)
          
        Alert.alert('Success', 'Email verified! Proceeding to next step.');
        navigation.navigate('SendOtp', { email: values.email, correctOtp: otpResponse.data.object , userId: userId}); // Navigate only if email exists
      } else {
        Alert.alert('Error', 'Email not found. Please enter a registered email.');
      }
    } catch (error) {
      console.error('Email Verification Error:', error.response?.data || error.message);
      Alert.alert('Error', error.response?.data?.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false); // Re-enable button after API call
    }
  };

  return (
    <ScrollView>
      <SafeAreaView style={{ marginHorizontal: 20 }}>
        <View>
          <BackBtn onPress={() => navigation.goBack()} />
          <Image
            source={require('../assets/images/bk.png')}
            style={{
              height: SIZES.height / 3,
              width: SIZES.width - 60,
              resizeMode: 'contain',
              marginBottom: SIZES.xxLarge,
            }}
          />
          <Text
            style={{
              fontFamily: 'bold',
              fontSize: SIZES.xLarge,
              color: COLORS.primary,
              alignItems: 'center',
              marginBottom: SIZES.xSmall,
            }}
          >
            Forgot Password
          </Text>
          <Text
            style={{
              marginBottom: 35,
              fontSize: SIZES.medium,
            }}
          >
            Please enter your registered email
          </Text>

          <Formik
            initialValues={{ email: '' }}
            validationSchema={validationSchema}
            onSubmit={handleEmailSubmit} // Call API on submit
          >
            {({ handleChange, handleBlur, handleSubmit, touched, values, errors, isValid, setFieldTouched }) => (
              <View>
                <View style={styles.wrapper}>
                  <View style={styles.inputWrapper(touched.email ? COLORS.secondary : COLORS.offwhite)}>
                    <MaterialCommunityIcons name="email-outline" size={20} color={COLORS.gray} style={styles.iconStyle} />
                    <TextInput
                      placeholder="Enter email"
                      onFocus={() => setFieldTouched('email')}
                      onBlur={() => setFieldTouched('email', false)}
                      value={values.email}
                      onChangeText={handleChange('email')}
                      autoCapitalize="none"
                      autoCorrect={false}
                      style={{ flex: 1 }}
                    />
                  </View>
                  {touched.email && errors.email && <Text style={styles.errorMessage}>{errors.email}</Text>}
                </View>

                <Button
                  title={loading ? 'Checking...' : 'S U B M I T'}
                  onPress={isValid ? handleSubmit : () => Alert.alert('Invalid Form', 'Please enter a valid email.')}
                  isValid={isValid && !loading} // Disable button while checking
                />
              </View>
            )}
          </Formik>
        </View>
      </SafeAreaView>
    </ScrollView>
  );
};

export default ForgotPassword;
