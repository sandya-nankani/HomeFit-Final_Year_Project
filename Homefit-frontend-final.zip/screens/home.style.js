import { COLORS, SIZES } from "../assets/constants"
import { StyleSheet } from "react-native";


const styles = StyleSheet.create({
textStyle: {
    fontFamily: "bold",
    fontSize: 40
    },
appBarWrapper : {
    marginHorizonatal: 22,
    marginTop: SIZES.small,
    marginLeft: 10
},
appBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center"
},
location: {
    fontFamily: "semibold",
    fontSize: SIZES.medium,
    color: COLORS.gray
},
cartCount: {
    position: "absolute",
    bottom: 16,
    right: 4,
    width: 16,
    height: 16,
    borderRadius: 15,
    alignItems: "center",
    backgroundColor: "green",
    justifyContent: "center",
    zIndex: 999,
   
},
cartNumber: {
    fontFamily: "regular",
    fontweight: "600",
    fontSize: 10,
    color: COLORS.lightWhite,
    
}
})

export default styles;