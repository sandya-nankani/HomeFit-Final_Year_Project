

// ✅ Updated CheckoutScreen.js
import React, { useEffect, useState } from 'react';
import {
  View, Text, TextInput, FlatList, StyleSheet,
  ScrollView, TouchableOpacity, Alert, Image,
  TouchableWithoutFeedback, Modal
} from 'react-native';
import { COLORS, SIZES } from '../assets/constants/theme';
import BackBtn from '../components/BackBtn';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const getImageUriFromByteArray = (byteArray) => {
  if (!byteArray || !Array.isArray(byteArray)) return null;
  const base64String = btoa(byteArray.map((byte) => String.fromCharCode(byte)).join(''));
  return `data:image/jpeg;base64,${base64String}`;
};


const CheckoutScreen = ({ navigation, route }) => {

 
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');


  const [address, setAddress] = useState('');
  const [products, setProducts] = useState([]);
  const [paymentMethod, setPaymentMethod] = useState('Cash on Delivery');
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState('cash');

  const [loggedInUser, setLoggedInUser] = useState(null);
  const [isStripePaid, setIsStripePaid] = useState(false);
  
  
  
    useEffect(() => {
    if (route.params?.orderPayload) {
      const payload = route.params.orderPayload;
      setFirstName(payload.firstName);
      setLastName(payload.lastName);
      setPhone(payload.mobileNo);
      setCity(payload.city);
      setAddress(payload.address);
      setEmail(payload.email);
      setPaymentMethod(payload.paymentType);
      setIsStripePaid(route.params.stripePaid || false);
    }
  }, [route.params]);
  
  
  

  // 🔄 Check if returning from Stripe with success
  useEffect(() => {
    if (route.params?.stripePaid) {
      setIsStripePaid(true);
    }
  }, [route.params]);

  useEffect(() => {
    const fetchCartItems = async () => {
      try {
        const userData = await AsyncStorage.getItem('user');
        if (!userData) return;

        const user = JSON.parse(userData);
        setLoggedInUser(user);

        const response = await axios.get(`http://172.16.150.254:3000/cart/user/${user.id}`);
        const cartItems = response.data || [];

        const formatted = cartItems.map(item => ({
          id: item.product.id,
          product: item.product,
          title: item.product.title,
          price: item.quantity * item.product.price,
          quantity: item.quantity,
        }));

        setProducts(formatted);
      } catch (error) {
        console.error('🛑 Error fetching cart items for checkout:', error.message);
      }
    };

    fetchCartItems();
  }, []);

  const totalItems = products.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = products.reduce((sum, item) => sum + item.price, 0);
  const shippingCharge = 250;
  const grandTotal = totalPrice + shippingCharge;

  const handlePlaceOrder = async () => {
    try {
      if (!loggedInUser) return;

      if (paymentMethod.includes("Stripe") && !isStripePaid) {
        Alert.alert("⚠️ Payment Required", "Please complete the Stripe payment first.");
        return;
      }

      const orderPayload = {
        firstName,
        lastName,
        email: loggedInUser.email,
        mobileNo: phone,
        address,
        city,
        userId: loggedInUser.id,
        paymentType: paymentMethod,
        products: products.map((item) => ({
          productId: item.product.id,
          quantity: item.quantity,
        })),
      };

      const response = await axios.post('http://172.16.150.254:3000/order', orderPayload);

      console.log('✅ Order placed successfully:', response.data);
      Alert.alert('✅ Success', '🎉 Your order has been placed successfully!');

      await axios.delete(`http://172.16.150.254:3000/cart/user/${loggedInUser.id}/clear`);
      setProducts([]);
      navigation.navigate('BottomTabNavigation');
    } catch (error) {
      console.error('🛑 Error placing order:', error.message);
      Alert.alert('Error', 'Could not place your order. Please try again.');
    }
  };

  // ✅ FIX: Don’t create order here
  const handleStripePayment = async () => {
    try {
      if (!loggedInUser) return;

      console.log('Sending to backend:', { amount: grandTotal, userId: loggedInUser.id });

      
  const res = await axios.post('http://172.16.150.254:3000/payment-gateway/create-intent', {
  amount: grandTotal,
  userId: loggedInUser.id,
 
    });

    const { clientSecret } = res.data;

      // 👉 Just navigate to PaymentDetails
      navigation.navigate('PaymentDetails', {
          clientSecret,
        amount: grandTotal,
        userId: loggedInUser.id,
        orderPayload: {
        
          firstName,
          lastName,
          email: loggedInUser.email,
          mobileNo: phone,
          address,
          city,
          userId: loggedInUser.id,
          paymentType: 'Stripe (Online Payment)',
          products: products.map((item) => ({
            productId: item.product.id,
            quantity: item.quantity,
          })),
        },
      });
    } catch (error) {
      console.error('🛑 Error navigating to Stripe payment:', error.message);
      Alert.alert('Error', 'Could not initiate Stripe payment');
    }
  };

  const renderProduct = ({ item }) => {
    if (!item?.product) return null;
    const imageData = item.product.image?.data;
    const imageUrl = imageData ? getImageUriFromByteArray(imageData) : null;

    return (
      <View style={styles.productCard}>
        {imageUrl && <Image source={{ uri: imageUrl }} style={styles.productImage} resizeMode="cover" />}
        <View style={styles.productInfo}>
          <Text style={styles.productTitle}>{item.product.title}</Text>
          <Text style={styles.productDetails}>Qty: {item.quantity}</Text>
        </View>
        <Text style={styles.productPrice}>
          Rs {item.product.price.toLocaleString()}
        </Text>
      </View>
    );
  };

  return (
    <View style={styles.screen}>
      <ScrollView style={styles.container}>
        <View style={styles.backButtonContainer}>
          <BackBtn onPress={() => navigation.goBack()} />
        </View>

        <Text style={styles.heading}>Checkout</Text>

        <TextInput style={styles.input} placeholder="First Name" value={firstName} onChangeText={setFirstName} />
        <TextInput style={styles.input} placeholder="Last Name" value={lastName} onChangeText={setLastName} />
        <TextInput style={styles.input} placeholder="Phone Number" keyboardType="phone-pad" value={phone} onChangeText={setPhone} />
        <TextInput style={styles.input} placeholder="City" value={city} onChangeText={setCity} />
        <TextInput style={styles.input} placeholder="Address" value={address} onChangeText={setAddress} multiline />

        {/* Payment Section */}
        <View style={styles.paymentSection}>
          <View style={styles.paymentHeader}>
            <Text style={styles.paymentTitle}>💼 Payment method</Text>
            <TouchableOpacity onPress={() => setModalVisible(true)}>
              <Text style={styles.changeText}>Change</Text>
            </TouchableOpacity>
          </View>

          <Modal animationType="fade" transparent visible={modalVisible} onRequestClose={() => setModalVisible(false)}>
            <TouchableWithoutFeedback onPress={() => setModalVisible(false)}>
              <View style={styles.modalBackground}>
                <View style={styles.modalContent}>
                  <Text style={styles.modalTitle}>Select Payment Method</Text>

                  <View style={{ marginTop: 20 }}>
                    <TouchableOpacity style={styles.optionRow} onPress={() => setSelectedMethod('stripe')}>
                      <View style={styles.radioCircle}>{selectedMethod === 'stripe' && <View style={styles.selectedRb} />}</View>
                      <Text style={styles.optionText}>💳 Stripe (Online Payment)</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.optionRow} onPress={() => setSelectedMethod('cash')}>
                      <View style={styles.radioCircle}>{selectedMethod === 'cash' && <View style={styles.selectedRb} />}</View>
                      <Text style={styles.optionText}>💵 Cash on Delivery</Text>
                    </TouchableOpacity>
                  </View>

                  <TouchableOpacity
                    style={styles.confirmButton}
                    onPress={() => {
                      if (!selectedMethod) return;
                      if (selectedMethod === 'stripe') {
                        setPaymentMethod('Stripe (Online Payment)');
                        setModalVisible(false);
                        handleStripePayment();
                      } else if (selectedMethod === 'cash') {
                        setPaymentMethod('Cash on Delivery');
                        setModalVisible(false);
                      }
                    }}
                  >
                    <Text style={styles.confirmButtonText}>Confirm</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </TouchableWithoutFeedback>
          </Modal>

          <View style={styles.paymentRow}>
            <Text style={styles.methodLabel}>💵 {paymentMethod}</Text>
            <Text style={styles.amountText}>Rs {grandTotal.toLocaleString()}</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Order Summary</Text>
        <FlatList
          data={products}
          keyExtractor={(item, index) => item.id?.toString() || index.toString()}
          renderItem={renderProduct}
          scrollEnabled={false}
        />
      </ScrollView>

      <View style={styles.bottomSummary}>
        <View style={styles.summaryRow}>
          <Text>Total Items:</Text>
          <Text>{totalItems}</Text>
        </View>
        <View style={styles.summaryRow}>
          <Text>Total Items Price:</Text>
          <Text>Rs {totalPrice.toLocaleString()}</Text>
        </View>
        <View style={styles.summaryRow}>
          <Text>Shipping Charges:</Text>
          <Text>Rs {shippingCharge.toLocaleString()}</Text>
        </View>
        <View style={[styles.summaryRow, { fontWeight: 'bold' }]}>
          <Text>Total:</Text>
          <Text>Rs {grandTotal.toLocaleString()}</Text>
        </View>
      </View>

      <TouchableOpacity
        onPress={handlePlaceOrder}
        style={[
          styles.placeOrder,
          paymentMethod.includes("Stripe") && !isStripePaid ? { backgroundColor: '#ccc' } : {}
        ]}
      >
        <Text style={styles.placeOrderText}>Place Order</Text>
      </TouchableOpacity>
    </View>
  );
};

// ✅ styles unchanged…
const styles = StyleSheet.create({
  container: { padding: SIZES.medium, backgroundColor: COLORS.white, marginBottom: 30, flex: 1 },
  modalBackground: { flex: 1, backgroundColor: 'rgba(0,0,0,0.3)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: '#fff', width: 250, borderRadius: 10, padding: 15 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 10, color: COLORS.primary },
  optionRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 10 },
  optionText: { fontSize: 16, marginLeft: 10 },
  radioCircle: { height: 20, width: 20, borderRadius: 10, borderWidth: 2, borderColor: COLORS.primary, alignItems: 'center', justifyContent: 'center' },
  selectedRb: { width: 10, height: 10, borderRadius: 5, backgroundColor: COLORS.primary },
  confirmButton: { marginTop: 20, backgroundColor: COLORS.primary, paddingVertical: 12, paddingHorizontal: 30, borderRadius: 10, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.25, shadowRadius: 3.84, elevation: 5 },
  confirmButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: 1 },
  productCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f2f2f2', padding: 10, borderRadius: 10, marginBottom: 10 },
  productImage: { width: 60, height: 60, borderRadius: 8, marginRight: 10 },
  productInfo: { flex: 1 },
  productTitle: { fontSize: 16, fontWeight: 'bold' },
  productDetails: { fontSize: 14, color: '#555' },
  backButtonContainer: { position: 'absolute', top: 25, left: 2, zIndex: 1 },
  heading: { fontSize: 20, fontWeight: 'bold', marginTop: 27, marginBottom: 15, marginLeft: 45 },
  input: { borderWidth: 1, borderColor: COLORS.lightGray, padding: 10, borderRadius: 8, marginBottom: SIZES.medium },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', marginVertical: SIZES.medium },
  productPrice: { fontSize: 16, fontWeight: '600', color: COLORS.primary },
  screen: { flex: 1, backgroundColor: COLORS.white, bottom: 10 },
  bottomSummary: { bottom: 20, left: 0, right: 0, paddingVertical: 5, paddingHorizontal: 20, backgroundColor: '#fff', borderTopWidth: 1, borderColor: '#ccc' },
  summaryRow: { fontWeight: 'bold', flexDirection: 'row', justifyContent: 'space-between', marginVertical: 5 },
  placeOrder: { backgroundColor: COLORS.primary, padding: 10, bottom: 25, borderRadius: 10, margin: 10, alignItems: 'center' },
  placeOrderText: { color: '#fff', fontWeight: 'bold' },
  paymentSection: { backgroundColor: '#fff', padding: 16, borderRadius: 10, elevation: 2, shadowColor: '#000', shadowOpacity: 0.1, shadowOffset: { width: 0, height: 2 }, shadowRadius: 4, marginBottom: 10 },
  paymentHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  paymentTitle: { fontSize: 16, fontWeight: 'bold' },
  changeText: { color: COLORS.gray, fontWeight: '600' },
  paymentRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  methodLabel: { fontSize: 15, color: '#555' },
  amountText: { fontSize: 15, fontWeight: 'bold', color: COLORS.primary },
});

export default CheckoutScreen;
