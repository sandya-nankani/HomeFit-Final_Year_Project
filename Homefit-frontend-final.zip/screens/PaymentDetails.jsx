
import {React, useState, useEffect}  from "react";
import { View, Text, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from "react-native";
import { CardField, useStripe } from "@stripe/stripe-react-native";

export default function PaymentDetails({ route, navigation }) {
  const { amount, orderId, userId } = route.params; // ✅ passed from Checkout
  const { confirmPayment } = useStripe();
  const [cardDetails, setCardDetails] = useState(null);
  const [loading, setLoading] = useState(false);
  

  // ✅ Handle payment
  const handlePayPress = async () => {
    if (!cardDetails?.complete) {
      Alert.alert("Error", "Please enter complete card details");
      return;
    }
 
    try {
      setLoading(true);

      // 1️⃣ Call backend to create PaymentIntent
      const response = await fetch("http://172.16.150.254:3000/payment-gateway/create-intent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderId,
          userId,
          amount,
          paymentMethod: "Stripe",
        }),
      });

      const data = await response.json();
      if (!data.clientSecret) {
        console.log("Amount:", amount)
        console.log("userId:", userId)
        throw new Error("Failed to get clientSecret from server");
      }

      // 2️⃣ Confirm payment with Stripe
      const { paymentIntent, error } = await confirmPayment(data.clientSecret, {
        paymentMethodType: "Card",
      });

      if (error) {
        Alert.alert("❌ Payment failed", error.message);
        console.log("❌ Payment failed", error.message)
      } else if (paymentIntent) {
        Alert.alert("✅ Success", `Payment of Rs ${amount} confirmed!`);
       navigation.navigate("CheckoutScreen", {
        stripePaid: true,
         paymentId: paymentIntent.id,    
          orderPayload: route.params.orderPayload,
  });
      }
    } catch (err) {
      Alert.alert("Payment Error", err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>💳 Stripe Payment</Text>
      <Text style={styles.amount}>Total: Rs {amount.toLocaleString()}</Text>

      <CardField
        postalCodeEnabled={false}
        placeholder={{ number: "4242 4242 4242 4242" }}
        cardStyle={{
          backgroundColor: "#f1f1f1",
          textColor: "#000000",
          placeholderColor: "#888888",
        }}
        style={styles.cardContainer}
        onCardChange={(details) => setCardDetails(details)}
      />

      <TouchableOpacity
        style={[styles.payButton, loading && { backgroundColor: "#cccccc" }]}
        onPress={handlePayPress}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.payText}>Pay Now</Text>
        )}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#ffffff",
    justifyContent: "center",
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },
  amount: {
    fontSize: 18,
    marginBottom: 20,
    textAlign: "center",
  },
  cardContainer: {
    height: 50,
    marginVertical: 30,
  },
  payButton: {
    backgroundColor: "#287f2b",
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
  },
  payText: {
    color: "#ffffff",
    fontSize: 18,
    fontWeight: "bold",
  },
});



