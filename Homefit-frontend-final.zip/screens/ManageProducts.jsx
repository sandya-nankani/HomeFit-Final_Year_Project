


import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, Image,
  ScrollView, StyleSheet, TouchableOpacity
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { COLORS, SIZES } from '../assets/constants';
import { Picker } from '@react-native-picker/picker';
import base64 from 'react-native-base64';


const arrayBufferToBase64 = (buffer) => {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return base64.encode(binary);
};

const getImageUriFromByteArray = (byteArray) => {
  if (!byteArray || !Array.isArray(byteArray)) return null;
  const base64String = arrayBufferToBase64(byteArray);
  return `data:image/jpeg;base64,${base64String}`;
};



const ManageProducts = ({ navigation }) => {
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [description, setDescription] = useState('');
  const [stock, setStock] = useState('');
  const [imageUri, setImageUri] = useState(null);
  const [modelUri, setModelUri] = useState(null);
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [categoryId, setCategoryId] = useState('');

  useEffect(() => {
    fetchCategories();
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const response = await fetch('http://172.16.150.254:3000/products');
      const data = await response.json();
      setProducts(Array.isArray(data) ? data : data.products || []);
    } catch (e) {
      console.error('❌ Failed to fetch products:', e);
      setProducts([]);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await fetch('http://172.16.150.254:3000/categories');
      const data = await response.json();
      setCategories(data);
    } catch (error) {
      console.error('Failed to fetch categories:', error);
    }
  };

  const saveProducts = async (productsList) => {
    try {
      await AsyncStorage.setItem('products', JSON.stringify(productsList));
    } catch (e) {
      console.error('Failed to save products', e);
    }
  };

  const resetForm = () => {
    setTitle('');
    setPrice('');
    setDescription('');
    setCategoryId('');
    setStock('');
    setImageUri(null);
    setModelUri(null);
  };

  const handleAddProduct = async () => {
    if (!title || !price || !description || !categoryId || !stock) {
      alert('Please fill all fields.');
      return;
    }

    const formData = new FormData();
    formData.append('title', title);
    formData.append('price', String(Number(price)));
    formData.append('description', description);
    formData.append('stock', String(Number(stock)));
    formData.append('categoryId', String(Number(categoryId)));

    if (imageUri) {
      formData.append('image', {
        uri: imageUri,
        name: `product-${Date.now()}.jpg`,
        type: 'image/jpeg'
      });
    }

    if (modelUri) {
      formData.append('model', {
        uri: modelUri,
        name: `product-${Date.now()}.glb`,
        type: 'model/gltf-binary'
      });
    }

    try {
      const response = await fetch('http://172.16.150.254:3000/products/create', {
        method: 'POST',
        headers: { 'Content-Type': 'multipart/form-data' },
        body: formData
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.message || 'Failed to add product');

      const updatedProducts = [...products, result];
      setProducts(updatedProducts);
      saveProducts(updatedProducts);
      resetForm();

      alert('✅ Product added successfully!');
    } catch (error) {
      console.error('Upload failed:', error.message);
      alert('❌ Failed to add product.');
    }
  };

  
const handleDeleteProduct = async (index) => {
  const ProductId = products[index].id;

  try {
    const response = await fetch(`http://172.16.150.254:3000/products/${ProductId}`, {
      method: 'DELETE',
    });

    let result = null;
    // Check if response has content before parsing JSON
    const text = await response.text();
    if (text) {
      result = JSON.parse(text);
    }

    if (!response.ok) {
      alert(result?.message || 'Failed to delete product');
      return;
    }

    // Proceed if deletion was successful
    const updatedProducts = [...products];
    updatedProducts.splice(index, 1);
    setProducts(updatedProducts);
    await saveProducts(updatedProducts);
    alert('🗑️ Product deleted successfully');
  } catch (error) {
    console.error('Delete Product failed:', error);
    alert(error.message || 'Failed to delete product.');
  }
};



  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      alert('Permission is required to access media library');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 1
    });

    if (!result.canceled && result.assets?.length > 0) {
      setImageUri(result.assets[0].uri);
    }
  };

  const pick3DModel = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['model/gltf-binary', 'model/gltf+json', 'model/usd', 'application/octet-stream'],
        copyToCacheDirectory: true,
        multiple: false
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        const asset = result.assets[0];
        const uri = asset.uri;
        const name = asset.name;

        const extension = name.split('.').pop().toLowerCase();
        const supportedExtensions = ['glb', 'gltf', 'usdz', 'obj', 'fbx'];

        if (!supportedExtensions.includes(extension)) {
          alert(`Unsupported file type: .${extension}`);
          return;
        }

        setModelUri(uri);
      }
    } catch (error) {
      console.error('❌ Failed to pick 3D model:', error);
      alert('Failed to pick 3D model. Please try again.');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.heading}>Add New Product</Text>

      <TextInput style={styles.input} placeholder="Title" value={title} onChangeText={setTitle} />
      <TextInput style={styles.input} placeholder="Price" value={price} onChangeText={setPrice} keyboardType="numeric" />
      <TextInput style={styles.input} placeholder="Description" value={description} onChangeText={setDescription} />
      
      <View style={styles.input}>
        <Picker selectedValue={categoryId} onValueChange={(itemValue) => setCategoryId(itemValue)}>
          <Picker.Item label="Select Category" value="" />
          {categories.map((cat) => (
            <Picker.Item label={cat.name} value={cat.id} key={cat.id} />
          ))}
        </Picker>
      </View>

      <TextInput style={styles.input} placeholder="Stock" value={stock} onChangeText={setStock} keyboardType="numeric" />

      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <TouchableOpacity onPress={pickImage} style={styles.fileButton}>
          <Text style={styles.fileButtonText}>Pick Image</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={pick3DModel} style={[styles.fileButton, { backgroundColor: COLORS.green }]}>
          <Text style={styles.fileButtonText}>Pick 3D Model</Text>
        </TouchableOpacity>
      </View>

      {imageUri && <Image source={{ uri: imageUri }} style={styles.imagePreview} />}
      {modelUri && (
        <Text style={{ marginVertical: 10, color: COLORS.blue }}>
          3D Model Selected: {modelUri.split('/').pop()}
        </Text>
      )}

      <TouchableOpacity onPress={handleAddProduct} style={styles.addBtn}>
        <Text style={styles.addBtnText}>Add Product</Text>
      </TouchableOpacity>

      <Text style={styles.heading}>Product List</Text>
      {/* {products.map((product, index) => (
        <View key={index} style={styles.productRow}>
          <Text style={styles.productTitle}>{product.title}</Text>
          <Text>Price: Rs {product.price}</Text>
          <Text>{product.description}</Text>
          <Text>Stock: {product.stock}</Text>
        </View>
      ))} */}

      {products.map((product, index) => {
  // ✅ Handle both string and byte-array images
  const imageData = product.image?.data || product.image;
  const imageUri = typeof imageData === "string"
    ? imageData
    : getImageUriFromByteArray(imageData);

  return (
    <View key={index} style={styles.productRow}>
      {imageUri && (
        <Image source={{ uri: imageUri }} style={styles.productImage} />
      )}
      <View style={styles.productDetails}>
        <Text style={styles.productTitle}>{product.title}</Text>
        <Text>Price: Rs {product.price}</Text>
        <Text numberOfLines={2}>{product.description}</Text>
        <Text>Stock: {product.stock}</Text>

        <View style={styles.buttonsContainer}>
          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: COLORS.green }]}
            onPress={() => {
              console.log('Navigating to EditProduct:', product.id);
              navigation.navigate('EditProducts', { id: product.id })}
             }>
            <Text style={styles.actionBtnText}>Update</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: COLORS.red }]}
            onPress={() => handleDeleteProduct(index)}
          >
            <Text style={styles.actionBtnText}>Delete</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
})}



    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { padding: 16, backgroundColor: '#fff' },
  heading: { fontSize: 20, fontWeight: 'bold', marginVertical: 10 },
  input: { borderWidth: 1, borderColor: '#aaa', borderRadius: 8, padding: 10, marginBottom: 10 },
  fileButton: { backgroundColor: COLORS.primary, padding: 10, borderRadius: 8, marginVertical: 10, flex: 0.48, alignItems: 'center' },
  fileButtonText: { color: '#fff', fontWeight: 'bold' },
  addBtn: { backgroundColor: COLORS.blue, padding: 10, borderRadius: 8, marginVertical: 10, alignItems: 'center' },
  addBtnText: { color: '#fff', fontWeight: 'bold' },
  imagePreview: { width: 120, height: 120, marginVertical: 10, borderRadius: 8 },
  productRow: { padding: 10, marginBottom: 10, backgroundColor: '#f5f5f5', borderRadius: 8 },
  productTitle: { fontSize: 16, fontWeight: 'bold' },
  
buttonsContainer: {
  flexDirection: 'row',
  justifyContent: 'flex-start', // align buttons left inside the text+button area
  gap: 10,
},

actionBtn: {
  paddingVertical: 6,
  paddingHorizontal: 12,
  borderRadius: 6,
  justifyContent: 'center',
  alignItems: 'center',
},

actionBtnText: {
  color: '#fff',
  fontWeight: '600',
},


actionBtn: {
  paddingVertical: 6,
  paddingHorizontal: 12,
  borderRadius: 6,
  justifyContent: 'center',
  alignItems: 'center',
  marginLeft: 10,  // ensure some spacing between buttons
},


actionBtnText: {
  color: '#fff',
  fontWeight: 'bold',
},
});

export default ManageProducts;
