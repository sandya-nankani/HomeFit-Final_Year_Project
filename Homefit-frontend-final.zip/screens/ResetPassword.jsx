
import { ScrollView, View, Text, Image, TextInput, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import React, { useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import BackBtn from '../components/BackBtn';
import styles from './login.style';
import Button from '../components/Button';
import * as Yup from 'yup';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS, SIZES } from '../assets/constants';
import { Formik } from 'formik';
import axios from 'axios';

const validationSchema = Yup.object().shape({
  password: Yup.string()
    .min(8, 'Password must be at least 8 characters long')
    .required('Required'),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref('password'), null], 'Passwords must match')
    .required('Confirm Password is required'),
});

const ResetPassword = ({ navigation, route }) => {
  const [loading, setLoading] = useState(false);
  const [obsecureText, setObsecureText] = useState(true);

  const userEmail = route.params?.email || ''; // Get email from route params
  const userId = Number(route.params?.userId) || 0; // Get userId from route params


  const updatePassword = async (password) => {
    setLoading(true);
    try {
      const response = await axios.patch(`http://172.16.150.254:3000/user/resetPassword/${userId}`, {
        password,
      });

      
        Alert.alert('Success', 'Password updated successfully');
        console.log(response.data)
        navigation.replace('PasswordUpdated'); // Redirect to login page
    
      //   if (response.data['Password changed successfully']) {
      //     Alert.alert('Success', 'Password updated successfully');
      //     navigation.replace('BottomTabNavigation'); // Redirect to login page
      // } else {
      //     Alert.alert('Error', 'Failed to update password');
      // }
      
    } catch (error) {
      console.log("📦 userId:", userId, "🧪 Type:", typeof userId);
      Alert.alert('Error', 'Failed to update password');
      // Alert.alert('Error', error.response?.data?.message || 'Something went wrong');
      console.log(error.response?.data?.message)
    console.log('userId: ',userId)

    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView>
      <SafeAreaView style={{ marginHorizontal: 20 }}>
        <View>
          <BackBtn onPress={() => navigation.goBack()} />
          <Image
            source={require('../assets/images/bk.png')}
            style={{
              height: SIZES.height / 3,
              width: SIZES.width - 60,
              resizeMode: 'contain',
              marginBottom: SIZES.xxLarge,
            }}
          />
          <Text style={{ fontFamily: 'bold', fontSize: SIZES.xLarge, color: COLORS.primary, marginBottom: SIZES.xSmall }}>
            Reset Password
          </Text>
          <Text style={{ marginBottom: 35, fontSize: SIZES.medium }}>Please enter a new password for your account</Text>

          <Formik
            initialValues={{ password: '', confirmPassword: '' }}
            validationSchema={validationSchema}
            onSubmit={(values) => updatePassword(values.password)}
          >
            {({ handleChange, handleBlur, handleSubmit, touched, values, errors, setFieldTouched }) => (
              <View>
                <View style={styles.wrapper}>
                  <View style={styles.inputWrapper(touched.password ? COLORS.secondary : COLORS.offwhite)}>
                    <MaterialCommunityIcons name="lock-outline" size={20} color={COLORS.gray} style={styles.iconStyle} />
                    <TextInput
                      secureTextEntry={obsecureText}
                      placeholder="Enter Password"
                      onFocus={() => setFieldTouched('password')}
                      onBlur={() => setFieldTouched('password', '')}
                      value={values.password}
                      onChangeText={handleChange('password')}
                      autoCapitalize="none"
                      autoCorrect={false}
                      style={{ flex: 1 }}
                    />
                    <TouchableOpacity onPress={() => setObsecureText(!obsecureText)}>
                      <MaterialCommunityIcons name={obsecureText ? 'eye-outline' : 'eye-off-outline'} size={18} />
                    </TouchableOpacity>
                  </View>
                  {touched.password && errors.password && <Text style={styles.errorMessage}>{errors.password}</Text>}
                </View>

                <View style={styles.wrapper}>
                  <View style={styles.inputWrapper(touched.confirmPassword ? COLORS.secondary : COLORS.offwhite)}>
                    <MaterialCommunityIcons name="lock-outline" size={20} color={COLORS.gray} style={styles.iconStyle} />
                    <TextInput
                      secureTextEntry={obsecureText}
                      placeholder="Confirm Password"
                      onFocus={() => setFieldTouched('confirmPassword')}
                      onBlur={() => setFieldTouched('confirmPassword', '')}
                      value={values.confirmPassword}
                      onChangeText={handleChange('confirmPassword')}
                      autoCapitalize="none"
                      autoCorrect={false}
                      style={{ flex: 1 }}
                    />
                    <TouchableOpacity onPress={() => setObsecureText(!obsecureText)}>
                      <MaterialCommunityIcons name={obsecureText ? 'eye-outline' : 'eye-off-outline'} size={18} />
                    </TouchableOpacity>
                  </View>
                  {touched.confirmPassword && errors.confirmPassword && (
                    <Text style={styles.errorMessage}>{errors.confirmPassword}</Text>
                  )}
                </View>

                {loading ? (
                  <ActivityIndicator size="large" color={COLORS.primary} />
                ) : (
                  <Button
                    title="R E S E T"
                    onPress={() => {
                      if (!values.password || !values.confirmPassword) {
                        Alert.alert('Invalid Form', 'Please provide all required fields');
                      } else if (values.password !== values.confirmPassword) {
                        Alert.alert('Error', 'Passwords do not match');
                      } else {
                        handleSubmit();
                      }
                    }}
                  />
                )}
              </View>
            )}
          </Formik>
        </View>
      </SafeAreaView>
    </ScrollView>
  );
};

export default ResetPassword;
