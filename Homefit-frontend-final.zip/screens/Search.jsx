import React, { useEffect, useState } from 'react';
import ProductCardView from '../components/products/ProductCardView'
import { Text, View, TextInput, TouchableOpacity, FlatList, Image} from 'react-native';
import styles from './search.styles';
import { Feather, Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, SIZES } from '../assets/constants';


const arrayBufferToBase64 = (buffer) => {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);  // ✅ Built-in base64 encoder (React Native supports this)
};

// const getImageUriFromByteArray = (byteArray) => {
//   if (!byteArray || !Array.isArray(byteArray)) return null;
//   const base64String = arrayBufferToBase64(byteArray);
//   return `data:image/jpeg;base64,${base64String}`;
// };

const Search = () => {
  const [searchText, setSearchText] = useState('');
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  useEffect(() => {
    if (searchText.trim() === '') {
      setFilteredProducts([]);
    } else {
      const filtered = products.filter((item) =>
        item.title.toLowerCase().includes(searchText.toLowerCase())
      );
      setFilteredProducts(filtered);
    }
  }, [searchText]);

  const fetchProducts = async () => {
    try {
      const response = await fetch('http://172.16.150.254:3000/products');
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error('Failed to fetch products:', error);
    }
  };

  // const renderItem = ({ item }) => {
  //   const imageData = item.image?.data || item.image;
  //   const imageUri = imageData
  // ? `data:image/jpeg;base64,${arrayBufferToBase64(imageData)}`
  // : null;

  //   return (
  //     <View style={styles.productCard}>
  //       {imageUri && <Image source={{ uri: imageUri }} style={styles.productImage} />}
  //       <View>
  //         <Text style={styles.productTitle}>{item.title}</Text>
  //         <Text style={styles.productPrice}>{item.price} Rs</Text>
  //       </View>
  //     </View>
  //   );
  // };

  // return (
  //   <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.lightWhite }}>
  //     <View style={styles.searchContainer}>
  //       <Feather name="search" size={24} style={styles.searchIcon} />
  //       <View style={styles.searchWrapper}>
  //         <TextInput
  //           style={styles.searchInput}
  //           value={searchText}
  //           onChangeText={setSearchText}
  //           placeholder="What are you looking for?"
  //         />
  //       </View>
  //       <TouchableOpacity style={styles.searchBtn}>
  //         <Ionicons name="camera-outline" size={SIZES.xLarge} color={COLORS.offwhite} />
  //       </TouchableOpacity>
  //     </View>

  //     <FlatList
  //       data={filteredProducts}
  //       keyExtractor={(item) => item.id?.toString()}
  //       renderItem={renderItem}
  //       contentContainerStyle={{ padding: SIZES.medium }}
  //       ListEmptyComponent={
  //         searchText.length > 0 ? (
            
  //         <Text style={styles.noProduct}>No products found</Text>
  //         ) : null
  //       }
  //     />
  //   </SafeAreaView>
  // );
 // };


 return (
    <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.lightWhite }}>
      <View style={styles.searchContainer}>
        <Feather name="search" size={24} style={styles.searchIcon} />
        <View style={styles.searchWrapper}>
          <TextInput
            style={styles.searchInput}
            value={searchText}
            onChangeText={setSearchText}
            placeholder="What are you looking for?"
          />
        </View>
        <TouchableOpacity style={styles.searchBtn}>
          <Ionicons name="camera-outline" size={SIZES.xLarge} color={COLORS.offwhite} />
        </TouchableOpacity>
      </View>

      <FlatList
        data={filteredProducts}
        keyExtractor={(item) => item.id?.toString()}
        renderItem={({ item }) => <ProductCardView product={item} />}
        numColumns={2}
        columnWrapperStyle={{ justifyContent: 'space-between', marginBottom: 16 }}
  contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 16, paddingBottom: 100 }}
        ListEmptyComponent={
          searchText.length > 0 ? (
            <Text style={styles.noProduct}>No products found</Text>
          ) : null
        }
      />
    </SafeAreaView>
  );
};


export default Search;










