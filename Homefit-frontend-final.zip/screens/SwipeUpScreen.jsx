import React, { useEffect, useRef } from 'react';
import { View, Text, Image, Animated, PanResponder, StyleSheet, Dimensions } from 'react-native';
import { EvilIcons } from '@expo/vector-icons';
import { COLORS } from '../assets/constants';

const { height } = Dimensions.get('window'); // Get screen height


const SwipeUpScreen = ({ navigation }) => {
  const translateY = useRef(new Animated.Value(0)).current;
  const bounceAnim = useRef(new Animated.Value(0)).current;

  
  // Bounce Animation for the Arrow (Every 2 seconds)
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(bounceAnim, { toValue: -10, duration: 500, useNativeDriver: true }),
        Animated.timing(bounceAnim, { toValue: -0, duration: 500, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  // Swipe Gesture Handling
  const panResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderMove: (evt, gestureState) => {
      if (gestureState.dy < 0) {
        translateY.setValue(gestureState.dy);
      }
    },
    onPanResponderRelease: (evt, gestureState) => {
      if (gestureState.dy < -50) {
        Animated.timing(translateY, {
          toValue: -height, // Move off-screen
          duration: 500,
          useNativeDriver: true,
        }).start(() => {
          navigation.replace('BottomTabNavigation'); // Navigate after swipe-up
        });
      } else {
        Animated.spring(translateY, {
          toValue: 0,
          useNativeDriver: true,
        }).start();
      }
    },
  });


  
  return (
    <View style={styles.container} {...panResponder.panHandlers}>
      <Animated.View style={[styles.content, { transform: [{ translateY }] }]}>
        <Image source={require('../assets/images/logo.png')} style={styles.logo} />
        <Text style={styles.text1}>HomeFit</Text>

        {/* Animated Jumping Arrow */}
    
  <Animated.View style={[styles.iconWrapper, { transform: [{ translateY: bounceAnim }] }]}>
    <EvilIcons name="arrow-up" size={50} color={'#FFF'} />
  </Animated.View>


        <Text style={styles.text}>Swipe up to open</Text>
      </Animated.View>
    </View>
  );
};

export default SwipeUpScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.primary || '#2F4F4F', // Fallback color if COLORS.primary is undefined
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'visible'
  },
  content: {
    alignItems: 'center',
    flexDirection: 'column',
    paddingBottom: 50,
    overflow:'visible'
  },
  logo: {
    width: 300,
    height: 300,
    resizeMode: 'contain',
    // marginBottom: 50, // Adjusted spacing
  },
  iconWrapper: {
    height: 60,
  },
  text: {
    fontSize: 18,
    color: '#FFF',
    textAlign: 'center',
    fontFamily: 'regular',  
  },
  text1: {
    fontSize: 40,
    color: COLORS.white,
    textAlign: 'center',
    fontFamily: 'Kaushan',
    marginTop: -120,
    marginBottom: 170
  }
});
