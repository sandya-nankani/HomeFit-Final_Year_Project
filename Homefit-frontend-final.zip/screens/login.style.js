import { StyleSheet, Text, View } from 'react-native'
import { COLORS, SIZES } from '../assets/constants'
import { ErrorMessage } from 'formik';

const styles = StyleSheet.create({
    cover: {
        height: SIZES.height/2.4,
        width: SIZES.width-60,
        resizeMode: "contain",
        marginBottom: SIZES.xxLarge
    },
    title: {
        fontFamily: "bold",
        fontSize: SIZES.xLarge,
        color: COLORS.primary,
        alignItems: "center",
        marginBottom: SIZES.xLarge
    },
    wrapper: {
        marginBottom: 20,
    },
    label:  {
        fontFamily: "regular",
        fontSize: SIZES.xSmall,
        marginBottom: 5,
        marginEnd: 5,
        textAlign: "right"
    },
    inputWrapper: (borderColor)=> ({
        borderColor: borderColor,
        backgroundColor: COLORS.lightWhite,
        borderWidth: 1,
        height: 50,
        borderRadius: 12,
        flexDirection: 'row',
        paddingHorizontal: 15,
        alignItems: "center"
    }),
    iconStyle: {
        marginRight: 10
    },
    errorMessage: {
        color: COLORS.red,
        fontFamily: "regular",
        marginTop: 5,
        marginLeft: 5,
        fontSize: SIZES.xSmall
    },
    NoAccount: {
        textAlign: "center",
    },
    registration: {
        marginTop: 5,
        marginBottom: 50,
        textAlign: "center",
        color: COLORS.primary,
        fontFamily: "semiBold",
        fontSize: SIZES.medium
    },
    forgotPass: {
        marginBottom: 10,
       color: COLORS.primary ,
       fontFamily: "semiBold" 
      },
      otpContainer: {
        flexDirection: "row",
        justifyContent: "space-between",
        width: "70%",
        marginBottom: 20,
        marginLeft: 50
      },
      otpInput: {
        width: 50,
        height: 50,
        borderWidth: 1,
        borderColor: COLORS.lightGray,
        textAlign: "center",
        fontSize: 20,
        borderRadius: 10,
        backgroundColor: "white"
      },
});



export default styles;