import React, { useState, useEffect } from 'react';
import {View, Text, TextInput, Image,
  ScrollView, StyleSheet, TouchableOpacity
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { COLORS, SIZES } from '../assets/constants';
import base64 from 'react-native-base64';




const arrayBufferToBase64 = (buffer) => {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return base64.encode(binary);
};

const getImageUriFromByteArray = (byteArray) => {
  if (!byteArray || !Array.isArray(byteArray)) return null;
  const base64String = arrayBufferToBase64(byteArray);
  return `data:image/jpeg;base64,${base64String}`;
};


const ManageUsers = ({ navigation }) => {
  const [name, setName] = useState('');
  const [image, setImage] = useState(null);
  const [users, setUsers] = useState([]);

  useEffect(() => {
    loadUsers();
  }, []);

  
  const loadUsers = async () => {
    try {
    const response = await fetch('http://172.16.150.254:3000/user');
    const data = await response.json();
    setUsers(data);
  } catch (error) {
    console.error('Failed to fetch Users', error);
  }
  };

//   const saveCategories = async (categoriesList) => {
//     try {
//       const jsonValue = JSON.stringify(categoriesList);
//       await AsyncStorage.setItem('categories', jsonValue);
//     } catch (e) {
//       console.error('Failed to save categories', e);
//     }
//   };

//   const handleAddCategory = async () => {
//   if (!name || !image) {
//     alert('Please enter name and pick an image');
//     return;
//   }

//   const formData = new FormData();
//   formData.append('name', name);
//   formData.append('file', {
//     uri: image,
//     name: `${Date.now()}.jpg`,
//     type: 'image/jpeg',
//   });

//   try {
//     const response = await fetch('http://172.16.150.254:3000/categories/create', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'multipart/form-data',
//       },
//       body: formData,
//     });

//     const result = await response.json();
//     if (!response.ok) {
//       throw new Error(result.message || 'Failed to add category');
//     }

//     const updatedCategories = [...categories, result];
//     setCategories(updatedCategories);
//     saveCategories(updatedCategories);

//     setName('');
//     setImage(null);

//     alert('✅ Category added successfully!');
//   } catch (error) {
//     console.error('Upload failed:', error);
//     alert('❌ Failed to add category.');
//   }
// };



//   const pickImage = async () => {
//     const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
//     if (status !== 'granted') {
//       alert('Permission required to access media library');
//       return;
//     }

//     const result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       quality: 1,
//     });

//     if (!result.canceled && result.assets?.length > 0) {
//       setImage(result.assets[0].uri);
//     }
//   };



const handleDeleteUser = async (index) => {
  const userId = users[index].id;

  try {
    const response = await fetch(`http://172.16.150.254:3000/user/${userId}`, {
      method: 'DELETE',
    });
    const result = await response.json(); // parse once here

    if (!response.ok) {
      alert(result.message );
      return;
    }
    // Only proceed if deletion was successful
    const updatedUsers = [...users];
    updatedUsers.splice(index, 1);
    setUsers(updatedUsers);
    // await saveUsers(updatedUsers);
    alert('🗑️ User deleted successfully');
  } catch (error) {
    console.error('Delete user failed:', error);
    alert(error.message || 'Failed to delete user.');
  }
};





  
  return (
    <ScrollView contentContainerStyle={styles.container}>
      

      <Text style={styles.heading}>Users List</Text>
      

{users.map((user, index) => {
//   const imageData = category.image?.data || category.image;
//   const imageUri = getImageUriFromByteArray(imageData);

  return (
    <View key={index} style={styles.categoryRow}>
      {/* {imageUri && (
        <Image source={{ uri: imageUri }} style={styles.categoryImage} />
      )} */}
      <View style={styles.userDetails}>
        <Text style={styles.user}>User Id: {user.id}</Text>
        <Text style={styles.user}>User Name: {user.userName}</Text>
        <Text style={styles.user}>Email: {user.userName}</Text>
        <Text style={styles.user}>Phone: {user.phone}</Text>
        <Text style={styles.user}>Address: {user.address}</Text>
        <View style={styles.buttonsContainer}>
         

          {/* <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: COLORS.green }]}
           onPress={() => navigation.navigate('EditCategory', { id: category.id })}
            >
              <Text style={styles.actionBtnText}>Update</Text>
           </TouchableOpacity> */}


          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: COLORS.red }]}
            onPress={() => handleDeleteUser(index)}
          >
            <Text style={styles.actionBtnText}>Delete</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
})}






    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: SIZES.xLarge,
    padding: 16,
    backgroundColor: '#fff',
  },
  heading: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 10,
    color: COLORS.primary
  },
  input: {
    borderWidth: 1,
    borderColor: '#aaa',
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
  },
  imageButton: {
    backgroundColor: COLORS.primary,
    padding: 10,
    borderRadius: 8,
    marginBottom: 10,
    alignItems: 'center',
  },
  imageButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  addBtn: {
    backgroundColor: COLORS.blue,
    padding: 10,
    borderRadius: 8,
    marginBottom: 10,
    alignItems: 'center',
  },
  addBtnText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  imagePreview: {
    width: 100,
    height: 100,
    marginBottom: 10,
    borderRadius: 8,
  },
  categoryRow: {
  flexDirection: 'row',
  alignItems: 'center',
  marginBottom: 16,
  backgroundColor: COLORS.offwhite,
  padding: 10,
  borderRadius: 10,
  elevation: 2,
  shadowColor: '#000',
  shadowOpacity: 0.1,
  shadowRadius: 3,
},

categoryImage: {
  width: 60,
  height: 60,
  borderRadius: 8,
  marginRight: 10,
},

userDetails: {
  flex: 1,
  flexDirection: 'column',
  justifyContent: 'center',
},

user: {
  fontSize: 16,
  fontWeight: 'bold',
  marginBottom: 5,
},

buttonsContainer: {
  flexDirection: 'row',
  justifyContent: 'flex-end', // align buttons left inside the text+button area
  gap: 10,
 
},

actionBtn: {
  paddingVertical: 6,
  paddingHorizontal: 12,
  borderRadius: 6,
  justifyContent: 'center',
  alignItems: 'center',
},

actionBtnText: {
  color: '#fff',
  fontWeight: '600',
},


actionBtn: {
  paddingVertical: 6,
  paddingHorizontal: 12,
  borderRadius: 6,
  justifyContent: 'center',
  alignItems: 'center',
  marginLeft: 10,  // ensure some spacing between buttons
},


actionBtnText: {
  color: '#fff',
  fontWeight: 'bold',
},

});

export default ManageUsers;