

import { Text, TouchableOpacity, View, Image, ScrollView, FlatList } from 'react-native'; // ⬅️ Added ScrollView and FlatList
import React, { useEffect, useState } from 'react';
import styles from './productDetails.style';
import {
  Fontisto,
  Ionicons,
  MaterialCommunityIcons,
  SimpleLineIcons,
} from '@expo/vector-icons';
import { COLORS, SIZES } from '../assets/constants';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { Alert } from 'react-native';
import { TextInput } from 'react-native-gesture-handler';
import { KeyboardAvoidingView, Platform, TouchableWithoutFeedback, Keyboard } from 'react-native';







const arrayBufferToBase64 = (buffer) => {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};

const getImageUriFromByteArray = (byteArray) => {
  if (!byteArray || !Array.isArray(byteArray)) return null;
  const base64String = arrayBufferToBase64(byteArray);
  return `data:image/jpeg;base64,${base64String}`;
};
const ProductDetails = ({ navigation, route }) => {
  const { product } = route.params;
  
  const [count, setCount] = useState(1);
  const increment = () => setCount(count + 1);
  const decrement = () => count > 1 && setCount(count - 1);

  const [reviews, setReviews] = useState([]);
  const [newReview, setNewReview] = useState('');
   const [reviewText, setReviewText] = useState('');


  const handleSubmitReview = async () => {
    console.log('Review text:', reviewText); 


    if (!reviewText ) {
      Alert.alert('Error', 'Please enter a review.');
      return;
    }

   
      try {
    // Get logged in user from AsyncStorage
    const userData = await AsyncStorage.getItem('user');
    if (!userData) {
      Alert.alert('Login Required', 'Please log in to post a review.');
      return;
    }
    const user = JSON.parse(userData);
    console.log("user:", user.id)
    
       console.log("product:", product.id)

      const response = await axios.post('http://172.16.150.254:3000/reviews/create', {
        comment: reviewText,          
      userId: user.id,                
      productId: product.id  
      });

   
      Alert.alert('Success', 'Review submitted successfully');
      setReviewText('');
     
      console.log('Response:', response.data);
    } catch (error) {
      console.error('Error submitting review:', error);
      Alert.alert('Error', 'Could not submit review.');
    }
    }
  


  useEffect(() => {
    fetchReviews();
  }, []);

  const fetchReviews = async () => {
    try {
      const response = await axios.get(`http://172.16.150.254:3000/reviews/product/${product.id}`);
      setReviews(response.data);
    } catch (error) {
      // console.error('🛑 Failed to fetch reviews:', error.message);
    }
  };

  
  const imageUri = product?.image?.data
    ? getImageUriFromByteArray(product.image.data)
    : typeof product.image === 'string'
    ? product.image
    : null;

  const addToCart = async (product) => {
    try {
      const userData = await AsyncStorage.getItem('user');
      if (!userData) {
        Alert.alert('Login Required', 'Please log in first.');
        return;
      }
      const user = JSON.parse(userData);
      const quantity = count;

      await axios.post('http://172.16.150.254:3000/cart/add', {
        user: user.id,
        product: product.id,
        quantity,
        totalPrice: product.price,
      });

      Alert.alert('Success', '✅ Product added to cart successfully!');
      console.log("product:", product.fileType)
      console.log("product name:", product.filename)
    } catch (err) {
      Alert.alert('Error', '🛑 Failed to add product to cart');
      console.log(err)
    }
  };

  return (
  <KeyboardAvoidingView
    style={{ flex: 1 }}
    behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
  >
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
   <ScrollView
  style={styles.container} // keep colors, padding, margins here
  contentContainerStyle={styles.contentContainer} // move flex layout stuff here
  showsVerticalScrollIndicator={false}
>

      {/* Top Navigation */}
      <View style={styles.upperRow}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back-circle" size={30} color={COLORS.primary}/>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => {}}>
          <Ionicons name="heart" size={30} color={COLORS.gray} />
        </TouchableOpacity>
      </View>

      {/* Product Image */}
      {imageUri && (
        <Image source={{ uri: imageUri }} style={styles.image} />
      )}


      {/* Details Section */}
      <View style={styles.details}>
        {/* Title and Price */}
        <View style={styles.titleRow}>
          <Text style={styles.title} numberOfLines={2} ellipsizeMode="tail">
            {product?.title || 'Product'}
          </Text>
          <View style={styles.priceWrapper}>
            <Text style={styles.price}>Rs. {product.price.toLocaleString()}</Text>
          </View>
        </View>

        {/* Rating and Quantity */}
        <View style={styles.ratingRow}>
          <View style={styles.rating}>
            {[1, 2, 3, 4, 5].map((index) => (
              <Ionicons key={index} name="star" size={24} color="gold" />
            ))}
            <Text style={styles.ratingText}> (4.9) </Text>
          </View>
          <View style={styles.rating}>
            <TouchableOpacity onPress={decrement}>
              <SimpleLineIcons name="minus" size={20} />
            </TouchableOpacity>
            <Text style={styles.ratingText}>{count}</Text>
            <TouchableOpacity onPress={increment}>
              <SimpleLineIcons name="plus" size={20} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Description */}
        <View style={styles.descriptionWrapper}>
          <Text style={styles.description}>Description</Text>
          <Text style={styles.descText}>
            {product?.description || 'No description available for this product.'}
          </Text>
        </View>

        {/* Location and Delivery */}
        <View style={{ marginBottom: SIZES.small }}>
          <View style={styles.location}>
            <View style={{ flexDirection: 'row' }}>
              <Ionicons name="location-outline" size={20} />
              <Text> Karachi </Text>
            </View>
            <View style={{ flexDirection: 'row' }}>
              <MaterialCommunityIcons name="truck-delivery-outline" size={20} />
              <Text> Free Delivery </Text>
            </View>
          </View>
        </View>

        {/* Buy / Cart Buttons */}
        <View style={styles.cartRow}>
          <TouchableOpacity onPress={() => {}} style={styles.cartBtn}>
            <Text style={styles.cartTitle}  
     onPress={() => navigation.navigate('CheckoutScreen', {product})}
      >BUY NOW </Text>
            
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => addToCart(product)}
            style={styles.addCart}>
            <Fontisto name="shopping-bag" size={22} color={COLORS.lightWhite} />
          </TouchableOpacity>
        </View>

        

{product?.modelUrl && (
  <TouchableOpacity
    style={[styles.cartBtn2, { backgroundColor: '#287f2bff' }]}
    onPress={() =>
      navigation.navigate('ARExperience', {
        product: {
          modelUrl: product.modelUrl,
          width: product.width || 1,
          height: product.height || 1,
          depth: product.depth || 1,
        },
      })
    }
  >
    <Text style={styles.cartTitle}>View in AR</Text>
  </TouchableOpacity>
)}


      </View>

      {/* Reviews Section */}
      <View style={{ marginTop: 20, marginBottom: 100, padding: 10 }}>
        <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 10, color: COLORS.primary }}>Reviews</Text>

        {reviews.length === 0 ? (
          <Text style={{ fontStyle: 'italic' }}>No reviews yet.</Text>
        ) : (
          reviews.map((item, index) => ( // ⬅️ Changed from FlatList for simplicity in ScrollView
            <View key={index} style={{ marginBottom: 10, backgroundColor: '#f0f0f0', padding: 10, borderRadius: 6 }}>
              <Text style={{ fontWeight: '600' }}>{item.user?.userName || 'User'}:</Text>
              <Text>{item.comment}</Text>
            </View>
          ))
        )}

        {/* Add a Review */}
        <TextInput
  value={reviewText} // ✅ use same variable here
  onChangeText={(text) => {
    console.log('User typing:', text);
    setReviewText(text); // ✅ updating the same variable
  }}
  placeholder="Write your review..."
  multiline
  numberOfLines={4}
  style={{
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 6,
    padding: 10,
    marginTop: 10,
    marginBottom: 50,
    textAlignVertical: 'top',
  }}
/>

        <TouchableOpacity onPress={handleSubmitReview} style={[styles.cartBtn2, { backgroundColor: COLORS.primary }]}>
          <Text style={styles.cartTitle}>Submit Review</Text>
        </TouchableOpacity>
      </View>

    </ScrollView>
     </TouchableWithoutFeedback>
  </KeyboardAvoidingView>
  );
};

export default ProductDetails;





