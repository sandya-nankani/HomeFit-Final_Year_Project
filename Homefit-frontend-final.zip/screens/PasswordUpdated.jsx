import { ScrollView,  View, Text, Image, TextInput, TouchableOpacity, Alert } from 'react-native'
import React, {useState} from 'react'
import { SafeAreaView } from 'react-native-safe-area-context';
import BackBtn from '../components/BackBtn';
import styles from './login.style';
import Button from '../components/Button';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS, SIZES } from '../assets/constants';



const PasswordUpdated = ({navigation}) => {

  return (
    <ScrollView>
        <SafeAreaView style={{marginHorizontal: 20}}>
            <View>
                <BackBtn onPress={() => navigation.goBack()}/>
                {/* <Image 
                source={require('../assets/images/bk.png')}
                style={{
                    height: SIZES.height/3,
                    width: SIZES.width-60,
                    resizeMode: "contain",
                    marginBottom: SIZES.xSmall
                }}
                /> */}


                              <MaterialCommunityIcons
                                name='check-decagram-outline'
                                size={170}
                                color= {COLORS.primary}
                                style= {styles.iconStyle}
                                justifyContent= {'center'}
                                flex= {1}
                                marginBottom={50}
                                marginTop={50}
                                marginHorizontal= {90}
                                />

             <Text style={{
                fontFamily: "bold",
                fontSize: SIZES.xLarge,
                color: COLORS.primary,
                alignItems: "center",
                marginBottom: SIZES.xSmall
             }}
             > Password Updated </Text> 
             <Text style={{
                marginBottom: 35,
                fontSize: SIZES.medium
                
             }}
             > Your Password has been updated, You can try signing in again</Text>
            
            {/* <MaterialCommunityIcons
                                name='check-decagram-outline'
                                size={120}
                                color= {COLORS.primary}
                                style= {styles.iconStyle}
                                alignItems= {'center'}
                    
                                /> */}
                <View> 
                
                <Button title={"S I G N    I N"} onPress={() => navigation.navigate('Login')} />
            </View> 
        
                 
             </View>  
             
        </SafeAreaView>
    </ScrollView>
  );
};

export default PasswordUpdated;