

import { ScrollView, View, Text, Image, TextInput, TouchableOpacity, Alert } from 'react-native';
import React, { useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import BackBtn from '../components/BackBtn';
import styles from './login.style';
import Button from '../components/Button';
import * as Yup from 'yup';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS, SIZES } from '../assets/constants';
import { Formik } from 'formik';
import axios from 'axios';
// import { apiClient } from '../apiClient'; // Import your axios instance

const validationSchema = Yup.object().shape({
  password: Yup.string()
    .min(8, 'Password must be at least 8 characters long')
    .required('Required'),
  email: Yup.string()
    .trim()
    .required('Email is required')
    .email('Invalid email format')
    .matches(
      /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
      'Invalid email format'
    ),
});

const LoginPage = ({ navigation }) => {
  const [obsecureText, setObsecureText] = useState(true);

  const handleLogin = async (values) => {
    try {
        const response = await axios.post('http://172.16.150.254:3000/auth/login', values);
        
        if(response.data.code === 200){
          const user = response.data.user;
          const accountType = user.accountType;

          console.log('user: ',user)
          console.log('accountType: ', accountType)
        console.log('Login Success:', response.data);

        await AsyncStorage.setItem('user', JSON.stringify(user));
      await AsyncStorage.setItem('isLoggedIn', 'true');


        Alert.alert('Success', 'Login successful!');
           console.log("user acccount type: ", accountType)

        if (accountType === 'admin') {
          navigation.navigate('AdminProfile', { user });
        } else {
          navigation.navigate('Profile');
        }
      } else {
          const errorMessage = response.data.message || 'Login unsuccessful!';
          Alert.alert('Error', 'Invalid username or password' );
         console.log('login unsuccessful',response.data);
        }
      } catch (error) {
        // console.error('Login Error:', error.response?.data || error.message);
        Alert.alert('Error', error.response?.data?.message || 'Invalid credentials.');
      }
  };

  return (
    <ScrollView>
      <SafeAreaView style={{ marginHorizontal: 20 }}>
        <View>
          <BackBtn onPress={() => navigation.goBack()} />
          <Image
            source={require('../assets/images/bk.png')}
            style={{
              height: SIZES.height / 3,
              width: SIZES.width - 60,
              resizeMode: 'contain',
              marginBottom: SIZES.xxLarge,
            }}
          />
          <Text style={styles.title}> Unlimited Luxurious Items </Text>

          <Formik
            initialValues={{ email: '', password: '' }}
            validationSchema={validationSchema}
            onSubmit={handleLogin} // Call API on submit
          >
            {({ handleChange, handleBlur, handleSubmit, touched, values, errors, isValid, setFieldTouched }) => (
              <View>
                {/* Email Input */}
                <View style={styles.wrapper}>
                  <View style={styles.inputWrapper(touched.email ? COLORS.secondary : COLORS.offwhite)}>
                    <MaterialCommunityIcons name="email-outline" size={20} color={COLORS.gray} style={styles.iconStyle} />
                    <TextInput
                      placeholder="Enter email"
                      onFocus={() => setFieldTouched('email')}
                      onBlur={() => setFieldTouched('email', false)}
                      value={values.email}
                      onChangeText={handleChange('email')}
                      autoCapitalize="none"
                      autoCorrect={false}
                      style={{ flex: 1 }}
                    />
                  </View>
                  {touched.email && errors.email && <Text style={styles.errorMessage}>{errors.email}</Text>}
                </View>

                {/* Password Input */}
                <View style={styles.wrapper}>
                  <View style={styles.inputWrapper(touched.password ? COLORS.secondary : COLORS.offwhite)}>
                    <MaterialCommunityIcons name="lock-outline" size={20} color={COLORS.gray} style={styles.iconStyle} />
                    <TextInput
                      secureTextEntry={obsecureText}
                      placeholder="Password"
                      onFocus={() => setFieldTouched('password')}
                      onBlur={() => setFieldTouched('password', false)}
                      value={values.password}
                      onChangeText={handleChange('password')}
                      autoCapitalize="none"
                      autoCorrect={false}
                      style={{ flex: 1 }}
                    />
                    <TouchableOpacity onPress={() => setObsecureText(!obsecureText)}>
                      <MaterialCommunityIcons name={obsecureText ? 'eye-outline' : 'eye-off-outline'} size={18} />
                    </TouchableOpacity>
                  </View>
                  {touched.password && errors.password && <Text style={styles.errorMessage}>{errors.password}</Text>}
                </View>

                <Text style={styles.forgotPass} onPress={() => navigation.navigate('ForgotPassword')}>
                  Forgot Password?
                </Text>

                <Button title={'L O G I N'} onPress={isValid ? handleSubmit : () => Alert.alert('Invalid Form', 'Please fill in all required fields.')} isValid={isValid} />

                <View style={{ flexDirection: 'column' }}>
                  <Text style={styles.NoAccount}>Don't have an account?</Text>
                  <TouchableOpacity onPress={() => navigation.navigate('SignUp')}>
                    <Text style={styles.registration}>Sign up</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          </Formik>
        </View>
      </SafeAreaView>
    </ScrollView>
  );
};

export default LoginPage;
