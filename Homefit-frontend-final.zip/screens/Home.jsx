
import { StyleSheet, Text, TouchableOpacity, View , ScrollView, ActivityIndicator, FlatList, } from 'react-native'
import React, { useEffect, useState } from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Fontisto, Ionicons } from '@expo/vector-icons'
import styles from './home.style'
import { Welcome } from '../components'
import  Carousel from '../components/home/Carousel'
import Headings from '../components/home/Headings'
import Products from '../components/products/ProductRow'
import BottomTabNavigation from '../navigation/BottomTabNavigation'
import Categories from '../components/home/Categories'
import ProductCardView from 'components/products/ProductCardView'
import { useNavigation } from '@react-navigation/native';
import { Buffer } from 'buffer';


const getImageUriFromByteArray = (byteArray) => {
  if (!byteArray || !Array.isArray(byteArray)) return null;
  const base64String = btoa(
    byteArray.map((byte) => String.fromCharCode(byte)).join('')
  );
  return `data:image/jpeg;base64,${base64String}`;
};

const Home = () => {
   const [selectedCategoryId, setSelectedCategoryId] = useState(null);
  const [selectedCategoryName, setSelectedCategoryName] = useState('');
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigation = useNavigation();
  const [cartItemCount, setCartItemCount] = useState(0);
   const [sortOption, setSortOption] = useState('');


   const fetchCartCount = async () => {
    try {
      // Replace with your API endpoint to get cart items count for current user
      const response = await fetch('http://172.16.150.254:3000/cart/count');
      const data = await response.json();
      // Assuming response is { count: number }
      setCartItemCount(data.count || 0);
    } catch (err) {
      console.error('Error fetching cart count:', err);
    }
  };

  // Call fetchCartCount on mount and optionally when cart updates
  useEffect(() => {
    fetchCartCount();
  }, []);



  const fetchAllProducts = async () => {
    try {
      setLoading(true);
      const res = await fetch('http://172.16.150.254:3000/products');
      const data = await res.json();
      setProducts(data);
    } catch (err) {
      console.error('Error fetching all products:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchProductsByCategory = async (categoryId) => {
    try {
      setLoading(true);
      const res = await fetch(`http://172.16.150.254:3000/products/category/${categoryId}`);
      const data = await res.json();
      setProducts(data);
    } catch (err) {
      console.error('Error fetching products by category:', err);
    } finally {
      setLoading(false);
    }
  };




const sortedProducts = React.useMemo(() => {
  if (!products) return [];

  let sorted = [...products];

  switch (sortOption) {
    case 'oldToNew':
      sorted.sort((a, b) => new Date(a.createdAt || 0) - new Date(b.createdAt || 0));
      break;
    case 'newToOld':
      sorted.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
      break;
    case 'lowToHigh':
      sorted.sort((a, b) => a.price - b.price);
      break;
    case 'highToLow':
      sorted.sort((a, b) => b.price - a.price);
      break;
    case 'A-Z/a-z':
      sorted.sort((a, b) => (a.title || '').localeCompare(b.title || ''));
      break;
    case 'Z-A/z-a':
      sorted.sort((a, b) => (b.title || '').localeCompare(a.title || ''));
      break;
    default:
      break;
  }

  return sorted;
}, [products, sortOption]);





const handleCategorySelect = (categoryId, categoryName) => {
  if (categoryName === 'All') {
    // If 'All' category is selected
    setSelectedCategoryId(null);
    setSelectedCategoryName('All');
    fetchAllProducts();
  } else if (categoryId === selectedCategoryId) {
    // Deselect same category and show all
    setSelectedCategoryId(null);
    setSelectedCategoryName('All');
    fetchAllProducts();
  } else {
    // Select specific category
    setSelectedCategoryId(categoryId);
    setSelectedCategoryName(categoryName);
    fetchProductsByCategory(categoryId);
  }
};


   useEffect(() => {
    fetchAllProducts();
  }, []);

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <View style={styles.appBarWrapper}>
        <View style={styles.appBar}>
          <Ionicons name='location-outline' size={24}/>
             
          <Text style={styles.location}> Pakistan </Text>

        <View style={{ alignItems: 'flex-end', flexDirection: 'row', alignItems: 'center' }}>
            {cartItemCount > 0 && (
              <View style={styles.cartCount}>
                <Text style={styles.cartNumber}>{cartItemCount}</Text>
              </View>
            )}
        <TouchableOpacity onPress={() => navigation.navigate('Cart')}>
         <Fontisto name="shopping-bag" size={24} style={{ marginRight: 10 }} />
          </TouchableOpacity>
        </View>
      </View>
      </View>

<FlatList
  // data={products}
    data={sortedProducts}
  keyExtractor={(item) => item.id.toString()}
  renderItem={({ item }) => <ProductCardView product={item} />}
  numColumns={2}
  columnWrapperStyle={{ gap: 10, marginBottom: 16 }}
  

  ListHeaderComponent={
    <>
      <Welcome />
      <Carousel />
      <Categories onSelectCategory={handleCategorySelect} selectedCategoryId={selectedCategoryId} />

     <Headings
              title={selectedCategoryName || 'Best Selling'}
               onFilterChange={setSortOption} 
            />
    </>
  }
  contentContainerStyle={{ paddingBottom: 80 }}
  showsVerticalScrollIndicator={false}
  ListEmptyComponent={() => 
    loading ? (
       <ActivityIndicator size="large" color="#888" style={{ marginTop: 40 }} />
  ) : (
    <Text style={{ textAlign: 'center', marginTop: 40, fontSize: 16, color: 'gray' }}>
      No products available at this moment
    </Text>
  )}
/>
      
      </SafeAreaView>
      
  )
}

export default Home




















// import { StyleSheet, Text, TouchableOpacity, View , ScrollView } from 'react-native'
// import React from 'react'
// import { SafeAreaView } from 'react-native-safe-area-context'
// import { Fontisto, Ionicons } from '@expo/vector-icons'
// import styles from './home.style'
// import { Welcome } from '../components'
// import  Carousel from '../components/home/Carousel'
// import Headings from '../components/home/Headings'
// import ProductRow from '../components/products/ProductRow'
// import BottomTabNavigation from '../navigation/BottomTabNavigation'
// import Categories from '../components/home/Categories'

// const Home = () => {
  
//   return (
//     <SafeAreaView style={{ flex: 1 }}>
//       <View style={styles.appBarWrapper}>
//         <View style={styles.appBar}>
//           <Ionicons name='location-outline' size={24}/>
             
//           <Text style={styles.location}> Pakistan </Text>

//         <View style={{ alignItems: "flex-end"}}>
//           <View style={styles.cartCount}>
//                 <Text style={styles.cartNumber}> 8 </Text>
//         </View>

//         <TouchableOpacity>
//           <Fontisto name="shopping-bag" size={24} marginRight={10}/>
//         </TouchableOpacity>

//         </View>
//       </View>
//       </View>

//       <ScrollView 
//       contentContainerStyle={{ paddingBottom: 80 }}
//       showsVerticalScrollIndicator={false}
// >
//         <Welcome/>
//         <Carousel/>
//         <Categories/>
//         <Headings/>
//         <ProductRow/>
    
//       </ScrollView>
      
//       </SafeAreaView>
      
//   )
// }

// export default Home











