import React, { useState, useEffect } from 'react';
import {View, Text, TextInput, Image,
  ScrollView, StyleSheet, TouchableOpacity
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { COLORS, SIZES } from '../assets/constants';
import base64 from 'react-native-base64';





const arrayBufferToBase64 = (buffer) => {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return base64.encode(binary);
};

const getImageUriFromByteArray = (byteArray) => {
  if (!byteArray || !Array.isArray(byteArray)) return null;
  const base64String = arrayBufferToBase64(byteArray);
  return `data:image/jpeg;base64,${base64String}`;
};


const ManageOrders = ({ navigation }) => {
  const [name, setName] = useState('');
  const [image, setImage] = useState(null);
  const [users, setUsers] = useState([]);
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    loadOrders();
  }, []);

  
  const loadOrders = async () => {
    try {
    const response = await fetch('http://172.16.150.254:3000/order');
    const data = await response.json();
    setOrders(data);
  } catch (error) {
    console.error('Failed to fetch Orders', error);
  }
  };


const handleDeleteOrder = async (index) => {
  const OrderId = orders[index].id;

  try {
    const response = await fetch(`http://172.16.150.254:3000/order/${OrderId}`, {
      method: 'DELETE',
    });
    const result = await response.json(); // parse once here

    if (!response.ok) {
      alert(result.message );
      return;
    }
    // Only proceed if deletion was successful
    const updatedOrders = [...orders];
    updatedOrders.splice(index, 1);
    setOrders(updatedOrders);
    // await saveOrders(updatedOrders);
    alert('🗑️ Order deleted successfully');
  } catch (error) {
    console.error('Delete Order failed:', error);
    alert(error.message || 'Failed to delete Order.');
  }
};





  
  return (
    <ScrollView contentContainerStyle={styles.container}>
      

      <Text style={styles.heading}>Orders List</Text>
      
{orders.map((order, index) => (
  <View key={index} style={styles.categoryRow}>
    <View style={styles.userDetails}>
      <Text style={styles.user}>Order ID: {order.id}</Text>
      <Text style={styles.user}>Customer: {order.firstName} {order.lastName}</Text>
      <Text style={styles.user}>Email: {order.email}</Text>
      <Text style={styles.user}>Phone: {order.mobileNo}</Text>
      <Text style={styles.user}>Address: {order.address}</Text>

     <View style={styles.buttonsContainer}>
  <TouchableOpacity
    style={[styles.actionBtn, { backgroundColor: COLORS.primary }]}
    onPress={() => navigation.navigate('ViewOrder', { order: order })}
  >
    <Text style={styles.actionBtnText}>View Order</Text>
  </TouchableOpacity>

  {/* <TouchableOpacity
    style={[styles.actionBtn, { backgroundColor: COLORS.red }]}
    onPress={() => handleDeleteOrder(index)}
  >
    <Text style={styles.actionBtnText}>Delete</Text>
  </TouchableOpacity> */}
</View>


    </View>
  </View>
))}








    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: SIZES.xLarge,
    padding: 16,
    backgroundColor: '#fff',
  },
  heading: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 10,
    color: COLORS.primary
  },
  input: {
    borderWidth: 1,
    borderColor: '#aaa',
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
  },
  imageButton: {
    backgroundColor: COLORS.primary,
    padding: 10,
    borderRadius: 8,
    marginBottom: 10,
    alignItems: 'center',
  },
  imageButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  addBtn: {
    backgroundColor: COLORS.blue,
    padding: 10,
    borderRadius: 8,
    marginBottom: 10,
    alignItems: 'center',
  },
  addBtnText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  imagePreview: {
    width: 100,
    height: 100,
    marginBottom: 10,
    borderRadius: 8,
  },
  categoryRow: {
  flexDirection: 'row',
  alignItems: 'center',
  marginBottom: 16,
  backgroundColor: COLORS.offwhite,
  padding: 10,
  borderRadius: 10,
  elevation: 2,
  shadowColor: '#000',
  shadowOpacity: 0.1,
  shadowRadius: 3,
},

categoryImage: {
  width: 60,
  height: 60,
  borderRadius: 8,
  marginRight: 10,
},

userDetails: {
  flex: 1,
  flexDirection: 'column',
  justifyContent: 'center',
},

user: {
  fontSize: 16,
  fontWeight: 'bold',
  marginBottom: 5,
},

buttonsContainer: {
  flexDirection: 'row',
  justifyContent: 'flex-end', // align buttons left inside the text+button area
  gap: 10,
 
},

actionBtn: {
  paddingVertical: 6,
  paddingHorizontal: 12,
  borderRadius: 6,
  justifyContent: 'center',
  alignItems: 'center',
},

actionBtnText: {
  color: '#fff',
  fontWeight: '600',
},


actionBtn: {
  paddingVertical: 6,
  paddingHorizontal: 12,
  borderRadius: 6,
  justifyContent: 'center',
  alignItems: 'center',
  marginLeft: 10,  // ensure some spacing between buttons
},


actionBtnText: {
  color: '#fff',
  fontWeight: 'bold',
},

});

export default ManageOrders;