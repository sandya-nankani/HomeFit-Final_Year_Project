

// // screens/ARExperience.jsx
// import React, { useEffect, useRef, useState } from "react";
// import { View, Text, StyleSheet, PanResponder } from "react-native";
// import { CameraView, useCameraPermissions } from "expo-camera";
// import { GLView } from "expo-gl";
// import { Renderer } from "expo-three";
// import * as THREE from "three";
// import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader";
// import { useRoute } from "@react-navigation/native";

// export default function ARExperience() {
//   const route = useRoute();
//   const { product } = route.params;
//   console.log('🚀 ARExperience received product:', product);
//   const { modelUrl, width, height, depth } = product;

//   const [permission, requestPermission] = useCameraPermissions();
//   const [cameraZoom, setCameraZoom] = useState(0); // 0 to 1 zoom
//   const modelRef = useRef(null);
//   const lastPan = useRef({ x: 0, y: 0 });
//   const lastDistance = useRef(0);
//   const baseScale = useRef(1); // initial model scale

//   useEffect(() => {
//     if (permission && !permission.granted) requestPermission();
//   }, [permission]);

//   const onContextCreate = async (gl) => {
//     const { drawingBufferWidth: widthPx, drawingBufferHeight: heightPx } = gl;
//     const renderer = new Renderer({ gl });
//     renderer.setSize(widthPx, heightPx);

//     const scene = new THREE.Scene();
//     const camera = new THREE.PerspectiveCamera(75, widthPx / heightPx, 0.1, 1000);
//     camera.position.z = 2;
//     scene.add(camera);

//     const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
//     const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
//     directionalLight.position.set(2, 4, 5);
//     scene.add(ambientLight, directionalLight);

//     const loader = new GLTFLoader();
//     try{
//     loader.load(
//       modelUrl,
//       (gltf) => {
//         const model = gltf.scene;

//         const box = new THREE.Box3().setFromObject(model);
//         const size = box.getSize(new THREE.Vector3());
//         const initialScale = width / size.x; // scale based on width
//         model.scale.set(
//           (width / size.x) * 0.8,
//           (height / size.y) * 0.8,
//           (depth / size.z) * 0.8
//         );
//         baseScale.current = model.scale.x; // store initial scale

//         const center = new THREE.Box3().setFromObject(model).getCenter(new THREE.Vector3());
//         model.position.sub(center);

//         scene.add(model);
//         modelRef.current = model;
//       },
//       undefined,
//       (error) => console.warn("❌ Error loading model:", error)
//     );
//   }
//   catch(e) {
    
//   }

//     const render = () => {
//       requestAnimationFrame(render);

//       // update model scale according to camera zoom
//       if (modelRef.current) {
//         const scaleFactor = 1 + cameraZoom; // simple proportional scaling
//         modelRef.current.scale.set(
//           baseScale.current * scaleFactor,
//           baseScale.current * scaleFactor,
//           baseScale.current * scaleFactor
//         );
//       }

//       renderer.render(scene, camera);
//       gl.endFrameEXP();
//     };
//     render();
//   };

//   const panResponder = useRef(
//     PanResponder.create({
//       onStartShouldSetPanResponder: () => true,
//       onMoveShouldSetPanResponder: () => true,
//       onPanResponderMove: (evt, gesture) => {
//         const touches = evt.nativeEvent.touches;

//         if (touches.length === 1 && modelRef.current) {
//           const deltaX = gesture.dx - lastPan.current.x;
//           const deltaY = gesture.dy - lastPan.current.y;
//           modelRef.current.rotation.y += deltaX * 0.01;
//           modelRef.current.rotation.x += deltaY * 0.01;
//           lastPan.current = { x: gesture.dx, y: gesture.dy };
//         }

//         if (touches.length === 2) {
//           const dx = touches[0].pageX - touches[1].pageX;
//           const dy = touches[0].pageY - touches[1].pageY;
//           const distance = Math.sqrt(dx * dx + dy * dy);

//           if (lastDistance.current > 0) {
//             const zoomChange = (distance - lastDistance.current) / 200;
//             setCameraZoom((prev) => Math.min(Math.max(prev + zoomChange, 0), 1));
//           }
//           lastDistance.current = distance;
//         }
//       },
//       onPanResponderRelease: () => {
//         lastPan.current = { x: 0, y: 0 };
//         lastDistance.current = 0;
//       },
//     })
//   ).current;

//   if (!permission) return <View style={styles.center}><Text>Checking camera permissions...</Text></View>;
//   if (!permission.granted) return <View style={styles.center}><Text>No access to camera</Text></View>;

//   return (
//     <View style={{ flex: 1 }} {...panResponder.panHandlers}>
//       <CameraView style={{ flex: 1 }} facing="back" zoom={cameraZoom}>
//         <GLView style={StyleSheet.absoluteFill} onContextCreate={onContextCreate} />
//       </CameraView>
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   center: { flex: 1, justifyContent: "center", alignItems: "center" },
// });









// screens/ARExperience.jsx
import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";
import { WebView } from "react-native-webview";
import { useRoute } from "@react-navigation/native";

export default function ARExperience() {
  const route = useRoute();
  const { product } = route.params;
  const { modelUrl } = product;

  const [permission, requestPermission] = useCameraPermissions();

  if (!permission) {
    return (
      <View style={styles.center}>
        <Text>Checking camera permissions...</Text>
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View style={styles.center}>
        <Text>No access to camera</Text>
        <Text onPress={requestPermission} style={styles.link}>
          Tap to grant permission
        </Text>
      </View>
    );
  }

  const html = `

    <html>
      <head>
        <script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>
        <style>
          html, body {
            margin: 0;
            padding: 0;
            height: 100%;
            background: transparent !important;
          }
          model-viewer {
            width: 100%;
            height: 100%;
            background: transparent !important;
             transform: translateY(15%); 
            transform-origin: center center;
          }
        </style>
      </head>
      <body>
        <model-viewer 
          src="${modelUrl}" 
           auto-rotate 
          camera-controls 
          ar 
          ar-modes="webxr scene-viewer quick-look"
          style="background: transparent;">
        </model-viewer>
      </body>
    </html>
  `;

  return (
    <View style={{ flex: 1 }}>
      {/* Background camera feed */}
      <CameraView style={StyleSheet.absoluteFill} facing="back" />

      {/* Overlayed 3D model */}
      <WebView
        originWhitelist={["*"]}
        source={{ html }}
        style={[StyleSheet.absoluteFill, { backgroundColor: "transparent" }]}
        javaScriptEnabled
        domStorageEnabled
        transparent
      />
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, justifyContent: "center", alignItems: "center" },
  link: { color: "blue", marginTop: 5, textDecorationLine: "underline" },
});







