


import { ScrollView, View, Text, Image, TextInput, TouchableOpacity, Alert } from 'react-native';
import React, { useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import BackBtn from '../components/BackBtn';
import styles from './login.style';
import Button from '../components/Button';
import * as Yup from 'yup';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS, SIZES } from '../assets/constants';
import { Formik } from 'formik';
import axios from 'axios';

const validationSchema = Yup.object().shape({
  firstName: Yup.string().min(3, 'Too short!').required('Required'),
  lastName: Yup.string().min(3, 'Too short!').required('Required'),
  userName: Yup.string()
  .required('Username is required')
  .min(3, 'Username must be at least 3 characters')
  .max(20, 'Username must be at most 20 characters')
  .matches(
    /^(?![_. ])(?!. *[_. ]{2})[a-zA-Z0-9._ ]+(?<![_. ])$/,
    'Username must be 3–20 characters, no special characters at start/end, and no double dots/underscores'
  ),
  password: Yup.string()
  .required('Password is required')
  .min(8, 'Password must be at least 8 characters long')
  .matches(/[A-Z]/, 'Password must contain at least one uppercase letter')
  .matches(/[a-z]/, 'Password must contain at least one lowercase letter')
  .matches(/\d/, 'Password must contain at least one number')
  .matches(/[@$!%#*?&]/, 'Password must contain at least one special character'),
  email: Yup.string().email('Invalid email').required('Required'),
  phone: Yup.string()
    .matches(/^\d{11}$/, 'Phone must be 11 digits')
    .required('Required'),
  address: Yup.string().min(5, 'Too short!').required('Required'),
});

const SignUp = ({ navigation }) => {
  const [obsecureText, setObsecureText] = useState(true);

  const handleSignup = async (values) => {
    try {
      const response = await axios.post('http://172.16.150.254:3000/user/create', values);
      if (response.status === 201) {
        Alert.alert('Success', 'Account created successfully!');
        navigation.navigate('Login');
      }
    } catch (error) {
        console.log("Signup Error:", error.response ? error.response.data : error.message);
        Alert.alert('Error', error.response?.data?.message || 'Something went wrong. Please try again.');
      }
  };

  return (
    <ScrollView>
      <SafeAreaView style={{ marginHorizontal: 20 }}>
        <View>
          <BackBtn onPress={() => navigation.goBack()} />
          <Image
            source={require('../assets/images/bk.png')}
            style={{
              height: SIZES.height / 5,
              width: SIZES.width - 60,
              resizeMode: 'contain',
            }}
          />
          <Text style={styles.title}>Unlimited Luxurious Items</Text>

          <Formik
            initialValues={{
              firstName: '',
              lastName: '',
              userName: '',
              email: '',
              password: '',
              phone: '',
              address: '',
            }}
            validationSchema={validationSchema}
            onSubmit={handleSignup}
          >
            {({ handleChange, handleBlur, handleSubmit, touched, values, errors, setFieldTouched }) => (
              <View>
                {[{ name: 'firstName', placeholder: 'First Name', icon: 'person-outline' },
                  { name: 'lastName', placeholder: 'Last Name', icon: 'person-outline' },
                  { name: 'userName', placeholder: 'Username', icon: 'person-circle-outline' },
                  { name: 'email', placeholder: 'Email', icon: 'mail-outline' },
                  { name: 'phone', placeholder: 'Phone (11 digits)', icon: 'call-outline' } ,
                  { name: 'address', placeholder: 'Address', icon: 'home-outline' }].map(({ name, placeholder, icon }) => (
                  <View key={name} style={styles.wrapper}>
                    <View style={styles.inputWrapper(touched[name] ? COLORS.secondary : COLORS.offwhite)}>
                      <Ionicons name={icon} size={20} color={COLORS.gray} style={styles.iconStyle} />
                      <TextInput
                        placeholder={placeholder}
                        onFocus={() => setFieldTouched(name, true)}
                        onBlur={() => setFieldTouched(name, false)}
                        value={values[name]}
                        // onChangeText={handleChange(name)}

                        onChangeText={(text) => {
                        let cleanText = text;

                       if (name === "firstName" || name === "lastName") {
                        cleanText = text.replace(/[^A-Za-z ]/g, ""); // ✅ allow only letters + space
                        } else if (name === "phone") {
                        cleanText = text.replace(/[^0-9]/g, ""); // ✅ only numbers
                        }
                        handleChange(name)(cleanText);
                            }}


                        autoCapitalize="none"
                        autoCorrect={false}
                        style={{ flex: 1 }}
                      />
                    </View>
                    {touched[name] && errors[name] && <Text style={styles.errorMessage}>{errors[name]}</Text>}
                  </View>
                ))}

                {/* PASSWORD INPUT */}
                <View style={styles.wrapper}>
                  <View style={styles.inputWrapper(touched.password ? COLORS.secondary : COLORS.offwhite)}>
                    <MaterialCommunityIcons name="lock-outline" size={20} color={COLORS.gray} style={styles.iconStyle} />
                    <TextInput
                      secureTextEntry={obsecureText}
                      placeholder="Password"
                      onFocus={() => setFieldTouched('password', true)}
                      onBlur={() => setFieldTouched('password', false)}
                      value={values.password}
                      onChangeText={handleChange('password')}
                      autoCapitalize="none"
                      autoCorrect={false}
                      style={{ flex: 1 }}
                    />
                    <TouchableOpacity onPress={() => setObsecureText(!obsecureText)}>
                      <MaterialCommunityIcons name={obsecureText ? 'eye-outline' : 'eye-off-outline'} size={18} />
                    </TouchableOpacity>
                  </View>
                  {touched.password && errors.password && <Text style={styles.errorMessage}>{errors.password}</Text>}
                </View>

                <Button title="SIGN UP" onPress={handleSubmit} />
                <View style={{ flexDirection: 'column', justifyContent: 'center', marginTop: 10}}>
                  <Text style={styles.NoAccount}>Already have an account?</Text>
                  <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                    <Text style={styles.registration}> Sign in</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          </Formik>
        </View>
      </SafeAreaView>
    </ScrollView>
  );
};

export default SignUp;
