// import React from 'react';
// import { View, Text, FlatList, StyleSheet, ScrollView} from 'react-native';



// const getImageUriFromByteArray = (byteArray) => {
//   if (!byteArray || !Array.isArray(byteArray)) return null;
//   const base64String = btoa(byteArray.map((byte) => String.fromCharCode(byte)).join(''));
//   return `data:image/jpeg;base64,${base64String}`;
// };


// const ViewOrder = ({ route }) => {
//   const { order } = route.params;

//   const products = order.products || [];

//   const totalItems = products.reduce((sum, p) => sum + (p.quantity || 1), 0);
//   const totalPrice = products.reduce((sum, p) => sum + (p.price * (p.quantity || 1)), 0);
//   const shippingCharge = 200;
//   const grandTotal = totalPrice + shippingCharge;

//   const renderProduct = ({ item }) => (
//     <View style={styles.productRow}>
//       <Text>{item.title}</Text>
//       <Text>{item.quantity || 1} x Rs {item.price}</Text>
//     </View>
//   );

//   return (
//     <ScrollView contentContainerStyle={styles.container}>
//       <Text style={styles.sectionTitle}>Order Summary</Text>
      
//       <FlatList
//              data={products}
//              keyExtractor={(item, index) => item.id?.toString() || index.toString()}
//              renderItem={renderProduct}
//              scrollEnabled={false}
//            />

//       <View style={styles.bottomSummary}>
//         <View style={styles.summaryRow}>
//           <Text>Total Items:</Text>
//           <Text>{totalItems}</Text>
//         </View>
//         <View style={styles.summaryRow}>
//           <Text>Total Items Price:</Text>
//           <Text>Rs {totalPrice.toLocaleString()}</Text>
//         </View>
//         <View style={styles.summaryRow}>
//           <Text>Shipping Charges:</Text>
//           <Text>Rs {shippingCharge.toLocaleString()}</Text>
//         </View>
//         <View style={[styles.summaryRow, { fontWeight: 'bold' }]}>
//           <Text>Total:</Text>
//           <Text>Rs {grandTotal.toLocaleString()}</Text>
//         </View>
//       </View>
//     </ScrollView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     padding: 16,
//   },
//   sectionTitle: {
//     fontSize: 18,
//     fontWeight: 'bold',
//     marginVertical: 10,
//   },
//   productRow: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     paddingVertical: 6,
//   },
//   bottomSummary: {
//     marginTop: 20,
//     padding: 16,
//     backgroundColor: '#f8f8f8',
//     borderRadius: 10,
//   },
//   summaryRow: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     marginBottom: 10,
//   },
// });

// export default ViewOrder;













import React from 'react';
import { View, Text, FlatList, StyleSheet, Image, ScrollView } from 'react-native';
import { COLORS, SIZES } from '../assets/constants';

const getImageUriFromByteArray = (byteArray) => {
  if (!byteArray || !Array.isArray(byteArray)) return null;
  const base64String = btoa(byteArray.map((byte) => String.fromCharCode(byte)).join(''));
  return `data:image/jpeg;base64,${base64String}`;
};

const ViewOrder = ({ route }) => {
  const { order } = route.params;

  if (!order) {
    return (
      <View style={styles.center}>
        <Text>No order details available</Text>
      </View>
    );
  }

  const { firstName, lastName, email, mobileNo, address, city, paymentType, products } = order;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>Order Details</Text>

      {/* Customer Info */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Customer Information</Text>
        <Text>Name: {firstName} {lastName}</Text>
        <Text>Email: {email}</Text>
        <Text>Phone: {mobileNo}</Text>
        <Text>City: {city}</Text>
        <Text>Address: {address}</Text>
      </View>

      {/* Payment Info */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Payment Method</Text>
        <Text>{paymentType}</Text>
      </View>

      {/* Products */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Order Summary</Text>
        <FlatList
          data={products}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) => {
            const imageUrl = item.product?.image?.data ? getImageUriFromByteArray(item.product.image.data) : null;
            return (
              <View style={styles.productCard}>
                {imageUrl && (
                  <Image source={{ uri: imageUrl }} style={styles.productImage} resizeMode="cover" />
                )}
                <View style={styles.productInfo}>
                  <Text style={styles.productTitle}>{item.product.title}</Text>
                  <Text style={styles.productDetails}>Qty: {item.quantity}</Text>
                </View>
                <Text style={styles.productPrice}>Rs {(item.product.price * item.quantity).toLocaleString()}</Text>
              </View>
            );
          }}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: SIZES.medium,
    backgroundColor: COLORS.white,
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 15,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  productCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f2f2f2',
    padding: 10,
    borderRadius: 10,
    marginBottom: 10,
  },
  productImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 10,
  },
  productInfo: {
    flex: 1,
  },
  productTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  productDetails: {
    fontSize: 14,
    color: '#555',
  },
  productPrice: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.primary,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  }
});

export default ViewOrder;
