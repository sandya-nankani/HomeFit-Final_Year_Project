import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StyleSheet, Text, View } from 'react-native';
import { useFonts } from 'expo-font';
import { useCallback } from 'react';
import * as SplashScreen from "expo-splash-screen";
import BottomTabNavigation from './navigation/BottomTabNavigation';
import {  SwipeUpScreen, ForgotPassword, Home, LoginPage, PasswordUpdated, ResetPassword, SendOtp, SignUp, ProductDetails, Cart, AdminDashboard, Profile, ManageProducts, AdminProfile, Search, ARView, AdvancedARView, ARExperience } from './screens';
import { UserProvider } from './context/UserContext';
import { ManageCategories } from './screens';
import EditCategory from 'screens/EditCategory';
import EditProducts from 'screens/EditProducts';
import EmptyCart from 'screens/EmptyCart';
import CheckoutScreen from 'screens/Checkout';
import ManageUsers from 'screens/ManageUsers'; 
import ManageOrders from 'screens/ManageOrders';
import {ViewOrder} from './screens';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import PaymentDetails from './screens/PaymentDetails';
import { StripeProvider } from "@stripe/stripe-react-native";


const Stack = createNativeStackNavigator();

export default function App() {
  const [fontsLoaded] = useFonts({
    Kaushan: require("./assets/fonts/KaushanScript-Regular.ttf"),
    regular: require("./assets/fonts/Poppins-Regular.ttf"),
    light: require("./assets/fonts/Poppins-Light.ttf"),
    bold: require("./assets/fonts/Poppins-Bold.ttf"),
    medium: require("./assets/fonts/Poppins-Medium.ttf"),
    extraBold: require("./assets/fonts/Poppins-ExtraBold.ttf"),
    semiBold: require("./assets/fonts/Poppins-SemiBold.ttf"),
  }) 

 

  const onLayoutRootView = useCallback(async() => {
    if(fontsLoaded){
      await SplashScreen.hideAsync();
    }
  }, [fontsLoaded] );

  if(!fontsLoaded){
    return null;
  }

  

  
  return (
     <StripeProvider publishableKey="pk_test_51S1YLXRoA3J7ezlxBXThBLEiVmf5phjaXLfwZJddS4BWAwSywEKKav6ZYzSeQ7A2HObRzfkclPYiCmFZjsF2IT8W00KqXmW2no">
     <GestureHandlerRootView style={{ flex: 1 }}>
    <UserProvider>
       <View style={{ flex: 1 }} onLayout={onLayoutRootView}>
    <NavigationContainer>

      <Stack.Navigator initialRouteName='SwipeUpScreen' screenOptions={{headerShown: false}}>
      
      <Stack.Screen 
        name='SwipeUpScreen' 
        component={SwipeUpScreen} 
        options={{headerShown: false}}
      />

      <Stack.Screen 
        name='BottomTabNavigation' 
        component={BottomTabNavigation} 
        options={{headerShown: false}}
      />
             
      <Stack.Screen 
        name='Home' 
        component={Home} 
        options={{headerShown: false}}
      />

      <Stack.Screen
        name='Login'
        component={LoginPage}
        options={{ headerShown: false}}
      />

      <Stack.Screen
        name='SignUp'
        component={SignUp}
        options={{ headerShown: false}}
      />

      <Stack.Screen
        name='ForgotPassword'
        component={ForgotPassword}
        options={{ headerShown: false}}
      />

      <Stack.Screen
        name='SendOtp'
        component={SendOtp}
        options={{ headerShown: false}}
      />

      <Stack.Screen
        name='ResetPassword'
        component={ResetPassword}
        options={{ headerShown: false}}
      />

      <Stack.Screen
        name='PasswordUpdated'
        component={PasswordUpdated}
        options={{ headerShown: false}}
      />

       <Stack.Screen
        name='Profile'
        component={Profile}
        options={{ headerShown: false}}
      />

      <Stack.Screen
        name='ProductDetails'
        component={ProductDetails}
        options={{ headerShown: false}}
      />

      <Stack.Screen
        name='Search'
        component={Search}
        options={{ headerShown: false}}
      />

     <Stack.Screen
        name='EmptyCart'
        component={EmptyCart}
        options={{ headerShown: false}}
      />

      <Stack.Screen
        name='Cart'
        component={Cart}
        options={{ headerShown: false}}
      />

        <Stack.Screen
        name='AdminDashboard'
        component={AdminDashboard}
        options={{ headerShown: false}}
      /> 

      <Stack.Screen
        name='AdminProfile'
        component={AdminProfile}
        options={{ headerShown: false}}
      />  

        <Stack.Screen
        name='ManageProducts'
        component={ManageProducts}
        options={{ headerShown: false}}
      /> 

      <Stack.Screen
        name='ManageCategories'
        component={ManageCategories}
        options={{ headerShown: false}}
      /> 

      <Stack.Screen
        name='ManageUsers'
        component={ManageUsers}
        options={{ headerShown: false}}
      /> 

       <Stack.Screen
        name='ManageOrders'
        component={ManageOrders}
        options={{ headerShown: false}}
      /> 


      <Stack.Screen
        name='ViewOrder'
        component={ViewOrder}
        options={{ headerShown: false}}
      /> 



      <Stack.Screen
        name='EditCategory'
        component={EditCategory}
        options={{ headerShown: false}}
      /> 

      <Stack.Screen
        name='EditProducts'
        component={EditProducts}
        options={{ headerShown: false}}
      /> 

      <Stack.Screen
        name='CheckoutScreen'
        component={CheckoutScreen}
        options={{ headerShown: false}}
      /> 

      <Stack.Screen
        name='ARView'
        component={ARView}
        options={{ headerShown: false}}
      /> 

      <Stack.Screen
        name='AdvancedARView'
        component={AdvancedARView}
        options={{ headerShown: false}}
      /> 

      <Stack.Screen
        name='ARExperience'
        component={ARExperience}
        options={{ headerShown: false}}
      /> 

      <Stack.Screen
        name='PaymentDetails'
        component={PaymentDetails}
        options={{ headerShown: false}}
      /> 

     



      </Stack.Navigator>
    </NavigationContainer>
    
    </View>
    </UserProvider>
    </GestureHandlerRootView>
    </StripeProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  textStyle: {
    fontFamily: "extraBold",
    fontSize: 20,
  }
});
