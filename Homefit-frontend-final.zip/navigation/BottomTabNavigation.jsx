import { View, Text } from 'react-native'
import React, {useCallback, useEffect, useState} from 'react'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import { AdminDashboard, AdminManageProducts, AdminProfile, Cart, Home, Profile, Search } from '../screens';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS } from "../assets/constants/index"
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';


const Tab = createBottomTabNavigator();


const BottomTabNavigation = () => {
    const [accountType, setAccountType] = useState(null);
    const [loading, setLoading] = useState(true)



useFocusEffect(
  useCallback(() => {
    const loadUserAccountType = async () => {
    //   try {
        const userData = await AsyncStorage.getItem('user');
        if (userData) {
          const user = JSON.parse(userData);
          console.log('Loaded user from AsyncStorage:', user);
          setAccountType(user.accountType); // 'admin' or 'user'
        }
        setLoading(false);
   
    };

    loadUserAccountType();
  }, [])
);

  if (loading) {
    return null; // You can return a spinner if needed
  }

const screensOptions = {
    tabBarShareLabel: false,
    tabBarHideOnKeyboard: true,
    headerShown: false,
    tabBarStyle: {
        position: "absolute",
        bottom: 0,
        right: 0,
        left: 0,
        elevation: 0,
        height: 90,
        // marginBottom: 20,
        paddingBottom: 20,
        
    }
}


  return (
    <Tab.Navigator screenOptions={screensOptions}>
       
       <Tab.Screen name="Home" component={Home}
       options={{
        tabBarIcon: ({focused}) => {
            return <Ionicons name={focused ? "home" : "home-outline"} 
            size={24} color={focused ? COLORS.primary: COLORS.gray2} />
        }
       }}/>

       <Tab.Screen name="Cart" component={Cart}
        options={{
            tabBarIcon: ({focused}) => {
                return <MaterialCommunityIcons
                  name="cart-outline"
                size={24} color={focused ? COLORS.primary: COLORS.gray2} />
            }
           }}/> 
           
       {/* <Tab.Screen name="AdminProfile" component={AdminProfile}
        options={{
            tabBarIcon: ({focused}) => {
                return <Ionicons name={focused ? "person" : "person-outline"} 
                size={24} color={focused ? COLORS.primary: COLORS.gray2} />
            }
           }}/>   */}



      {accountType === 'admin' ? (
        <Tab.Screen 
        name="Profile" 
        component={AdminProfile} 
        options={{
            tabBarIcon: ({focused}) => {
                return <Ionicons name={focused ? "person" : "person-outline"} 
                size={24} color={focused ? COLORS.primary: COLORS.gray2} />
            }
         }} />
      ) : (
        <Tab.Screen name="Profile" component={Profile} 
        options={{
            tabBarIcon: ({focused}) => {
                return <Ionicons name={focused ? "person" : "person-outline"} 
                size={24} color={focused ? COLORS.primary: COLORS.gray2} />
            }
        }}/>
      )}


    </Tab.Navigator>
  )
}

export default BottomTabNavigation