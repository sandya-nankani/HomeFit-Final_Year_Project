import {Controller,Post,Body, HttpCode, Req, Res,} from '@nestjs/common';
import { PaymentGatewayService } from './payment-gateway.service';
import { CreatePaymentGatewayDto } from './dto/create-payment-gateway.dto';

@Controller('payment-gateway')
export class PaymentGatewayController {
  constructor(private readonly paymentGatewayService: PaymentGatewayService) {}

  @Post('create-intent')
async createPaymentIntent(@Body() body: { amount: number; userId: number }) {
  console.log('Received body:', body);
  return this.paymentGatewayService.createPaymentIntent(body.amount, body.userId);
}


  // ✅ STEP 2: Stripe webhook (called by Stripe, not frontend!)
  @Post('webhook')
  @HttpCode(200)
  async handleWebhook(@Req() req, @Res() res) {
    try {
      const sig = req.headers['stripe-signature'];
      const event = this.paymentGatewayService.constructWebhook(req.rawBody, sig);

      await this.paymentGatewayService.handleWebhook(event);

      return res.send({ received: true });
    } catch (err) {
      console.error('❌ Webhook error:', err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }
  }
}