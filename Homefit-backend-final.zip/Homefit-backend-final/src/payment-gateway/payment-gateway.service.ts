// import { Injectable } from '@nestjs/common';
// import { CreatePaymentGatewayDto } from './dto/create-payment-gateway.dto';
// import { InjectRepository } from '@nestjs/typeorm';
// import Stripe from 'stripe';
// import { Repository } from 'typeorm';
// import { PaymentGateway } from './entities/payment-gateway.entity';
// import { OrderDetails } from 'src/order/entities/orderDetails.entity';
// import { User } from 'src/users/entities/user.entity';
// import { ConfigService } from '@nestjs/config';

// @Injectable()
// export class PaymentGatewayService {
//  private stripe: Stripe;

//   constructor(
//     @InjectRepository(PaymentGateway)
//     private paymentRepository: Repository<PaymentGateway>,

//     @InjectRepository(OrderDetails)
//     private orderRepository: Repository<OrderDetails>,
    
//     @InjectRepository(User)
//     private userRepository: Repository<User>,
//      private configService: ConfigService,   // ✅ inject ConfigService
  
//   ) {
//     const secretKey = this.configService.get<string>('STRIPE_SECRET_KEY');
//      console.log('🔑 Stripe secret:', secretKey);
//     this.stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
      
//       apiVersion: '2025-08-27.basil',
      
//     });
//   }

  
//   async createPayment(dto: CreatePaymentGatewayDto) {
//   const order = await this.orderRepository.findOneBy({ id: dto.orderId });
//   if (!order) throw new Error('Order not found');

//   const user = await this.userRepository.findOneBy({ id: dto.userId });
//   if (!user) throw new Error('User not found');

//   if (dto.paymentMethod === 'Stripe') {
//     const intent = await this.stripe.paymentIntents.create({
//       amount: Math.round(dto.amount * 100), // convert to cents
//       currency: 'usd',
//       metadata: { 
//         orderId: dto.orderId.toString(),
//         userId: dto.userId.toString(),
//       },
//     });

//     const payment = this.paymentRepository.create({
//       order,
//       user,                               // <-- assign user
//       paymentMethod: dto.paymentMethod,
//       transactionId: intent.id,
//       amount: dto.amount,
//       status: 'PENDING',
//     });
//     await this.paymentRepository.save(payment);

//     return { clientSecret: intent.client_secret };
//   }

//   // Cash on Delivery
//   const payment = this.paymentRepository.create({
//     order,
//     user,                                 // <-- assign user
//     paymentMethod: dto.paymentMethod,
//     transactionId: null,
//     amount: dto.amount,
//     status: 'PENDING',
//   });

//   return this.paymentRepository.save(payment);
// }


//   async handleWebhook(event: Stripe.Event) {
//     if (event.type === 'payment_intent.succeeded') {
//       const intent = event.data.object as Stripe.PaymentIntent;
//       const payment = await this.paymentRepository.findOneBy({ transactionId: intent.id });
//       if (payment) {
//         payment.status = 'SUCCESS';
//         await this.paymentRepository.save(payment);
//       }
//     }
//   }
// }









import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import Stripe from 'stripe';
import { Repository } from 'typeorm';
import { PaymentGateway } from './entities/payment-gateway.entity';
import { OrderDetails } from 'src/order/entities/orderDetails.entity';
import { User } from 'src/users/entities/user.entity';
import { ConfigService } from '@nestjs/config';
import { CreatePaymentGatewayDto } from './dto/create-payment-gateway.dto';

@Injectable()
export class PaymentGatewayService {
  private stripe: Stripe;

  constructor(
    @InjectRepository(PaymentGateway)
    private paymentRepository: Repository<PaymentGateway>,

    @InjectRepository(OrderDetails)
    private orderRepository: Repository<OrderDetails>,
    
    @InjectRepository(User)
    private userRepository: Repository<User>,

    private configService: ConfigService,
  ) {
    this.stripe = new Stripe(this.configService.get<string>('STRIPE_SECRET_KEY')?.trim(), {
      apiVersion: '2025-08-27.basil',
    });
  }

  async createPaymentIntent(amount: number, userId: number) {
  if (!amount || !userId) throw new Error('Missing amount or userId');

  try {
    const paymentIntent = await this.stripe.paymentIntents.create({
      amount: amount * 100, // convert PKR to paisa
      currency: 'pkr',
      metadata: { userId: userId.toString() },
    });

    const payment = this.paymentRepository.create({
  user: await this.userRepository.findOneBy({ id: userId }),
  // order: await this.orderRepository.findOneBy({id: orderId}),
  paymentMethod: 'Stripe',
  transactionId: paymentIntent.id,
  amount,
 
  status: 'SUCCESS', // mark as pending until webhook confirms success
});
await this.paymentRepository.save(payment);



    console.log('✅ PaymentIntent created:', paymentIntent.id);
    return { clientSecret: paymentIntent.client_secret };

  } catch (err) {
    console.error('❌ Stripe error:', err.message);
    return { error: 'Stripe payment creation failed' }; // return structured error
  }
  
}




  constructWebhook(rawBody: Buffer, signature: string) {
    return this.stripe.webhooks.constructEvent(
      rawBody,
      signature,
      this.configService.get<string>('STRIPE_WEBHOOK_SECRET'), // ✅ in .env
    );
  }

  // STEP 2: Handle Stripe webhook after success
  async handleWebhook(event: Stripe.Event) {
    if (event.type === 'payment_intent.succeeded') {
      const intent = event.data.object as Stripe.PaymentIntent;

      const payment = await this.paymentRepository.findOne({
        where: { transactionId: intent.id },
        relations: ['user'],
      });

      if (payment) {
        // ✅ create order now
        const order = this.orderRepository.create({
          user: payment.user,
          firstName: 'From frontend',  // ✅ You’ll pass these later
          lastName: '',
          email: '',
          mobileNo: '',
          address: '',
          city: '',
          paymentType: 'Stripe',
          products: [], // attach cart products later
        });

        await this.orderRepository.save(order);

        // link order to payment
        payment.status = 'SUCCESS';
        payment.order = order;
        await this.paymentRepository.save(payment);
      }
    }
  }
}
