import { OrderDetails } from 'src/order/entities/orderDetails.entity';
import { User } from 'src/users/entities/user.entity';
import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, OneToOne, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class PaymentGateway {
  @PrimaryGeneratedColumn()
  id: number;



  @Column()
  paymentMethod: string;

  @Column({ nullable: true })
  transactionId: string;

  @Column({ default: 'PENDING' })
  status: string;

  @Column('decimal', { precision: 10, scale: 2 })
  amount: number;

  @CreateDateColumn()
  createdAt: Date;

   @OneToOne(() => OrderDetails, (order) => order.payment)
@JoinColumn({ name: 'orderId' }) // PaymentGateway owns the relation
order: OrderDetails;

@ManyToOne(() => User, (user) => user.payments, { eager: true })
@JoinColumn({ name: 'userId' })
user: User;
}
