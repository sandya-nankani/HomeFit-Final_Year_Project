import { IsNumber, IsString } from "class-validator";

export class CreatePaymentGatewayDto {
  @IsNumber()
  amount: number;

  @IsNumber()
  orderId: number;

  @IsNumber()
  userId: number;

  @IsString()
  paymentMethod: string;
}
