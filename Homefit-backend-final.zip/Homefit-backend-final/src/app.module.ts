import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsersModule } from './users/users.module';
import { User } from './users/entities/user.entity';
import { AuthModule } from './auth/auth.module';
import * as cors from 'cors'; 
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule} from '@nestjs/config';
import { UsersController } from './users/users.controller';
import { AuthController } from './auth/auth.controller';
import { UsersService } from './users/users.service';
import { AuthService } from './auth/auth.service';
import { jwtConstants } from './auth/contants';
import { PassportModule } from '@nestjs/passport';
import { AppController } from './app.controller';
import { HttpModule } from '@nestjs/axios';
import mailConfig from './config/mail.config';
import { Products } from './products/entities/product.entity';
import { Cart } from './cart/entities/cart.entity';
import { Category } from './category/entities/category.entity';
import { OrderDetails } from './order/entities/orderDetails.entity';
import { ProductsModule } from './products/products.module';
import { CategoryModule } from './category/category.module';
import { CartModule } from './cart/cart.module';
import { OrderModule } from './order/order.module';
import { ProductsController } from './products/products.controller';
import { OrderController } from './order/order.controller';
import { CategoryController } from './category/category.controller';
import { CartController } from './cart/cart.controller';
import { ProductsService } from './products/products.service';
import { OrderService } from './order/order.service';
import { EmailService } from './auth/email.service';
import { CategoryService } from './category/category.service';
import { CartService } from './cart/cart.service';
import { Review } from './reviews/entities/review.entity';
import { ReviewsModule } from './reviews/reviews.module';
import { ReviewsController } from './reviews/reviews.controller';
import { ReviewsService } from './reviews/reviews.service';
import { PaymentGateway } from './payment-gateway/entities/payment-gateway.entity';
import { PaymentGatewayModule } from './payment-gateway/payment-gateway.module';
import { PaymentGatewayController } from './payment-gateway/payment-gateway.controller';
import { PaymentGatewayService } from './payment-gateway/payment-gateway.service';


@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost',
      port: 3306,
      username: 'root',
      password: '',
      database: 'homefit',  
      synchronize: false,

      entities: [User,Products,Cart,Category,OrderDetails,Review, PaymentGateway],
    })
    
    ,HttpModule,
    TypeOrmModule.forFeature([User,Products,Cart,Category,OrderDetails,Review, PaymentGateway]),
    ConfigModule.forRoot({
      isGlobal: true,
      load: [mailConfig],
}),

    JwtModule.register({
      global: true,
      secret: jwtConstants.secret,
      signOptions: { expiresIn: '1d' },
    }),
    UsersModule,
    AuthModule,
    PassportModule,
    ProductsModule,
    CategoryModule,
    CartModule,
    OrderModule,
    ReviewsModule,
    PaymentGatewayModule

  ],
  controllers: [
    AppController,
    UsersController,
    AuthController,
    ProductsController,
    OrderController,
    CategoryController,
    CartController,
    ReviewsController,
    PaymentGatewayController
  ],
  providers: [
    AppService,
    UsersService,
    AuthService,
    ProductsService,
    OrderService,
    EmailService,
    CategoryService,
    CartService,
    ReviewsService,
    PaymentGatewayService
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(cors()).forRoutes('*');
  }
}