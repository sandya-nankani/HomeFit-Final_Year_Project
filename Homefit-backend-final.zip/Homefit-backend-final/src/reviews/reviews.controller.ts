import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ReviewsService } from './reviews.service';
import { CreateReviewDto } from './dto/create-review.dto';
import { UpdateReviewDto } from './dto/update-review.dto';

@Controller('reviews')
export class ReviewsController {
  constructor(private readonly reviewsService: ReviewsService) {}

  @Post("/create")
  create(@Body() dto: CreateReviewDto) {
    console.log("Hit on reviews create");
    return this.reviewsService.create(dto);
  }

  @Get('product/:productId')
  getByProduct(@Param('productId') productId: number) {
    return this.reviewsService.findByProduct(productId);
  }

  @Get('user/:userId')
  getByUser(@Param('userId') userId: number) {
    return this.reviewsService.findByUser(userId);
  }
}
