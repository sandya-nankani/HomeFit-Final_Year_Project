import { IsInt, IsNotEmpty, IsString } from 'class-validator';

export class CreateReviewDto {
  @IsInt()
  userId: number;

  @IsInt()
  productId: number;

  // @IsInt()
  // rating: number;

  @IsString()
  @IsNotEmpty()
  comment: string;
}
