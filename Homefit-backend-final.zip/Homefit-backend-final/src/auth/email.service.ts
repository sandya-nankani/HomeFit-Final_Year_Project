import { Injectable } from '@nestjs/common';
import * as nodemailer from 'nodemailer';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class EmailService {
  private transporter: nodemailer.Transporter;

  constructor(private configService: ConfigService) {
    this.transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'rkmeghani36@gmail.com',
        pass: 'elfp mjqc mvof rtmy',
      },
    });
  }

  async sendOTP(email: string, otp: string): Promise<void> {
    const mailOptions = {
      from: this.configService.get<string>('EMAIL_USER'), // Fix here
      to: email,
      subject: 'Your OTP Code',
      text: `Your OTP code is: ${otp}. It expires in 10 minutes.`,
    };

    try {
    await this.transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('⚠️ Failed to send OTP email:', error.message);
    // don’t throw — so your app flow continues
  }
}

  async sendOrderConfirmation(email: string, orderDetails: any): Promise<void> {
    const mailOptions = {
      from: this.configService.get<string>('EMAIL_USER'), // Fix here
      to: email,
      subject: 'Order Confirmation',
      html: `<h3>Your order has been confirmed. Thank you for placing your order in homeFit!</h3>
             <p>Your order details:</p>
              <p>Order ID: ${orderDetails.id}<p>
             <ul>
               ${orderDetails.items
                 .map(
                   (item) =>
                     `<li>${item.name} x  ${item.quantity} = $${item.price}</li>`,
                 )
                 .join('')}
             </ul>
             <p>Total: <strong>$${orderDetails.total}</strong></p>`,
    };

try {
    await this.transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('⚠️ Failed to send order confirmation email:', error.message);
    // don’t throw — so order + payment still succeed
  }
}
}
