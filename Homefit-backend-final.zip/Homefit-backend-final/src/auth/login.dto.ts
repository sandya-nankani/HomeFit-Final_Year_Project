export class MicrosoftProfileDto {
    email:string
    password:string
  }
  