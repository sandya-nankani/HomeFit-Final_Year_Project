import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { log } from 'console';
import { User } from 'src/users/entities/user.entity';
import { Repository } from 'typeorm/repository/Repository';


@Injectable()
export class AuthService {
    constructor(
        @InjectRepository(User) private userRepository: Repository<User>,private jwtService:JwtService
    ){}

    private readonly refreshSecret="df59cf13a1547ca9430f9b59c76af795baca29b34da18fc699320a04451d4509"

    async generateUserToken(id: number){
        const accessToken=this.jwtService.sign({id},{expiresIn:'1h'})
        return{accessToken}
    }

    generateRefreshToken(payload: any): string {
        return this.jwtService.sign(payload, {
          secret: this.refreshSecret,
          expiresIn: '7d', // Refresh token expires in 7 days
        });
      }
    
      verifyRefreshToken(token: string): any {
        try {
          return this.jwtService.verify(token, { secret: this.refreshSecret });
        } catch (e) {
          throw new UnauthorizedException('Invalid or expired refresh token');
        }
      }
}
