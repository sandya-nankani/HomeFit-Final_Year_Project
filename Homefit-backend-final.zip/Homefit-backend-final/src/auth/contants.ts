export const jwtConstants = {
  secret: 'dd698e4825fb7be4e6329597ba5b9a2bde70d119cac944e207d69d4c09f473ea',
};  