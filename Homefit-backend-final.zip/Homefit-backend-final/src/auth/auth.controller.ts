import { Body, Controller, Get, Post, UnauthorizedException, UseGuards } from '@nestjs/common';
import { AuthService } from './auth.service';
import { UsersService } from 'src/users/users.service';
import * as bcrypt from 'bcryptjs';
import { MicrosoftProfileDto } from './login.dto';
import { EmailService } from './email.service';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService,private userService:UsersService,private emailService:EmailService) {}

  @Post("/login")
async login(@Body() loginDto: MicrosoftProfileDto) {
  console.log("login: ", loginDto);

  try {
    // Check if user exists
    const user = await this.userService.findbyEmail(loginDto.email);
    if (!user) {
      return { code: 400, message: "wrong credentials", object: null };
    }

    // Verify password
    const isPasswordMatch =await bcrypt.compare(loginDto.password, user.password);
    console.log("pass",isPasswordMatch)
    if (!isPasswordMatch) {
      return { code: 400, message: "wrong credentials", object: null };
    }

    // Generate token
    const token = await this.authService.generateUserToken(user.id);

    // Return success response
    return { code: 200, message: "user found", object: token.accessToken, user:user };

  } catch (error) {
    console.error("Error during login: ", error);
    return { code: 500, message: "Internal server error", object: null };
  }
}

@Post('sendOtp')
  async sendOtp(@Body('email') email: string) {
    console.log("otp sent");
    
    const otp = Math.floor(1000 + Math.random() * 9000).toString();
    await this.emailService.sendOTP(email, otp);
    return {status:200, message: 'OTP sent successfully',object:otp };
  }
}
