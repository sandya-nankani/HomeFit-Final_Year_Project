import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Cart } from './entities/cart.entity';
import { Repository } from 'typeorm';
import { CreateCartDto } from './dto/create-cart.dto';
import { UpdateCartDto } from './dto/update-cart.dto';
import { User } from 'src/users/entities/user.entity';
import { Products } from 'src/products/entities/product.entity';

@Injectable()
export class CartService {
  constructor(
    @InjectRepository(Cart)
    private readonly cartRepository: Repository<Cart>,

    @InjectRepository(User)
    private readonly userRepository: Repository<User>,

    @InjectRepository(Products)
    private readonly productRepository: Repository<Products>,
  ) {}

  async create(createCartDto: CreateCartDto): Promise<Cart> {
    const user = await this.userRepository.findOne({ where: { id: createCartDto.user } });
    const product = await this.productRepository.findOne({ where: { id: createCartDto.product } });

    if (!user || !product) {
      throw new NotFoundException('User or Product not found');
    }


let cart = await this.cartRepository.findOne({
    where: {
      user: { id: user.id },
      product: { id: product.id },
    },
  });

  if (cart) {
    // Update existing cart item quantity and prices
    cart.quantity += createCartDto.quantity;

    // Recalculate prices based on updated quantity and product price
    cart.totalPrice = product.price * cart.quantity;
    cart.totalOrderPrice = cart.totalPrice;  // Adjust if you have discounts or other rules


return this.cartRepository.save(cart);
  } else {


     const newCart = this.cartRepository.create({
      quantity: createCartDto.quantity,
      totalPrice: product.price * createCartDto.quantity,
      totalOrderPrice: product.price * createCartDto.quantity,
      user,
      product,
    });

    return this.cartRepository.save(newCart);
  }
}

async getCartItemsByUserId(userId: number): Promise<Cart[]> {
  return this.cartRepository.find({
    where: { user: { id: userId } },
    relations: ['user', 'product'], // include product and user data
  });
}



  async findAll(): Promise<Cart[]> {
    return this.cartRepository.find({ relations: ['user', 'product'] });
  }

  async findOne(id: number): Promise<Cart> {
    return this.cartRepository.findOne({
      where: { id },
      relations: ['user', 'product'],
    });
  }

  

  async changeQuantity(cartItemId: number, change: number) {
  const cartItem = await this.cartRepository.findOne({ where: { id: cartItemId } });
  if (!cartItem) throw new NotFoundException('Cart item not found');

  const newQuantity = cartItem.quantity + change;
  if (newQuantity < 1) 
    throw new BadRequestException('Quantity cannot be less than 1');

  cartItem.quantity = newQuantity;
  return this.cartRepository.save(cartItem);
}


  async remove(id: number): Promise<void> {
    await this.cartRepository.delete(id);
  }


  async clearCartByUser(userId: number) {
  await this.cartRepository.delete({ user: { id: userId } });
  return { message: 'Cart cleared successfully' };
}


}
