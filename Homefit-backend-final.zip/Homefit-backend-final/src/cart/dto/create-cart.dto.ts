export class CreateCartDto {
      id: number;
      quantity:number;
      user: number;
      product: number;
      // totalPrice:number;
      // totalOrderPrice:number;
      
}
