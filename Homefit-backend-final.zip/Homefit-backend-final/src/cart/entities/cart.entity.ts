import { Products } from "src/products/entities/product.entity";
import { User } from "src/users/entities/user.entity";
import {Column, Entity, PrimaryGeneratedColumn, OneToMany, ManyToOne, JoinColumn, Double } from "typeorm";



@Entity()
export class Cart {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  quantity:number;
  
  @ManyToOne(() => User, (user) => user.orderDetails)
  @JoinColumn({ name: "userId" })
  user: User;

  @ManyToOne(() => Products, (product) => product.orderDetails)
  @JoinColumn({ name: "productId" })
  product: Products;

  @Column()
  totalPrice:number;
  
  @Column()
  totalOrderPrice:number;
  

}
