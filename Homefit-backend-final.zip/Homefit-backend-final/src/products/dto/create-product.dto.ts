// export class CreateProductDto {
//     title: string;
//     description: string;
//     price: number;
//     stock: number;
//     image: string;
//     model: string;
//     // discount: number;
//     // discountPrice: number;
//     categoryId: number; 
//   }
  

export class CreateProductDto {
  title: string;
  price: number;
  description: string;
  stock: number;
  categoryId: number;
  Date: string;
  fileName: string;
}
