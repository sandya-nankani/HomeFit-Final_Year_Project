import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseInterceptors,
  UploadedFile,
  Query,
  ParseIntPipe,
  BadRequestException,
  Res,
  UploadedFiles,
} from '@nestjs/common';
import { ProductsService } from './products.service';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { FileFieldsInterceptor, FileInterceptor } from '@nestjs/platform-express';
import { writeFile } from 'fs/promises';
import { extname, join } from 'path';


@Controller('products')
export class ProductsController {
  constructor(private readonly productsService: ProductsService) {}


  // @Post('/create')
  //   @UseInterceptors(FileInterceptor('file'))
  //   async create(
  //     @Body() createCategoryDto: CreateProductDto,
  //     @UploadedFile() file: Express.Multer.File,
  //   ) {
  //     console.log("Hit on add product");
      
  //     const imageBuffer = file?.buffer;
  //     return this.productsService.create(createCategoryDto, imageBuffer);
  //   }



//   @Post('/create')
// @UseInterceptors(FileInterceptor('file'))
// async create(
//   @Body() createProductDto: CreateProductDto,
//   @UploadedFile() file: Express.Multer.File,
// ) {
//   return this.productsService.create(createProductDto, file);
// }



@Post('create')
@UseInterceptors(
  FileFieldsInterceptor([
    { name: 'image', maxCount: 1 },
    { name: 'model', maxCount: 1 },
  ]),
)
async create(
  @Body() createProductDto: CreateProductDto,
  @UploadedFiles()
  files: {
    image?: Express.Multer.File[];
    model?: Express.Multer.File[];
  },
) {
  return this.productsService.create(createProductDto, files);
}


  @Get()
async findAll() {
  return await this.productsService.findAll();
}

@Get(':id')
async findOne(@Param('id') id: number) {
  return await this.productsService.findOne(id);
}



  @Get('category/:categoryId')
  async findByCategory(@Param('categoryId') CategoryId: number) {
    return await this.productsService.findByCategory(CategoryId);
  }



  @Get('/search') // Place before ':id' to avoid routing conflicts
  async searchProducts(
    @Query('search') search: string = '',
    @Query('page', ParseIntPipe) page = 1,
    @Query('limit', ParseIntPipe) limit = 10,
  ) {
    return this.productsService.searchProducts(search, page, limit);
  }

  // @Get(':id')
  // findOne(@Param('id', ParseIntPipe) id: number) {
  //   return this.productsService.findOne(id);
  // }






  @UseInterceptors(FileInterceptor('file'))
  @Patch('update/:id')
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateProductDto: UpdateProductDto,
    @UploadedFile() file?: Express.Multer.File,
  ) {
    
    const imageBuffer = file ? file.buffer : undefined;
    return this.productsService.update(id, updateProductDto, imageBuffer);
  }

  @Delete(':id')
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.productsService.remove(id);
  }
}
