import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { Products } from './entities/product.entity';
import { Like, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Category } from 'src/category/entities/category.entity';
import * as fs from 'fs';
import * as path from 'path';

@Injectable()
export class ProductsService {
  constructor(
    @InjectRepository(Products)
    private productRepository: Repository<Products>,
    @InjectRepository(Category)
    private categoryRepository: Repository<Category>,
  ) {}

  
// async create(
//   createProductDto: CreateProductDto,
//   file?: Express.Multer.File,
// ): Promise<any> {
//   const category = await this.categoryRepository.findOneBy({
//     id: createProductDto.categoryId,
//   });
//   if (!category) {
//     throw new NotFoundException('Category not found');
//   }

//   let fileName: string | null = null;
//   let image: Buffer | null = null;
//   let model: Buffer | null = null;

//   if (file) {
//     const isImage =
//       file.mimetype === 'image/png' ||
//       file.mimetype === 'image/jpeg' ||
//       file.mimetype === 'image/jpg';

//     if (isImage) {
//       // 🖼 Save file buffer into image column
//       image = file.buffer;
//     } else {
//       // 📦 Treat everything else as a 3D model
//       model = file.buffer;

//       // Save model file physically
//       const uploadDir = path.join(process.cwd(), 'uploads', 'models');
//       if (!fs.existsSync(uploadDir)) {
//         fs.mkdirSync(uploadDir, { recursive: true });
//       }

//       const savedFileName = `${Date.now()}-${file.originalname}`;
//       const fullPath = path.join(uploadDir, savedFileName);
//       fs.writeFileSync(fullPath, file.buffer);

//       console.log('📝 Saving 3D model to:', fullPath);

//       // ✅ Only store filename for 3D models
//       fileName = savedFileName;
//     }
//   }

//   const newProduct = this.productRepository.create({
//     ...createProductDto,
//     category,
//     image,
//     model,
//     fileName, // only filled if 3D model
//   });

//   return this.productRepository.save(newProduct);
// }



 async create(
    createProductDto: CreateProductDto,
    files: { image?: Express.Multer.File[]; model?: Express.Multer.File[] },
  ): Promise<Products> {
    const category = await this.categoryRepository.findOneBy({ id: createProductDto.categoryId });
    if (!category) throw new NotFoundException('Category not found');

    let image: Buffer | null = null;
    let modelPath: string | null = null;

    // Handle image
    if (files.image && files.image.length > 0) {
      image = files.image[0].buffer;
    }

    // Handle 3D model
    if (files.model && files.model.length > 0) {
      const modelFile = files.model[0];
      const uploadDir = path.join(process.cwd(), 'uploads', 'models');
      if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

      const savedFileName = `${Date.now()}-${modelFile.originalname}`;
      const fullPath = path.join(uploadDir, savedFileName);
      fs.writeFileSync(fullPath, modelFile.buffer);

      modelPath = savedFileName; // store only filename
      console.log('📝 3D model saved at:', fullPath);
    }

    const newProduct = this.productRepository.create({
      ...createProductDto,
      category,
      image,
      modelPath,
    });

    return this.productRepository.save(newProduct);
  }




// async create(
//     createProductDto: CreateProductDto,
//     file?: Express.Multer.File,
//   ): Promise<any> {
//     const category = await this.categoryRepository.findOneBy({
//       id: createProductDto.categoryId,
//     });
//     if (!category) {
//       throw new NotFoundException('Category not found');
//     }

//     let fileName: string | null = null;

// if (file) {
//   const isImage = file.mimetype.startsWith('image/');
//   const folder = isImage ? 'images' : 'models';

//   const uploadDir = path.join(process.cwd(), 'uploads', folder);

//   if (!fs.existsSync(uploadDir)) {
//     fs.mkdirSync(uploadDir, { recursive: true });
//   }

//   const savedFileName = `${Date.now()}-${file.originalname}`;
//   const fullPath = path.join(uploadDir, savedFileName);

//   fs.writeFileSync(fullPath, file.buffer);
//   console.log('📝 Saving file to:', fullPath);

//   // ✅ Store relative path in DB (folder + filename)
//   fileName = savedFileName;
// }

// const newProduct = this.productRepository.create({
//   ...createProductDto,
//   fileName, // now has "models/filename.glb" or "images/filename.jpg"
//   category,
// });

// return this.productRepository.save(newProduct);
// }








// async findAll(page = 1, limit = 10) {
//   const [products, total] = await this.productRepository.findAndCount({
//     relations: ['category'],
//     skip: (page - 1) * limit,
//     take: limit,
//   });

//   const baseUrl = `http://192.168.0.102:3000`;

//   return products.map((product) => {
//     let fileType: 'image' | '3d' | null = null;
//     let imageUrl: string | null = null;
//     let modelUrl: string | null = null;

//     if (product.fileName) {
//       if (product.fileName.toLowerCase().endsWith('.glb')) {
//         fileType = '3d';
//         modelUrl = `${baseUrl}/uploads/models/${product.fileName}`;
//       } else {
//         fileType = 'image';
//         imageUrl = `${baseUrl}/uploads/images/${product.fileName}`;
//       }
//     }

//     return {
//       ...product,
//       fileType,
//       imageUrl,
//       modelUrl,
//     };
//   });
// }


async findAll(page = 1, limit = 10) {
  const [products, total] = await this.productRepository.findAndCount({
    relations: ['category'],
    skip: (page - 1) * limit,
    take: limit,
  });

  const baseUrl = `http://192.168.2.106:3000`;

  return products.map((product) => {
    let fileType: 'image' | '3d' | null = null;
    let modelUrl: string | null = null;


    if (product.modelPath) {
      fileType = '3d';
      modelUrl = `${baseUrl}/uploads/models/${product.modelPath}`;
    } else if (product.image) {
      fileType = 'image';
    }

    return {
      id: product.id,
      title: product.title,
      description: product.description,
      price: product.price,
      stock: product.stock,
      createdAt: product.createdAt,
      // category: product.category,
        image: product.image,      
      modelPath: product.modelPath,
      fileType,
      modelUrl,
    };
  });
}




   async findByCategory(categoryId: number) {
    const products = await this.productRepository.find({
      where: {category: {id: categoryId}},
      relations: ['category'],
      
    });
    return products;
  }



  

  // async findOne(id: number): Promise<Products> {
  //   const product = await this.productRepository.findOne({
  //     where: { id },
  //     relations: ['category'],
  //   });
  //   if (!product) {
  //     throw new NotFoundException(`Product with ID ${id} not found`);
  //   }
  //   return product;
  // }


async findOne(id: number): Promise<any> {
  const product = await this.productRepository.findOne({
    where: { id },
    relations: ['category'],
  });

  if (!product) {
    throw new NotFoundException(`Product with ID ${id} not found`);
  }

  let fileType = 'image';
  let imageUrl: string | null = null;
  let modelUrl: string | null = null;

  if (product.image) {
    const base64 = Buffer.from(product.image).toString('base64');
    imageUrl = `data:image/jpeg;base64,${base64}`;
  }

  if (product.modelPath) {
    modelUrl = `http://192.168.2.104:3000/products/${product.id}/model`;
    fileType = '3d';
  }

  return {
    ...product,  // keep your existing fields
    fileType,
    imageUrl,
    modelUrl,
  };
}




  async update(
    id: number,
    updateProductDto: UpdateProductDto,
    imageBuffer?: Buffer,
  ): Promise<Products> {
    const product = await this.productRepository.findOne({
      where: { id },
      relations: ['category'],
    });
    if (!product) throw new NotFoundException('Product not found');

    if (updateProductDto.categoryId) {
      const category = await this.categoryRepository.findOneBy({
        id: updateProductDto.categoryId,
      });
      if (!category) throw new NotFoundException('Category not found');
      product.category = category;
    }

    Object.assign(product, updateProductDto);

    if (imageBuffer) {
      product.image = imageBuffer;
    }

    await this.productRepository.save(product);

    return product;
  }

  async remove(id: number): Promise<void> {
    const product = await this.findOne(id);
    await this.productRepository.remove(product as Products);
  }

  async searchProducts(search = '', page = 1, limit = 10) {
    const skip = (page - 1) * limit;

    const [products, total] = await this.productRepository.findAndCount({
      where: [
        { title: Like(`%${search}%`) },
        // Remove category search unless you join properly
      ],
      relations: ['category'],
      skip,
      take: limit,
    });

    const updatedProducts = products.map((product) => ({
      ...product,
      image: product.image
        ? `data:image/png;base64,${product.image.toString('base64')}`
        : null,
    }));

    return {
      totalItems: total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      pageSize: limit,
      products: updatedProducts,
    };
  }
}
