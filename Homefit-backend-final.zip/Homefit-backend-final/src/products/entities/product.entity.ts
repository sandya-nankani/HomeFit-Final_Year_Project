import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  ManyToMany,
  JoinTable,
  OneToMany,
  CreateDateColumn,
} from 'typeorm';
import { Category } from 'src/category/entities/category.entity';
import { OrderDetails } from 'src/order/entities/orderDetails.entity';
import { Review } from 'src/reviews/entities/review.entity';

@Entity()
export class Products {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  title: string;

  @Column()
  description: string;

  @Column()
  price: number;

   @CreateDateColumn({nullable: true})
    createdAt: Date;

  @Column()
  stock: number;

  @Column({ type: 'longblob' })
  image: Buffer;

   @Column({ nullable: true }) // 3D model path
modelPath: string;

  @Column()
  discount: number;

  @Column()
  discountPrice: number;

  
   
@Column({ nullable: true })
fileName: string;


  @ManyToOne(() => Category)
  @JoinColumn({ name: 'categoryId' })
  category: Category;

  // @OneToMany(() => Feedback, (feedback) => feedback.product)
  // feedback: Feedback[];

  @ManyToMany(() => OrderDetails, (orderDetails) => orderDetails.products)
  orderDetails:OrderDetails[]

    @OneToMany(() => Review, (review) => review.product)
  reviews:Review[]
}

