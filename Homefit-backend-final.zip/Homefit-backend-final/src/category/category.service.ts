import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Category } from './entities/category.entity';
import { CreateCategoryDto } from './dto/create-category.dto';
import { UpdateCategoryDto } from './dto/update-category.dto';

@Injectable()
export class CategoryService {
  constructor(
    @InjectRepository(Category)
    private categoryRepository: Repository<Category>,
  ) {}

  async create(createCategoryDto: CreateCategoryDto, imageBuffer?: Buffer): Promise<Category> {
  const newCategory = this.categoryRepository.create({
    ...createCategoryDto,
    image: imageBuffer,
  });
  return await this.categoryRepository.save(newCategory);
}

  async findAll(): Promise<Category[]> {
    return await this.categoryRepository.find({ relations: ['products'] });
  }

  async findOne(id: number): Promise<Category> {
    const category = await this.categoryRepository.findOne({
      where: { id },
      relations: ['products'],
    });

    if (!category) {
      throw new NotFoundException(`Category with id ${id} not found`);
    }

    return category;
  }

  async update(
  id: number,
  updateCategoryDto: UpdateCategoryDto,
  imageBuffer?: Buffer
): Promise<Category> {
  const category = await this.categoryRepository.preload({
    id,
    ...updateCategoryDto,
    ...(imageBuffer && { image: imageBuffer }), // only set if image is provided
  });

  if (!category) {
    throw new NotFoundException(`Category with id ${id} not found`);
  }

  return this.categoryRepository.save(category);
}
async remove(id: number): Promise<void> {
    const result = await this.categoryRepository.delete(id);
    if (result.affected === 0) {
      throw new NotFoundException(`Category with id ${id} not found`);
    }
  }
}
