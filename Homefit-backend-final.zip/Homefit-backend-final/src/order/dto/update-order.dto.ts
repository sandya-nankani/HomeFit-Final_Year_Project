import { PartialType } from '@nestjs/mapped-types';
import { OrderDetailsDto } from './create-order.dto';


export class UpdateOrderDto extends PartialType(OrderDetailsDto) {}
