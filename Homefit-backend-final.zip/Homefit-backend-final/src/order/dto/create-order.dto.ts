export class OrderDetailsDto {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  mobileNo: string;
  address: string;
  city: string;
  paymentType: string;
  userId: number;

  products: {
    productId: number;
    quantity: number;
    totalPrice: number;
  }[];
}
