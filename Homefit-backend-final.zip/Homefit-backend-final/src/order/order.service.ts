import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { UpdateOrderDto } from './dto/update-order.dto';
import { Products } from 'src/products/entities/product.entity';
import { OrderDetailsDto } from './dto/create-order.dto';
import { OrderDetails } from './entities/orderDetails.entity';
import { EmailService } from 'src/auth/email.service';

@Injectable()
export class OrderService {
  constructor(
    @InjectRepository(OrderDetails)
    private readonly orderRepository: Repository<OrderDetails>,

    @InjectRepository(Products)
    private readonly productRepository: Repository<Products>,
    private readonly emailService: EmailService,

  ) {}

//  async placeOrder(orderDto: OrderDetailsDto) {
//   const orderAddress = this.orderRepository.create({
//     firstName: orderDto.firstName,
//     lastName: orderDto.lastName,
//     email: orderDto.email,
//     mobileNo: orderDto.mobileNo,
//     address: orderDto.address,
//     city: orderDto.city,
//     paymentType: orderDto.paymentType,
//     user: { id: orderDto.userId },
//   });

//   const savedAddress = await this.orderRepository.save(orderAddress);

//    const items = [];
//   let total = 0;

//   // Decrease stock
//   for (const item of orderDto.products) {
//     const product = await this.productRepository.findOne({ where: { id: item.productId } });

//     if (!product) throw new NotFoundException(`Product ID ${item.productId} not found`);
//     if (product.stock < item.quantity) throw new Error(`Insufficient stock for ${product.title}`);

// //   product.stock -= item.quantity;
// // await this.productRepository.save(product);

// await this.productRepository.update(item.productId, {
//       stock: product.stock - item.quantity,
//     });

//     items.push({
//       name: product.title,
//       quantity: item.quantity,
//       price: product.price,
//     });

//     total += product.price * item.quantity;
//   }

//   // Send email
//   await this.emailService.sendOrderConfirmation(orderDto.email,
//     {
//       items,
//     total,
//  });

//   return {
//     message: 'Order placed successfully',
//     orderAddress: savedAddress,
//   };
// }


async placeOrder(orderDto: OrderDetailsDto) {
  // 1. Fetch product entities
  const productIds = orderDto.products.map(p => p.productId);
  const products = await this.productRepository.findBy({ id: In(productIds) });

  if (products.length !== productIds.length) {
    throw new NotFoundException('One or more products not found');
  }

  // 2. Check stock and decrease
  for (const item of orderDto.products) {
    const product = products.find(p => p.id === item.productId);
    if (!product) continue;

    if (product.stock < item.quantity) {
      throw new Error(`Insufficient stock for ${product.title}`);
    }

    product.stock -= item.quantity;
    await this.productRepository.save(product);
  }

  // 3. Create and assign products
  const orderAddress = this.orderRepository.create({
    firstName: orderDto.firstName,
    lastName: orderDto.lastName,
    email: orderDto.email,
    mobileNo: orderDto.mobileNo,
    address: orderDto.address,
    city: orderDto.city,
    paymentType: orderDto.paymentType,
    products: products, // 🔥 THIS is what saves to the join table
    user: { id: orderDto.userId },
  });

  const savedAddress = await this.orderRepository.save(orderAddress);
  console.log('====================================');
  console.log(savedAddress);
  console.log('====================================');

  // Optional: send email
  await this.emailService.sendOrderConfirmation(orderDto.email, 
    {
       id: savedAddress.id,
    items: orderDto.products.map(p => {
      const product = products.find(prod => prod.id === p.productId);
      return {
       
        name: product?.title,
        quantity: p.quantity,
        price: product?.price,
      };
    }),
    total: orderDto.products.reduce((acc, item) => {
      const prod = products.find(p => p.id === item.productId);
      return acc + (prod?.price || 0) * item.quantity;
    }, 0),
  });
}

  async findAll(): Promise<OrderDetails[]> {
  return await this.orderRepository.find({
    relations: ['user', 'products'],
    order: { id: 'DESC' }, // optional: newest first
  });
}

  async findOne(id: number): Promise<OrderDetails> {
    const order = await this.orderRepository.findOne({ where: { id } });
    if (!order) {
      throw new NotFoundException(`Order with ID ${id} not found`);
    }
    return order;
  }

  // async update(id: number, updateOrderDto: UpdateOrderDto): Promise<OrderDetails> {
  //   await this.findOne(id);
  //   await this.orderRepository.update(id, updateOrderDto);
  //   return this.findOne(id);
  // }



  async update(id: number, updateOrderDto: UpdateOrderDto): Promise<OrderDetails> {
  const order = await this.findOne(id); // Throws if not found

  // Extract only product IDs and fetch real Products
  const productIds = updateOrderDto.products.map(p => p.productId);
  const products = await this.productRepository.findBy({ id: In(productIds) });

  // Update order with valid Products array
  await this.orderRepository.update(id, {
    ...updateOrderDto,
    products: products, // ✅ Correct type
  });

  return this.findOne(id); // Return updated record
}


  async remove(id: number): Promise<void> {
    const order = await this.findOne(id);
    await this.orderRepository.remove(order);
  }
}
