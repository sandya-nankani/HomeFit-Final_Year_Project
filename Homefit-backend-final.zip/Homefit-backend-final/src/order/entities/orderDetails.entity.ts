
import { PaymentGateway } from 'src/payment-gateway/entities/payment-gateway.entity';
import { Products } from 'src/products/entities/product.entity';
import { User } from 'src/users/entities/user.entity';
import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  ManyToMany,
  JoinTable,
  OneToMany,
  OneToOne,
} from 'typeorm';

@Entity()
export class OrderDetails {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  firstName: string;

  @Column()
  lastName: string;

  @Column()
  email: string;

  @Column()
  mobileNo: string;

  @Column()
  address: string;

  @Column()
  city: string;

  @Column()
  state: string;

  // @Column()
  // pincode: string;

  
  @Column()
  paymentType: string;

  @ManyToOne(() => User, (user) => user.orderDetails)
  @JoinColumn({ name: 'userId' })
  user: User;

 @OneToOne(() => PaymentGateway, (payment) => payment.order)
 @JoinColumn({ name: 'paymentId' }) 
payment: PaymentGateway;


  @ManyToMany(() => Products, (product) => product.orderDetails, {cascade: true})
  @JoinTable({ name: 'OrderedProducts' })
  products:Products[]
  
}
