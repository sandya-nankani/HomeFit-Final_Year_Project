import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { UpdateUserDto } from './Dto/UpdateUserDto';
import { User } from './entities/user.entity';
import { Not, Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class UsersService {
  constructor(@InjectRepository(User) private userRepository: Repository<User>){}

  async createUser(userData: User): Promise<User> {
    console.log(userData)
    return await this.userRepository.save(userData); 
  }
  findAll() {
    return this.userRepository.find();
  }

  async findOne(id: number) {
    const user = await this.userRepository.findOne({ where: { id } });

    if (!user) {
        throw new NotFoundException(`User with ID ${id} not found`);
    }

    // Decode Base64 image if it exists
    if (user.profilePic) {
        user.profilePic = `data:image/png;base64,${user.profilePic}`;
    }

    return user;
}

  findbyUserName(username:string){
    return this.userRepository.findOne({where:{userName:username}})
  }
  
  findbyEmail(email:string){
    const user= this.userRepository.findOne({where:{email:email}})
    return user;
  }

  async update(id: number, updateUserDto: UpdateUserDto) {
    console.log(updateUserDto);
    
     const passChnage =await this.userRepository.update(id,updateUserDto);
     return {"Password chaged successfully":passChnage};
  }

async updateStatus(userId: number, newStatus: string): Promise<User> {
  const user = await this.userRepository.findOne({ where: { id: userId } });

  if (!user) {
    throw new Error('User not found');
  }

  return user;
}


remove(id: number) {
    return this.userRepository.delete(id);
  }
}
