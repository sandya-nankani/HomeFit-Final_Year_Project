export class UpdateUserDto {

    firstName: string;

    lastName: string;

    cnic: string;

    email: string;

    phone: string;

    address: string;
 
    shopName: string;

    amount: number;

    password:string;
}