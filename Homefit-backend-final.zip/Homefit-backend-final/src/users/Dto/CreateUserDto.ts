export class CreateUserDto {

    firstName: string;

    lastName: string;
    
    userName:string;

    password:string

    email: string;

    phone: string;

    accountType:string;

    address: string;
}