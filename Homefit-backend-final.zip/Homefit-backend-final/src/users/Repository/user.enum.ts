// user-role.enum.ts
export enum AccountType {
    USER = 'user',
    ADMIN = 'admin',
  }
  