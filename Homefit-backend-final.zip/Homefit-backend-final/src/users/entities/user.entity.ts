import { OrderDetails } from "src/order/entities/orderDetails.entity";
import { PaymentGateway } from "src/payment-gateway/entities/payment-gateway.entity";
import { Review } from "src/reviews/entities/review.entity";
import { Column, Entity, PrimaryGeneratedColumn, OneToMany, JoinColumn } from "typeorm";

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  profilePic: string;
  
  @Column()
  firstName: string;

  @Column()
  lastName: string;

  @Column()
  userName: string;

  @Column()
  password: string;
  
  @Column()
  email: string;
  
  @Column()
  phone: string;
  
  @Column()
  address: string;
  
  @Column({ nullable: true })
  accountType: string;
  
  @OneToMany(() => OrderDetails, (orderDetails) => orderDetails.user)
  orderDetails: OrderDetails[];

  @OneToMany(() => PaymentGateway, (paymentGateway) => paymentGateway.user)
    payments: PaymentGateway[];

  @OneToMany(() => Review, (review) => review.user)
  reviews: Review[];


}

