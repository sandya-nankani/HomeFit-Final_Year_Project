// import { NestFactory } from '@nestjs/core';
// import { AppModule } from './app.module';
// import { NestExpressApplication } from '@nestjs/platform-express';
// import { join } from 'path';
// import * as dotenv from 'dotenv';


// async function bootstrap() {
//   const app = await NestFactory.create<NestExpressApplication>(AppModule);
//   dotenv.config();
//   app.enableCors({
//     origin:'*',
//     methods:['GET','POST','PUT','DELETE','PATCH'],
//     allowedHeaders:['Content-Type','Authorization'],
//   });
//   app.useStaticAssets(join(__dirname, '..', 'public'));
//   await app.listen(process.env.PORT ?? 3000);
// }
// bootstrap();



import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { NestExpressApplication } from '@nestjs/platform-express';
import { join } from 'path';
import * as dotenv from 'dotenv';
import * as express from 'express';

async function bootstrap() {
  dotenv.config();

  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  app.enableCors({
    origin: '*',
    methods: ['GET','POST','PUT','DELETE','PATCH'],
    allowedHeaders: ['Content-Type','Authorization'],
  });

  // Serve public folder (old behavior)
  app.useStaticAssets(join(__dirname, '..', 'public'));

  // ✅ Serve /uploads explicitly
  app.use(
    '/uploads',
    express.static(join(__dirname, '..', 'uploads')),
  );

  console.log('📂 Serving uploads from:', join(__dirname, '..', 'uploads'));

  await app.listen(process.env.PORT ?? 3000);
}
bootstrap();
    